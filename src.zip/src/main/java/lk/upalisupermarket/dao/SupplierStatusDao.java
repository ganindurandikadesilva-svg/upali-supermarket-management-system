package lk.upalisupermarket.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import lk.upalisupermarket.entity.SupplierStatus;


public interface SupplierStatusDao extends JpaRepository<SupplierStatus,Integer> {

}
