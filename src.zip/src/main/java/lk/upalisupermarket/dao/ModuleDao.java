package lk.upalisupermarket.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import lk.upalisupermarket.entity.Module;

public interface ModuleDao extends JpaRepository<Module,Integer>{

}
