package lk.upalisupermarket.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import lk.upalisupermarket.entity.GrnStatus;


public interface GrnStatusDao extends JpaRepository<GrnStatus,Integer>{

}
