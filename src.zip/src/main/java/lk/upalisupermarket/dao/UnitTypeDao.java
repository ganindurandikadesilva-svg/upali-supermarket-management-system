package lk.upalisupermarket.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import lk.upalisupermarket.entity.UnitType;

public interface UnitTypeDao extends JpaRepository<UnitType,Integer> {

}
