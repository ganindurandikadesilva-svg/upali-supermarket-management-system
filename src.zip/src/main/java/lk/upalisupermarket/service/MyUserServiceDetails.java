package lk.upalisupermarket.service;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;
import lk.upalisupermarket.dao.UserDao;
import lk.upalisupermarket.entity.Role;
import lk.upalisupermarket.entity.User;

@Service//mek dunne nattm config file ekt bari wenw MyUserDetails file ek load krnna
public class MyUserServiceDetails implements UserDetailsService {

    @Autowired
    private UserDao userDao;

    @Override
    @Transactional//Me anotation ek natuwa list access krnn ba
    //username ekt adal user kenek innwd balala e user ta adala UserDetails object ekk return karai
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
      
        System.out.println(username);

        User extUser=userDao.getByUserName(username);

        //existing user ge roles set eka rolename eka dila GrantedAuthority object ekk hadla eka set ekt add krnwa
        Set<GrantedAuthority> authority=new HashSet();
        for(Role userRole:extUser.getRoles()){
            authority.add(new SimpleGrantedAuthority(userRole.getName()));
        }

        
        return new org.springframework.security.core.userdetails.User(extUser.getUsername(), extUser.getPassword(),
        extUser.getStatus(),true,true,true,authority);

    }

}
