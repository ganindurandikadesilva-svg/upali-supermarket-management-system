//Browser load event
window.addEventListener("load", () => {
  console.log("load");
 
  

  //enable tooltip
  $('[data-bs-toggle="tooltip"]').tooltip();

  refreshEmpTable();

  refreshEmpForm();
});

//refresh table area
const refreshEmpTable = () => {
  //
 // actionButtons.style.display = "none"; // added for table style 3
  //table
 
//calling the ajax request func in coommon func.js to get data
 employees  = getServiceRequest("/employee/findall")

 /*  //accessing data of database using ajax for employee table
  $.ajax({
    url: "employee/findall",
    type: "GET", // HTTP method(GET/POST/PUT/DELETE)
    async: false,
    dataType: "json", // The type of data expected from the server
    success: function (response) {
      // Callback function executed if the request is successful
      console.log("Success", response);
      employees = response;
    },
    error: function (xhr, status, error) {
      // Callback function executed if the request fails
      console.log("Error", response);
    },
  }); */

  /*  let employees = [
    {
      id: 1,
      fullname: "Ganindu Randika",
      callingname:"Ganindu",
      nic: 200116301733,
      phone_no: "0710700591",
      landno: "",
      gender: "Male",
      dob: "1990-06-11",
      email:"ganindud@gmail.com",
      civilstatus:"Married",
      designation: { id: 1, name: "Manager" },
      employeeStatus: { id: 1, status: "Active" },
    },
    {
      id: 2,
      fullname: "Haritha Pramoda",
      callingname:"Haritha",
      nic: 200116301735,
      phone_no: "0710700591",
      landno:"",
      gender: "Male",
      dob: "1999-06-11",
      email:"harithaP@gmail.com",
      civilstatus:"Single",
      designation: { id: 2, name: "As-Manager" },
      employeeStatus: { id: 2, status: "Resigned" },
    },
    {
      id: 3,
      fullname: "Sahan Perera",
      callingname:"Sahan",
      nic: 200116301733,
      phone_no: "0710700591",
      landno: "0382295563",
      gender: "FeMale",
      dob: "1990-06-11",
      email:"sahanpp@gmail.com",
      civilstatus:"Married",
      designation: { id: 3, name: "Cashier" },
      employeeStatus: { id: 3, status: "Deleted" },
    },
  ]; */

  //Datatypes
  //string --> date/string/number
  //function-->object/array/boolean
   //decimal-->decimal/price
  let columnList = [
    { columnName: "fullname", dataType: "string" },
    { columnName: "callingname", dataType: "string" },
    { columnName: "nic", dataType: "string" },
    { columnName: "mobile_no", dataType: "string" },
    { columnName: "emp_photo", dataType: "image-array" },
    { columnName: "gender", dataType: "string" },
    { columnName: "dob", dataType: "string" },
    // { columnName: generateBirthYear, dataType: "function" },
    { columnName: "email", dataType: "string" },
    { columnName: "civil_status", dataType: "string" },
    { columnName: getDesignation, dataType: "function" },
    { columnName: getEmpStatus, dataType: "function" },
  ];

  //call the common function to fill data into table(tablebody id,datalist name,column list,edit parameter,
  //delete parameter,view parameter,button visibility)
  // fillDataintoTable(tableBodyEmployee,employees,columnList,employeeEdit,employeeDelete,employeeView,true);
  fillDataintoTableTwo(
    tableBodyEmployee,
    employees,
    columnList,
    employeeEdit,
    employeeDelete,
    employeeView,
    true
  );
  // fillDataintoTableThree(tableBodyEmployee,employees,columnList,true);

    //disabling modifying buttons based on conditions
   for (const index in employees) {

    if (employees[index].emp_status_id.name=="Deleted") {
    const row = tableBodyEmployee.children[index];         // get the <tr>
    const lastCell = row.lastElementChild;                      // get the last <td>
    const deleteBtn = lastCell.querySelector("ul li:nth-child(3) button"); // third li button = Delete    
    deleteBtn.disabled="disabled";//deleteBtn.classList.add("d-none") for hide delete btn
  }
    
  }

  $("#employeeTable").DataTable();
};


//function to get designation
const getDesignation = (dataOb) => {
  return dataOb.designaton_id.name;
};

//function to get employee status
const getEmpStatus = (dataOb) => {


if (dataOb.emp_status_id.name == "Working") {
    let working =
      "<span class='badge text-bg-success'>" +
      dataOb.emp_status_id.name +
      "</span>";
    return working;
  }
  if (dataOb.emp_status_id.name == "Resigned") {
    let resigned =
      "<span class='badge text-bg-primary'>" +
      dataOb.emp_status_id.name +
      "</span>";
    return resigned;
  }
  if (dataOb.emp_status_id.name == "Deleted") {
    let deleted =
      "<span class='badge text-bg-danger'>" +
      dataOb.emp_status_id.name +
      "</span>";
    return deleted;
  }
};

/* //function to get date of birth
const generateBirthYear = (dataOb) => {
  return new Date(dataOb.dob).getFullYear();
}; */





//function for edit row
const employeeEdit = (dataOb, index) => {
  //old employee and employee for update checking
  employee = JSON.parse(JSON.stringify(dataOb));// Working copy for editing-->//if there is an update only the employee variable will be modified since its the passing object in frontend 
  oldEmployee = JSON.parse(JSON.stringify(dataOb));// Original copy for comparison

  /* JSON.stringify(dataOb) converts the object to a JSON string
JSON.parse() converts that JSON string back to a JavaScript object
This creates a completely new object with the same data */

  console.log("Edit", dataOb, index);
  //tableBodyEmployee.children[index].style.border="2px solid black";

  //refill the form
  txtFullname.value = dataOb.fullname;
  txtCallingName.value = dataOb.callingname;



  let fullNameParts = txtFullname.value.split(" ");

  //filling calling name  data list
  fullNameParts.forEach((element) => {
    let option = document.createElement("option");
    option.value = element;
    if (element.length > 2) {
      DCallingName.appendChild(option);
    }
  });

  txtEmail.value = dataOb.email;
  txtNic.value = dataOb.nic;
  txtMobileNo.value = dataOb.mobile_no;

  if (dataOb.gender == "Male") {
    radioMale.checked = true;
  } else {
    radioFemale.checked = true;
  }

  txtDOB.value = dataOb.dob;
  txtAddress.value=dataOb.address;
  civilStatus.value = dataOb.civil_status; //static

  selectDesignation.value = JSON.stringify(dataOb.designaton_id); //object ekk nisa (dynamic ewge)
  selectEmpStatus.value = JSON.stringify(dataOb.emp_status_id); //dynmaic

  //not required 
  //set photo
  if (dataOb.emp_photo!=null) {
    empPhotoPreview.src=atob(dataOb.emp_photo);
  } else {
    empPhotoPreview.src="images/undraw_profile.jpg";
  }
  //required nati nisa
  if (dataOb.txtLandNo == null) {
    txtLandNo.value = " ";
  } else {
    txtLandNo.value = dataOb.landno;
  }

   //required nati nisa
   if (dataOb.txtNote == null) {
    txtNote.value = " ";
  } else {
    txtNote.value = dataOb.note;
  }


  $("#employeeFormModal").modal("show"); //show modal

  
  //disable submit button,Enable update button in edit function
  submitButton.style.display="none";
  updateButton.removeAttribute("style");
};

//function for delete row
const employeeDelete = (dataOb, index) => {
  console.log("Delete", dataOb, index);
 
   //need to get user confirmation
    let userConfirmation=window.confirm("Are You sure you want to delete the following Employee .. ?"+
      "\nEmployee Full Name :"+dataOb.fullname +
      "\nEmployee Calling Name :"+dataOb.callingname +
      "\nEmployee DOB :"+dataOb.dob +
      "\nEmployee NIC :"+dataOb.nic +
      "\nEmployee Email :"+dataOb.email+ 
      "\nEmployee Designation :"+dataOb.designaton_id.name+ 
      "\nEmployee Mobile No :"+dataOb.phone_no+ 
      "\nEmployee Land No :"+dataOb.landno+ 
      "\nEmployee Gender :"+dataOb.gender+ 
      "\nEmployee Civil Status :"+dataOb.civilstatus

    );
    if (userConfirmation) {
      //Call delete service
        let deleteResponse=getHTTPServiceRequest("/employee/delete","DELETE",dataOb);
      
      if (deleteResponse=="OK") {

        window.alert("Delete Successfull !..\n");
        refreshEmpTable();//refresh employee table
        // window.location.reload(); full browser reload -->reload every image&...
        refreshEmpForm();//refresh employee form

      } else {
        window.alert("Submission Failed !..\n"+deleteResponse);
      }
    } 
};

//function for view/print row
const employeeView = (dataOb, index) => {
  console.log("View", dataOb, index);

  //option 1

  //how to open a new tab and enter html tags and styles using js

  /* 
  let newTab=window.open();
  let printTab="<head><title>Employee Print</title>"+
  "<link rel='stylesheet' href='../resources/bootstrap-5.2.3/css/bootstrap.min.css'></head>"+
  "<body><table class='table table-striped'><tr><th>Full Name</th><td>"+dataOb.fullname+"</td></tr></table></body>";
  newTab.document.write(printTab);

  setTimeout(()=>{
    //what should happen after 1500 ms
    newTab.stop();
    newTab.print();
    newTab.close();
  },1500) */

  //option 2 view in  a modal
  

  Emp_FullName.innerText = dataOb.fullname;
  Emp_CallingName.innerText = dataOb.callingname;
  Emp_Nic.innerText = dataOb.nic;
  Emp_Email.innerText = dataOb.email;
  Emp_DOB.innerText = dataOb.dob;
  Emp_Status.innerText = dataOb.emp_status_id.name;
  Emp_Designation.innerText = dataOb.designaton_id.name;
  Emp_MobileNo.innerText = dataOb.mobile_no;
  Emp_LandNo.innerText = dataOb.land_no;
  Emp_Gender.innerText = dataOb.gender;
  Emp_civilStatus.innerText = dataOb.civil_status;
  Emp_Address.innerText = dataOb.address;
  Emp_Note.innerText = dataOb.note;
 
  $("#employeeFormModalView").modal("show"); //show modal
};

//option 2 Print row new tab open
const printButtonRow = () => {
  let newTab = window.open();
  let printTab =
"<head><title>Employee Print</title>" +
"<link rel='stylesheet' href='bootstrap-5.2.3/css/bootstrap.min.css'>" +
"</head>" +
"<body>" +
"<h4 class='text-center mt-3'>Employee Print</h4>" +
"<div class='container mt-3'>" +
"  <div class='row justify-content-center'>" +
"    <div class='col-md-8'>" + employeeTableView.outerHTML + "</div>" +
"  </div>" +
"</div>" +
"</body>";

  newTab.document.write(printTab);

  setTimeout(() => {
    //what should happen after 1500 ms
    newTab.stop();
    newTab.print();
    newTab.close();
  }, 1500);
};




/* *************************************************************************** */
/* **************************  FORM *********************************************/

//refresh form area
const refreshEmpForm = () => {
 





  //static element only is cleared
  //Cleaning the values(select list not needed dynamic nm )

  empForm.reset(); //clearing the form values

  empPhotoFile.value="";//clearing image file input field
  empPhotoPreview.src="images/undraw_profile.jpg"; //default photo


  employee = new Object(); //creating a new object

   //refilling the dynamic elements
   let designation = getServiceRequest("/designation/findall")//calling the ajax request func in coommon func.js

   //accessing data of database using ajax for designation dropdown
  /*  $.ajax({
     url: "/designation/findall",
     type: "GET", // HTTP method(GET/POST/PUT/DELETE)
     async: false,
     dataType: "json", // The type of data expected from the server
     success: function (response) {
       // Callback function executed if the request is successful
       console.log("Success", response);
       designation = response;
     },
     error: function (xhr, status, error) {
       // Callback function executed if the request fails
       console.log("Error", response);
     },
   }); */
 
  /*  employeeStatus = [
     { id: 1, status: "Active" },
     { id: 2, status: "Resigned" },
     { id: 3, status: "Deleted" },
   ]; */
 
   //employee status select list
  let employeeStatus = getServiceRequest("/employeestatus/findall")//calling the ajax request func in coommon func.js
 
  //calling reusable function for select list(elementid,massege,dtaalistname,prportyname of the datalist)
   fillDataintoSelect(
     selectDesignation,
     "Select Designation",
     designation,
     "name"
   );
   //calling reusable function for select list(elementid,massege,dtaalistname,prportyname of the datalist)
   fillDataintoSelect(
     selectEmpStatus,
     "Select Employee status",
     employeeStatus,
     "name"
   );
 

  /* txtFullname.value="";
   txtCallingName.value="";
   txtNic.value="";
    */

     //set employee status aailable when loading form
     selectEmpStatus.value=JSON.stringify(employeeStatus[0]);//[0] is "available" in employee status table
     employee.emp_status_id=JSON.parse(selectEmpStatus.value);
 

  // //Need to clear the colors

  setToDefault([
    txtFullname,
    txtCallingName,
    txtNic,
    txtEmail,
    txtDOB,
    txtMobileNo,
    txtLandNo,
    selectEmpStatus,
    selectDesignation,
    civilStatus,
    txtAddress,
    txtNote
  ]);



  /*  txtFullname.classList.remove("is-valid");
  //  txtFullname.style.border="1px solid #ced4da";
  civilStatus.classList.remove("is-valid");
  //  civilStatus.style.border="1px solid #ced4da"; */

  //set color for supplier Status
  selectEmpStatus.classList.remove("is-invalid");
  selectEmpStatus.classList.add("is-valid"); 

    //disable update button,Enable submit button
  // updateButton.style.visibility="hidden";
  // submitButton.style.visibility="visible";

  updateButton.style.display="none";
  submitButton.removeAttribute("style");
};

//clearing the selected image
const clearSelectedPhotoFile=()=>{

  empPhotoFile.value="";//clearing image file input field
  empPhotoPreview.src="images/undraw_profile.jpg"; //default photo
}




//check form errors

const checkEmployeeFormErrors = () => {
  let errors = "";
  if (employee.fullname == null) {
    errors = errors + "Please Enter  Full Name \n";
  }
  if (employee.callingname == null) {
    errors = errors + "Please Enter Calling Name \n";
  }
  if (employee.nic == null) {
    errors = errors + "Please Enter  NIC \n";
  }
  if (employee.email == null) {
    errors = errors + "Please Enter an Email \n";
  }
  if (employee.designaton_id == null) {
    errors = errors + "Please Enter a Designation\n";
  }
  if (employee.emp_status_id == null) {
    errors = errors + "Please Select an Employee Status \n";
  }
  if (employee.civil_status == null) {
    errors = errors + "Please Select a Civil Status \n";
  }
  if (employee.gender == null) {
    errors = errors + "Please select a Gender \n";
  }

  if (employee.dob == null) {
    errors = errors + "Please Enter DOB \n";
  }
  if (employee.mobile_no == null) {
    errors = errors + "Please Enter  Mobile No \n";
  }
  // if(employee.landno==null){
  //   errors=errors+"Please Enter Land No \n";

  // }
  return errors;
};

//Employee form submit event Function
const empSubmitButton = () => {

  console.log(employee);
  
  //check form error for required fields
  let errors = checkEmployeeFormErrors(); //call the error function
  if (errors == "") {
    //no errors
    //need to get user confirmation
    let userConfirmation = window.confirm(
      "Are You sure you want to add the following Employee .. ?" +
        "\nEmployee Full Name :" +
        employee.fullname +
        "\nEmployee Calling Name :" +
        employee.callingname +
        "\nEmployee DOB :" +
        employee.dob +
        "\nEmployee NIC :" +
        employee.nic +
        "\nEmployee Email :" +
        employee.email +
        "\nEmployee Designation :" +
        employee.designaton_id.name +
        "\nEmployee Status :" +
        employee.emp_status_id.name +
        "\nEmployee Mobile No :" +
        employee.mobile_no +
        "\nEmployee Land No :" +
        employee.land_no +
        "\nEmployee Gender :" +
        employee.gender +
        "\nEmployee Civil Status :" +
        employee.civil_status
    );
    if (userConfirmation) {
      //Call post service(url,method,data) data means object name-->employee
      let postServiceResponse = getHTTPServiceRequest("/employee/insert","POST",employee);
      if (postServiceResponse == "OK") {
        window.alert("Submission Successfull !..\n");
        refreshEmpTable(); //refresh employee table
        // window.location.reload(); full browser reload -->reload every image&...
        refreshEmpForm(); //refresh employee form
        $("#employeeFormModal").modal("hide"); //Hide modal
      } else {
        window.alert("Submission Failed !..\n" + postServiceResponse);
      }
    }
  } else {
    window.alert("Form Contains Following Errors !..\n" + errors);
  }

  // console.log(employee);

  refreshEmpTable();
};

const checkEmployeeFromUpdates = () => {
  let updates = "";

  console.log(employee);//if there is an update only the employee variable will be modified since its the passing object in frontend 
  console.log(oldEmployee);

  if (employee != null && oldEmployee != null) {
    if (employee.fullname != oldEmployee.fullname) {
      updates =
        updates +
        "Full Name changed from " +
        oldEmployee.fullname +
        " into " +
        employee.fullname +
        "\n";
    }
    if (employee.callingname != oldEmployee.callingname) {
      updates =
        updates +
        "Calling Name changed from " +
        oldEmployee.callingname +
        " into " +
        employee.callingname +
        "\n";
    }
    if (employee.nic != oldEmployee.nic) {
      updates =
        updates +
        "Nic changed from " +
        oldEmployee.nic +
        " into " +
        employee.nic +
        "\n";
    }
    if (employee.email != oldEmployee.email) {
      updates =
        updates +
        "Email changed from " +
        oldEmployee.email +
        " into " +
        employee.email +
        "\n";
    }
    if (employee.dob != oldEmployee.dob) {
      updates =
        updates +
        "DOB changed from " +
        oldEmployee.dob +
        " into " +
        employee.dob +
        "\n";
    }
    if (employee.emp_status_id.name != oldEmployee.emp_status_id.name) {
      updates =
        updates +
        "Employee Status changed from " +
        oldEmployee.emp_status_id.name +
        " into " +
        employee.emp_status_id.name +
        "\n";
    }
    if (employee.designaton_id.name != oldEmployee.designaton_id.name) {
      updates =
        updates +
        "Designation changed from " +
        oldEmployee.designaton_id.name +
        " into " +
        employee.designaton_id.name +
        "\n";
    }
    if (employee.mobile_no != oldEmployee.mobile_no) {
      updates =
        updates +
        "Mobile No changed from " +
        oldEmployee.mobile_no +
        " into " +
        employee.mobile_no +
        "\n";
    }
    if (employee.landno != oldEmployee.landno) {
      updates =
        updates +
        "Land No changed from " +
        oldEmployee.landno +
        " into " +
        employee.landno +
        "\n";
    }
     if (employee.emp_photo != oldEmployee.emp_photo) {
      updates =
        updates +
        "Employee Photo changed";
    }
    if (employee.gender != oldEmployee.gender) {
      updates =
        updates +
        "Gender changed from " +
        oldEmployee.gender +
        " into " +
        employee.gender +
        "\n";
    }
    if (employee.civil_status != oldEmployee.civil_status) {
      updates =
        updates +
        "Civil Status changed from " +
        oldEmployee.civil_status +
        " into " +
        employee.civil_status +
        "\n";
    }
    if (employee.emp_photo!=oldEmployee.emp_photo) {
      updates=updates+"Employee Photo Changed\n";
    }
    if (employee.note != oldEmployee.note) {
      updates =
        updates +
        "Note changed from " +
        oldEmployee.note +
        " into " +
        employee.note +
        "\n";
    }
  }

  return updates;
};

//Employee Form update event function
const empUpdateButton = () => {
  //check for form eroors
  let errors = checkEmployeeFormErrors();
  if (errors == "") {
    //check for employee Form updates
    let updates = checkEmployeeFromUpdates();
    if (updates == "") {
      window.alert("Form Contains No Updates..!");
    } else {
      //Need user confirmation
      let userConfirmation = window.confirm(
        "Are you Sure you want to update the following changes ?\n" + updates
      );
      if (userConfirmation) {

        //call put service

        let putServiceResponse = getHTTPServiceRequest("/employee/update","PUT",employee);;
        if (putServiceResponse == "OK") {
          window.alert("Form update Successfull..!");
          refreshEmpForm();
          $("#employeeFormModal").modal("hide"); //Hide modal
        } else {
          window.alert("Form Update Unsucessfull..!\n" + putServiceResponse);
        }
      }
    }
  } else {
    window.alert("Form Contains Following Errors !..\n" + errors);
  }

  refreshEmpTable();
};

//Employee Form Delete function
const DeleteEmp = (dataOb, rowIndex) => {
  refreshEmpTable();
};







//Full name validation
txtFullname.addEventListener("keyup", () => {
  const fullnameValue = txtFullname.value;
  if (fullnameValue != "") {
    if (
      new RegExp("^([A-Z][a-z]{1,20}[\\s])+([A-Z][a-z]{1,20})$").test(
        fullnameValue
      )
    ) {
      //valid full name
      employee.fullname = fullnameValue;

      txtFullname.classList.remove("is-invalid");
      txtFullname.classList.add("is-valid");

      let fullNameParts = fullnameValue.split(" ");
      //console.log(fullNameParts);
      DCallingName.innerHTML = "";

      //initial calling name set
      txtCallingName.value = fullNameParts[0];
      txtCallingName.classList.remove("is-invalid");
      txtCallingName.classList.add("is-valid");

      employee.callingname = txtCallingName.value;

      //filling calling name  data list
      fullNameParts.forEach((element) => {
        let option = document.createElement("option");
        option.value = element;
        if (element.length > 2) {
          DCallingName.appendChild(option);
        }
      });
    } else {
      //invalid full name
      employee.fullname = null;

      txtFullname.classList.remove("is-valid");
      txtFullname.classList.add("is-invalid");
    }
  } else {
    //invalid full name
    employee.fullname = null;

    txtFullname.classList.remove("is-valid");
    txtFullname.classList.add("is-invalid");
  }
});

//calling name validation
const callingNameValidator = (callingNameElement) => {
  let callingNameValue = callingNameElement.value;
  const fullnameValue = txtFullname.value;
  let fullNameParts = fullnameValue.split(" ");

  if (callingNameValidator != "") {
    let extIndex = fullNameParts
      .map((fullNamePart) => fullNamePart)
      .indexOf(callingNameValue);
    if (extIndex != -1) {
      //valid calling name
      employee.callingname = txtCallingName.value;

      callingNameElement.classList.remove("is-invalid");
      callingNameElement.classList.add("is-valid");
    } else {
      //invalid calling name
      employee.callingname = null;

      callingNameElement.classList.remove("is-valid");
      callingNameElement.classList.add("is-invalid");
    }
  } else {
    //invalid calling name
    employee.callingname = null;

    callingNameElement.classList.remove("is-valid");
    callingNameElement.classList.add("is-invalid");
  }
};

//Nic validation
const nicValidator = (nicElement) => {
  let nicValue = nicElement.value;
  if (nicValue != "") {
    if (new RegExp("^(([98765][0-9]{8}[VvXx])||([0-9]{12}))$").test(nicValue)) {
      //valid nic
      employee.nic = nicValue;//binding

      nicElement.classList.remove("is-invalid");
      nicElement.classList.add("is-valid");

      //generate  Dob and gender using nic
      //Generate dob
      let birthYear,birthDay;
      if (nicValue.length==10) {//920313523V (Example nic for this)

        birthYear="19"+nicValue.substring(0,2);//0,1 values of nic
        birthDay="19"+nicValue.substring(0,2);

      } else {//200116301733 (Example nic for this)
        birthYear=nicValue.substring(0,4);//0,1,2 values of nic
        birthDay=nicValue.substring(4,7);
      }
      console.log(birthYear,birthDay);

      //Generate gender
      if (parseInt(birthDay>500)) {
        console.log("Female");
        employee.gender="Female";
        birthDay=parseInt(birthDay)-500;//substract to find the real date
        radioFemale.checked=true;
      }
      else{
        console.log("Male");
        employee.gender="Male";
        radioMale.checked=true;
      }
      
      //Generate the BirthDate 
      let birthDateOb=new Date(birthYear+"-01-01");//date object for january 1st of birth year 
      birthDateOb.setDate(parseInt(birthDay));//and add the days to it

      if (parseFloat(birthYear)% 4 !=0 && parseInt(birthDay)>60) { //check if its a leap year(january 31days feb 29 means 60 so leap)(since we started from 1 need to look at more than 60)
        birthDateOb.setDate(birthDateOb.getDate()-1);
      }

      let month=birthDateOb.getMonth()+1;
      let date=birthDateOb.getDate();
      if (month<10) {
        month="0"+month;
      }
      if (date<10) {
        date="0"+date;
      }
      txtDOB.value=birthYear+"-"+month+"-"+date;
      employee.dob=txtDOB.value;

      txtDOB.classList.remove("is-invalid");
      txtDOB.classList.add("is-valid");

      //get age 
      //let currentYear=new Date().getFullYear(); use this and subrect it from birth year to generate age

    } else {
      //invalid nic
      employee.nic = null;
      employee.gender = null;
      employee.dob = null;
      
      txtDOB.classList.remove("is-valid");
      txtDOB.classList.add("is-invalid");

      nicElement.classList.remove("is-valid");
      nicElement.classList.add("is-invalid");
    }
  } else {
    //invalid nic
    employee.nic = null;

    nicElement.classList.remove("is-valid");
    nicElement.classList.add("is-invalid");
  }
};
