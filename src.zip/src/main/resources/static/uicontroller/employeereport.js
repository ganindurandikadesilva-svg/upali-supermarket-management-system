//Browser load event
window.addEventListener("load", () => {
  console.log("load");

  //enable tooltip
  $('[data-bs-toggle="tooltip"]').tooltip();


  refreshEmployeeReportForm();
});



const refreshEmployeeReportForm=()=>{
   employeeReport=new Object();
    let designation = getServiceRequest("/designation/findall")//calling the ajax request func in coommon func.js

   //accessing data of database using ajax for designation dropdown
  /*  $.ajax({
     url: "/designation/findall",
     type: "GET", // HTTP method(GET/POST/PUT/DELETE)
     async: false,
     dataType: "json", // The type of data expected from the server
     success: function (response) {
       // Callback function executed if the request is successful
       console.log("Success", response);
       designation = response;
     },
     error: function (xhr, status, error) {
       // Callback function executed if the request fails
       console.log("Error", response);
     },
   }); */
 
  /*  employeeStatus = [
     { id: 1, status: "Active" },
     { id: 2, status: "Resigned" },
     { id: 3, status: "Deleted" },
   ]; */
 
   //employee status select list
  let employeeStatus = getServiceRequest("/employeestatus/findall")//calling the ajax request func in coommon func.js
 
  //calling reusable function for select list(elementid,massege,dtaalistname,prportyname of the datalist)
   fillDataintoSelect(
     selectDesignation,
     "Select Designation",
     designation,
     "name"
   );
   //calling reusable function for select list(elementid,massege,dtaalistname,prportyname of the datalist)
   fillDataintoSelect(
     selectEmpStatus,
     "Select Employee status",
     employeeStatus,
     "name"
   );
 
}
  //function to generate reports
const generateReport=()=>{

  console.log(JSON.parse(selectEmpStatus.value).id);
  
   employees = getServiceRequest("/employeereport/listbystatusanddesignation/" + JSON.parse(selectEmpStatus.value).id+"/"+JSON.parse(selectDesignation.value).id);




  //Datatypes
  //string --> date/string/number
  //function-->object/array/boolean
   //decimal-->decimal/price
  let columnList = [
      { columnName: "fullname", dataType: "string" },
    { columnName: "nic", dataType: "string" },
    { columnName: "mobile_no", dataType: "string" },
    { columnName: "email", dataType: "string" },
    { columnName: getDesignation, dataType: "function" },
    { columnName: getEmpStatus, dataType: "function" },
   
  ];


  //call the common function to fill data into table(tablebody id,datalist name,column list))
  fillDataintoReportTable(
    employeeReportTableBody,
    employees,
    columnList
  );



}

  //function to get designation
const getDesignation = (dataOb) => {
  return dataOb.designaton_id.name;
};


//function to get employee status
const getEmpStatus = (dataOb) => {
  if (dataOb.emp_status_id.name=="Working") {
    let working="<span class='badge text-bg-success'>"+dataOb.emp_status_id.name+ "</span>";
    return  working ;
  }
  if (dataOb.emp_status_id.name=="Resigned") {
    let resigned="<span class='badge text-bg-primary'>"+dataOb.emp_status_id.name+ "</span>";
    return  resigned ;
  }
  if (dataOb.emp_status_id.name=="Deleted") {
    let deleted="<span class='badge text-bg-danger'>"+dataOb.emp_status_id.name+ "</span>";
    return  deleted ;
  }


};

//option 2 Print row new tab open
const printEmployeeReport = () => {
  let newTab = window.open();
  let printTab =
"<head><title>Employee Report Print</title>" +
"<link rel='stylesheet' href='bootstrap-5.2.3/css/bootstrap.min.css'>" +
"</head>" +
"<body>" +
"<h4 class='text-center mt-3'>Employee Report Print</h4>" +
"<div class='container mt-3'>" +
"  <div class='row justify-content-center'>" +
"    <div class='col-md-8'>" + employeeReportTable.outerHTML + "</div>" +
"  </div>" +
"</div>" +
"</body>";

  newTab.document.write(printTab);

  setTimeout(() => {
    //what should happen after 1500 ms
    newTab.stop();
    newTab.print();
    newTab.close();
  }, 1500);
};
