
  //function to generate reports
const generateReport=()=>{

  // generate table
  //calling the ajax request func in coommon func.js to get data
 dataList  = getServiceRequest("/purchasepaymentreport/bysdedtype?startdate="+dateStartDate.value+"&enddate="+dateEndDate.value+"&type="+selectDatePeriodType.value)
//JSON.parse(selectDatePeriodType.value).id if dynamic dropdown nm (meka static value constant ne)

 //Need to change the 2d array format of dataList into array of objects
let reportDataList=new Array();
let data=new Array();
let label=new Array();

for (const index in dataList) {
  let object=new Object();
  object.month=dataList[index][0];
  object.amount=dataList[index][1];
  reportDataList.push(object);

  //push to chart
  data.push(dataList[index][1]);
  label.push(dataList[index][0]);
}



  //Datatypes
  //string --> date/string/number
  //function-->object/array/boolean
   //decimal-->decimal/price
  let columnList = [
    { columnName: "month", dataType: "string" },
    { columnName: "amount", dataType: "decimal" },
   
  ];

  //call the common function to fill data into table(tablebody id,datalist name,column list))
  fillDataintoReportTable(
    purchasePaymentReportTableBody,
    reportDataList,
    columnList
  );


  //generate chart
 const ctx = document.getElementById('myChart');

 //clear chart when input value changed and generate button clicked
 if (Chart.getChart('myChart')!=undefined) {
  Chart.getChart('myChart').destroy();
 }
 

  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: label,
      datasets: [{
        label: 'Amount',
        data: data,
        borderWidth: 1,
        backgroundColor:generateRandomColors(data.length)//generate random colors   

      }]
    },
    options: {
      scales: {
        y: {
          beginAtZero: true
        }
      }
    }
  });


}


const reportforsixMonths=()=>{

  // generate table
  //calling the ajax request func in coommon func.js to get data
 dataList  = getServiceRequest("/purchasepaymentreport/bysixmonths")
//JSON.parse(selectDatePeriodType.value).id if dynamic dropdown nm (meka static value constant ne)

 //Need to change the 2d array format of dataList into array of objects
let reportDataList=new Array();
let data=new Array();
let label=new Array();

for (const index in dataList) {
  let object=new Object();
  object.month=dataList[index][0];
  object.amount=dataList[index][1];
  reportDataList.push(object);

  //push to chart
  data.push(dataList[index][1]);
  label.push(dataList[index][0]);
}



  //Datatypes
  //string --> date/string/number
  //function-->object/array/boolean
   //decimal-->decimal/price
  let columnList = [
    { columnName: "month", dataType: "string" },
    { columnName: "amount", dataType: "decimal" },
   
  ];

  //call the common function to fill data into table(tablebody id,datalist name,column list))
  fillDataintoReportTable(
    purchasePaymentReportTableBody,
    reportDataList,
    columnList
  );


  //generate chart
 const ctx = document.getElementById('myChart');

 //clear chart when input value changed and generate button clicked
 if (Chart.getChart('myChart')!=undefined) {
  Chart.getChart('myChart').destroy();
 }
 

  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: label,
      datasets: [{
        label: 'Amount',
        data: data,
        borderWidth: 1,
        backgroundColor:generateRandomColors(data.length)//generate random colors   

      }]
    },
    options: {
      scales: {
        y: {
          beginAtZero: true
        }
      }
    }
  });
}

  //function to print the chart
const printChart=()=>{

   const ctx = document.getElementById('myChart');
   
  let newTab = window.open();
  let printTab =
   ' <head><title>Chart Print</title>' +
    '<link rel="stylesheet" href="bootstrap-5.2.3/css/bootstrap.min.css">' +
    '</head> '+
    '<body> <h4 class="text-center">Purchase Order Report</h4>'+
    '<div class="row mt-2"><div class="col-6">'+
    '<table class="table table-bordered table-striped">'
    +purchasePayReportTable.outerHTML+
    '</table></div>'+
    '<div class="col-6">'+'<br><img src="' + ctx.toDataURL() + '"/></div>'+
    '</body>';
  newTab.document.write(printTab);

  setTimeout(() => {
    //what should happen after 1500 ms
    newTab.stop();
    newTab.print();
    newTab.close();
  }, 1500);
  }
  
