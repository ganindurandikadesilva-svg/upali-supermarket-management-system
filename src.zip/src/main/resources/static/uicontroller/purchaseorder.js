//Browser load event
window.addEventListener("load", () => {
  console.log("load");

  //enable tooltip
  $('[data-bs-toggle="tooltip"]').tooltip();

  refreshPurchaseOrderTable();

  refreshPurchaseOrderForm();
});

//refresh table area
const refreshPurchaseOrderTable = () => {
  //
  // actionButtons.style.display = "none"; // added for table style 3
  //table

  //calling the ajax request func in coommon func.js to get data
  purchaseorders = getServiceRequest("/purchaseorder/findall");

  //Datatypes
  //string --> date/string/number
  //function-->object/array/boolean
  //decimal-->decimal/price
  let columnList = [
    { columnName: "pod_no", dataType: "string" },
    { columnName: getItemList, dataType: "function" },
    { columnName: "grandtotal", dataType: "decimal" },
    { columnName: "required_date", dataType: "string" },
    { columnName: getQuotation, dataType: "function" },
    { columnName: getPurchaseOrderStatus, dataType: "function" },
  ];

  //call the common function to fill data into table(tablebody id,datalist name,column list,edit parameter,
  //delete parameter,view parameter,button visibility)
  // fillDataintoTable(purchaseOrderTableBody,employees,columnList,employeeEdit,employeeDelete,employeeView,true);
  fillDataintoTableTwo(
    purchaseOrderTableBody,
    purchaseorders,
    columnList,
    purchaseOrderEdit,
    purchaseOrderDelete,
    purchaseOrderView,
    true
  );
  // fillDataintoTableThree(purchaseOrderTableBody,employees,columnList,true);


  //disabling modifying buttons based on conditions
  for (const index in purchaseorders) {

    if (purchaseorders[index].purchase_order_status_id.name=="Deleted") {
    const row = purchaseOrderTableBody.children[index];         // get the <tr>
    const lastCell = row.lastElementChild;                      // get the last <td>
    const deleteBtn = lastCell.querySelector("ul li:nth-child(3) button"); // third li button = Delete    
    deleteBtn.disabled="disabled";//deleteBtn.classList.add("d-none") for hide delete btn
  }
  }

  $("#purchaseOrderTable").DataTable();
};

//function to get Item List
const getItemList = (dataOb) => {
  let purchaseOrderHasItemList = dataOb.purchaseOrderHasItemList;
  console.log(purchaseOrderHasItemList.length );
  
  let itemNames="";
  purchaseOrderHasItemList.forEach((itemObj, index) => {
    const itemName = itemObj.item_id.itemname;
    if (purchaseOrderHasItemList.length - 1 == index) {
      itemNames = itemNames +itemName; //remove the comma if its the last value
    } else {
      itemNames = itemNames+itemName+",";
    }
  });
  return itemNames;
};


//function to get Item List
const getQuotation = (dataOb) => {
  return dataOb.quotation_id.quotation_no;
};

//function to get Purchase Order Status
const getPurchaseOrderStatus = (dataOb) => {
  if (dataOb.purchase_order_status_id.name == "Pending") {
    let pending =
      "<span class='badge text-bg-secondary'>" +
      dataOb.purchase_order_status_id.name +
      "</span>";
    return pending;
  }
  if (dataOb.purchase_order_status_id.name == "Received") {
    let received =
      "<span class='badge text-bg-primary'>" +
      dataOb.purchase_order_status_id.name +
      "</span>";
    return received;
  }
  if (dataOb.purchase_order_status_id.name == "Completed") {
    let completed =
      "<span class='badge text-bg-success'>" +
      dataOb.purchase_order_status_id.name +
      "</span>";
    return completed;
  }
  if (dataOb.purchase_order_status_id.name == "Canceled") {
    let canceled =
      "<span class='badge text-bg-warning'>" +
      dataOb.purchase_order_status_id.name +
      "</span>";
    return canceled;
  }
  if (dataOb.purchase_order_status_id.name == "Deleted") {
    let deleted =
      "<span class='badge text-bg-danger'>" +
      dataOb.purchase_order_status_id.name +
      "</span>";
    return deleted;
  }
};

//function for edit/refill row
const purchaseOrderEdit = (dataOb, index) => {
  //old purchaseOrder and purchaseOrder for update checking
  purchaseOrder = JSON.parse(JSON.stringify(dataOb));//if there is an update only the purchaseOrder variable will be modified since its the passing object in frontend 
  oldPurchaseOrder = JSON.parse(JSON.stringify(dataOb));

  console.log("Edit", dataOb, index);
  //tableBodyPurchaseOrder.children[index].style.border="2px solid black";

  //refill the form
  //txtGrandTotal.value = dataOb.grandtotal; it will automatically refill by calling the refreshPurchaseOrderInnerForm() function at end
  txtGrandTotal.disabled="disabled";
  txtRequiredDate.value = dataOb.required_date;//static
  txtRequiredDate.classList.remove("is-invalid");
  txtRequiredDate.classList.add("is-valid");


  //supplier select list
  supplierSelect.value = JSON.stringify(dataOb.supplier_id); //object ekk nisa (dynamic ewge)
  supplierSelect.disabled="disabled";//disabling supplier selection at refill/edit need to enable in refreshform function
  supplierSelect.classList.remove("is-invalid");
  supplierSelect.classList.add("is-valid");

  quotationSelect.value = JSON.stringify(dataOb.quotation_id); //dynmaic (quotation_id is the foreign key in pod table)
  quotationSelect.disabled="disabled";//disable at refill enable at refresh
  quotationSelect.classList.remove("is-invalid");
  quotationSelect.classList.add("is-valid");

  purchaseOrderStatusSelect.value = JSON.stringify(dataOb.purchase_order_status_id); //dynmaic

  //required nati nisa
  if (dataOb.txtNote == null) {
    txtNote.value = " ";
  } else {
    txtNote.value = dataOb.note;
  }
 
  $("#purchaseOrderFormModal").modal("show"); //show modal

  //disable submit button,Enable update button in edit function
  purchaseSubmitButton.style.display = "none";
  purchaseUpdateButton.removeAttribute("style");
  refreshPurchaseOrderInnerForm();

  
 
};

//function for delete row
const purchaseOrderDelete = (dataOb, index) => {
  console.log("Delete", dataOb, index);



   //need to get user confirmation
    let userConfirmation=window.confirm("Are You sure you want to delete the following Purchase Order .. ?"+
      //"\nSupplier :"+dataOb.supplier_id.name +
      "\nQuotation No :"+dataOb.quotation_id.quotation_no +
      "\nRequired Date :"+dataOb.required_date +
      "\nGrand Total :"+dataOb.grandtotal +
      "\nPurchase Order Status :"+dataOb.purchase_order_status_id.name 

    );
    if (userConfirmation) {
       //Call delete service
       let deleteResponse=getHTTPServiceRequest("/purchaseorder/delete","DELETE",dataOb);
      if (deleteResponse=="OK") {

        window.alert("Delete Successfull !..\n");
        refreshPurchaseOrderTable();//refresh purchase order table
        // window.location.reload(); full browser reload -->reload every image&...
        refreshPurchaseOrderForm();//refresh purchase order form

      } else {
        window.alert("Submission Failed !..\n"+deleteResponse);
      }
    }
};

//function for view/print row
const purchaseOrderView = (dataOb, index) => {
  console.log("View", dataOb, index);

  //option 1

  //how to open a new tab and enter html tags and styles using js

  /* 
  let newTab=window.open();
  let printTab="<head><title>Employee Print</title>"+
  "<link rel='stylesheet' href='../resources/bootstrap-5.2.3/css/bootstrap.min.css'></head>"+
  "<body><table class='table table-striped'><tr><th>Full Name</th><td>"+dataOb.fullname+"</td></tr></table></body>";
  newTab.document.write(printTab);

  setTimeout(()=>{
    //what should happen after 1500 ms
    newTab.stop();
    newTab.print();
    newTab.close();
  },1500) */

  //option 2 view in  a modal

  //pod_supllierName.innerText=dataOb.supplier_id.name;
  pod_supplier.innerText = dataOb.supplier_id.suppliername;
  pod_quotation.innerText = dataOb.quotation_id.quotation_no;
  Pod_required_date.innerText = dataOb.required_date;
  Pod_status.innerText = dataOb.purchase_order_status_id.name;


  $("#purchaseOrderFormModalView").modal("show"); //show modal
};

//option 2 Print row new tab open
const printButtonRow = () => {
  let newTab = window.open();
  let printTab =
"<head><title>Purchase Order Print</title>" +
"<link rel='stylesheet' href='bootstrap-5.2.3/css/bootstrap.min.css'>" +
"</head>" +
"<body>" +
"<h4 class='text-center mt-3'>Purchase Order Print</h4>" +
"<div class='container mt-3'>" +
"  <div class='row justify-content-center'>" +
"    <div class='col-md-8'>" + purchaseOrderTableView.outerHTML + "</div>" +
"  </div>" +
"</div>" +
"</body>";
  newTab.document.write(printTab);

  setTimeout(() => {
    //what should happen after 1500 ms
    newTab.stop();
    newTab.print();
    newTab.close();
  }, 1500);
};

/* *************************************************************************** */
/* **************************  FORM *********************************************/

//refresh form area
const refreshPurchaseOrderForm = () => {
  //static element only is cleared
  //Cleaning the values(select list not needed dynamic nm )

  formPurchaseOrder.reset(); //clearing the form values

  purchaseOrder = new Object(); //creating a new object
  purchaseOrder.purchaseOrderHasItemList = new Array();
  supplierSelect.disabled="";//disabling supplier selection at refill/edit need to enable in refreshform function
  quotationSelect.disabled="";//enable at refresh

   //refilling the dynamic elements
   let supplier = getServiceRequest("/supplier/findall"); //calling the ajax request func in coommon func.js

   //calling reusable function for select list(elementid,massege,dtaalistname,prportyname of the datalist)
    fillDataintoSelect(
      supplierSelect,
      "Select Supplier",
      supplier,
      "suppliername"
    );

  //refilling the dynamic elements
  let quotation = getServiceRequest("/quotation/findall"); //calling the ajax request func in coommon func.js

  //purchase order status select list
  let purchaseOrderStatus = getServiceRequest("/purchaseorderstatus/findall"); //calling the ajax request func in coommon func.js

  //calling reusable function for select list(elementid,massege,dtaalistname,prportyname of the datalist)
  fillDataintoSelect(
    quotationSelect,
    "Select Quotation",
    quotation,
    "quotation_no"
  );
  //calling reusable function for select list(elementid,massege,dtaalistname,prportyname of the datalist)
  fillDataintoSelect(
    purchaseOrderStatusSelect,
    "Select Purchase Order Status",
    purchaseOrderStatus,
    "name"
  );

  //set purchase order status aailable when loading form
  purchaseOrderStatusSelect.value = JSON.stringify(purchaseOrderStatus[0]); //[0] is "available" in purchase order status table
  purchaseOrder.purchase_order_status_id = JSON.parse(
    purchaseOrderStatusSelect.value
  );

  //Need to clear the colors

  setToDefault([
    supplierSelect,
    quotationSelect,
    txtRequiredDate,
    txtGrandTotal,
    txtNote,
    purchaseOrderStatusSelect,
  ]);

  /*  txtFullname.classList.remove("is-valid");
  //  txtFullname.style.border="1px solid #ced4da";
  civilStatus.classList.remove("is-valid");
  //  civilStatus.style.border="1px solid #ced4da"; */

  //set color for purchase order Status
  purchaseOrderStatusSelect.classList.remove("is-invalid");
  purchaseOrderStatusSelect.classList.add("is-valid");

  //disable update button,Enable submit button

  purchaseUpdateButton.style.display = "none";
  purchaseSubmitButton.removeAttribute("style");

  //set min max value for require date[YYYY-MM-DD]
  let currentDate = new Date();
  let currentMonth = currentDate.getMonth() + 1; //getMonth gives [0-11] so we need to add 1
  if (currentMonth < 10) {
    currentMonth = "0" + currentMonth;
  }
  let CurrentDay = currentDate.getDate(); //[1-31]
  if (CurrentDay < 10) {
    CurrentDay = "0" + CurrentDay;
  }

  txtRequiredDate.min =
    currentDate.getFullYear() + "-" + currentMonth + "-" + CurrentDay;

  currentDate.setDate(currentDate.getDate() + 14); //adding 14 days to current date to get the max date

  let maximumcurrentMonth = currentDate.getMonth() + 1; //getMonth gives [0-11] so we need to add 1
  if (maximumcurrentMonth < 10) {
    maximumcurrentMonth = "0" + maximumcurrentMonth;
  }
  let maximumCurrentDay = currentDate.getDate(); //[1-31]
  if (maximumCurrentDay < 10) {
    maximumCurrentDay = "0" + maximumCurrentDay;
  }

  txtRequiredDate.max =
    currentDate.getFullYear() +
    "-" +
    maximumcurrentMonth +
    "-" +
    maximumCurrentDay;

  refreshPurchaseOrderInnerForm();
};

//check form errors

const checkPurchaseOrderFormErrors = () => {
  let errors = "";
  if (purchaseOrder.quotation_id == null) {
    errors = errors + "Please Select Quotation\n";
  }
  if (purchaseOrder.required_date == null) {
    errors = errors + "Please Enter  Required Date\n";
  }
  if (purchaseOrder.grandtotal == null) {
    errors = errors + "Please Enter Grand Total\n";
  }
  if (purchaseOrder.purchase_order_status_id == null) {
    errors = errors + "Please Select  Purchase Order Status\n";
  }
  if (purchaseOrder.purchaseOrderHasItemList.length == 0) {
    errors = errors + "Please Select Purchase Order Item\n";
  }

  return errors;
};

//purchase order form submit event Function
const purchaseOrderSubmitButton = () => {
  console.log(purchaseOrder);

  //check form error for required fields
  let errors = checkPurchaseOrderFormErrors(); //call the error function
  if (errors == "") {
    //no errors
    //need to get user confirmation
    let userConfirmation = window.confirm(
      "Are You sure you want to add the following Purchase Order .. ?" +
        "\nRequired Date :" +
        purchaseOrder.required_date +
        "\nGrand Total:" +
        purchaseOrder.grandtotal +
        "\nQuotation no :" +
        purchaseOrder.quotation_id.quotation_no +
        "\nPurchase Order Status:" +
        purchaseOrder.purchase_order_status_id.name
    );
    if (userConfirmation) {
      //Call post service(url,method,data) data means object name-->purchaseOrder
      let postServiceResponse = getHTTPServiceRequest(
        "/purchaseorder/insert",
        "POST",
        purchaseOrder
      );
      if (postServiceResponse == "OK") {
        window.alert("Submission Successfull !..\n");
        refreshPurchaseOrderTable(); //refresh purchaseorder table
        // window.location.reload(); full browser reload -->reload every image&...
        refreshPurchaseOrderForm(); //refresh purchaseorder form
        $("#purchaseOrderFormModal").modal("hide"); //Hide modal
      } else {
        window.alert("Submission Failed !..\n" + postServiceResponse);
      }
    }
  } else {
    window.alert("Form Contains Following Errors !..\n" + errors);
  }

  // console.log(purchaseorder);

  refreshPurchaseOrderTable();
};

const checkPurchaseOrderFromUpdates = () => {
  let updates = "";

  console.log(purchaseOrder);
  console.log(oldPurchaseOrder);//if there is an update only the purchaseOder variable will be modified since its the passing object in frontend 

  if (purchaseOrder != null && oldPurchaseOrder != null) {
   
    if (purchaseOrder.grandtotal != oldPurchaseOrder.grandtotal) {
      updates =
        updates +
        "Grand Total changed from " +
        oldPurchaseOrder.grandtotal +
        " into " +
        purchaseOrder.grandtotal +
        "\n";
    }
    
    if (purchaseOrder.required_date != oldPurchaseOrder.required_date) {
      updates =
        updates +
        "Required Date changed from " +
        oldPurchaseOrder.required_date +
        " into " +
        purchaseOrder.required_date +
        "\n";
    }
    if (purchaseOrder.purchase_order_status_id.name != oldPurchaseOrder.purchase_order_status_id.name) {
      updates =
        updates +
        "Purchase Order Status changed from " +
        oldPurchaseOrder.purchase_order_status_id.name +
        " into " +
        purchaseOrder.purchase_order_status_id.name +
        "\n";
    }
  }

  return updates;
};


//purchase order  Form update event function
const purchaseOrderUpdateButton = () => {
  //check for form eroors
  let errors = checkPurchaseOrderFormErrors();
  if (errors == "") {
    //check for purchase order Form updates
    let updates = checkPurchaseOrderFromUpdates();
    if (updates == "") {
      window.alert("Form Contains No Updates..!");
    } else {
      //Need user confirmation
      let userConfirmation = window.confirm(
        "Are you Sure you want to update the following changes ?\n" + updates
      );
      if (userConfirmation) {
        //call put service
 
        let putServiceResponse = getHTTPServiceRequest(
          "/purchaseorder/update",
          "PUT",
          purchaseOrder
        );
       
        
        if (putServiceResponse == "OK") {
          window.alert("Form update Successfull..!");
          refreshPurchaseOrderForm();
          $("#purchaseOrderFormModal").modal("hide"); //Hide modal
        } else {
          window.alert("Form Update Unsucessfull..!\n" + putServiceResponse);
        }
      }
    }
  } else {
    window.alert("Form Contains Following Errors !..\n" + errors);
  }

  refreshPurchaseOrderTable();
};

//purchase order  Form Delete function
const DeletePurchaseOrder = (dataOb, rowIndex) => {
  refreshPurchaseOrderTable();
};

/* *************************************************************************** */
/* ************************** INNER FORM *********************************************/

//define function to filter item list by existance of inner table(call this in item select list in purchaseorder.html)
const filterItemListbyExistance = () => {

 // let selectedItem = JSON.parse(itemSelect.value);//dynamic nm json parse krnn one
    selectedItem = purchaseOrderHasItem.item_id;

    // find the index of a specific item in a list inside a purchaseorder object.
  let extIndex = purchaseOrder.purchaseOrderHasItemList
    .map((poditem) => poditem.item_id.id)
    .indexOf(selectedItem.id);

   /*
   purchaseOrder.purchaseOrderHasItemList
      This is assumed to be an array (e.g., a list of items in a purchase order).

      Example structure:

      purchaseOrderHasItemList = [
        { item_id: { id: 101 } },
        { item_id: { id: 202 } },
        { item_id: { id: 303 } }
      ];
      2. .map((poditem) => poditem.item_id.id)
      This transforms the array into just a list of item IDs.

      From the above example, you'd get:

      [101, 202, 303]
      .indexOf(selectedItem.id)
      This finds the index of selectedItem.id in the array of item IDs.

      If selectedItem.id = 202, the result would be 1.

      let extIndex = ...
      Stores the index in a variable called extIndex.

      If the selectedItem.id is not found, extIndex will be -1. */

  if (extIndex != -1) {
    //index exists
    window.alert("Selected item already exists....!");
    refreshPurchaseOrderInnerForm();
  } else {
    //need to autaomatically add the value for unit price if have
    console.log(JSON.parse(quotationSelect.value).id);
    console.log("selectedItem",selectedItem);
    
    let podUnitPrice=getServiceRequest("/quotation/unitpricebyitem/"+JSON.parse(quotationSelect.value).id +"/"+selectedItem.id);
    txtUnitPrice.value = parseFloat(podUnitPrice).toFixed(2); //purchase_price here is item table purchase price
    purchaseOrderHasItem.purchase_price = parseFloat(txtUnitPrice.value).toFixed(2); //purchase_price here is unit price podhasitemtable purchase_price

    //set color for purchase order unit price
    txtUnitPrice.classList.remove("is-invalid");
    txtUnitPrice.classList.add("is-valid");
  }
};

//define fnction to filter quotations by supplier and required date
const filterQuotationBySupplierandReqDate=()=>{
  //get the quotations
  console.log(txtRequiredDate.value);
  
  let quotations = getServiceRequest("/quotation/qlistbysupplierandreqdate/" + JSON.parse(supplierSelect.value).id+"/"+txtRequiredDate.value); //calling the ajax request func in coommon func.js
  //calling reusable function for select list(elementid,massege,dtaalistname,prportynameOne)
  console.log(quotations);
  
  fillDataintoSelect(
    quotationSelect,
    "Select Quotation ",
    quotations,
    "quotation_no",
  ); 
}

//define function to filter item list by quotation (need to call this function at supplier dropdown in quotation.html)
const filterItemListbyQuotation = () => {
  //get the items
  let items = getServiceRequest("/item/listbyquotation/" + JSON.parse(quotationSelect.value).id); //calling the ajax request func in coommon func.js

  //calling reusable function for select list(elementid,massege,dtaalistname,prportynameOne,proprtynameTwo of the datalist)
 /*  fillDataintoSelectTwo(
    itemSelect,
    "Select Item",
    items,
    "item_no",
    "itemname"
  ); */

  console.log(items);
  

   //filling to item datalist
  //calling reusable function for data list(elementid,dtaalistname,prportynameOne,proprtynameTwo of the datalist)
 fillDataintoDataList(
    itemList,
    items,
    "item_no",
    "itemname"
  );

};

//filter quantity based on quatation and item selected -->returns just a number not a list-->need to calll in dtalist in html
const filterQtybyQRandItem=()=>{
  console.log(selectedItem);
  
  let qtys = getServiceRequest("/qt/qtybyquotationanditemid/" + JSON.parse(quotationSelect.value).id+"/"+selectedItem.id); 

  console.log(qtys);
  txtQty.value=parseInt(qtys);
  txtQty.classList.remove("is-invalid");
  txtQty.classList.add("is-valid");
  purchaseOrderHasItem.qty=parseInt(txtQty.value);
  calculateLinePrice();
  
}


//define function to calculate line price(unit price*quantity)-->call function at quantity input field onkeyip
const calculateLinePrice = () => {
  if (txtQty.value > 0) {
    //calculating line price
    let linePrice = (
      parseFloat(txtQty.value) * parseFloat(txtUnitPrice.value)
    ).toFixed(2);

    txtLinePrice.value = linePrice;
    purchaseOrderHasItem.line_price = linePrice;
    //set color
    txtLinePrice.classList.remove("is-invalid");
    txtLinePrice.classList.add("is-valid");
  } else {
    purchaseOrderHasItem.qty = null;
    purchaseOrderHasItem.line_price = null;
    //set color for purchase order quantity
    txtQty.classList.remove("is-valid");
    txtQty.classList.add("is-invalid");

    //default color for line price since no value for qty
    // txtLinePrice.style.border="1px solid #ced4da";
    txtLinePrice.classList.remove("is-valid");
    txtLinePrice.classList.remove("is-invalid");
    txtLinePrice.value = "";
  }
};

//Funtion for inner form
const refreshPurchaseOrderInnerForm = () => {
  //creating a new object
  purchaseOrderHasItem = new Object();

  //get the items
    items = [];

  console.log(quotationSelect.value);
  
  if (quotationSelect.value != "") {
    //get the items
    items = getServiceRequest("/item/listbyquotation/" + JSON.parse(quotationSelect.value).id); //calling the ajax request func in coommon func.js
  } else {
    //get the items
    items = getServiceRequest("/item/findall"); //calling the ajax request func in coommon func.js
  }

  //calling reusable function for select list(elementid,massege,dtaalistname,prportynameOne,proprtynameTwo of the datalist)
 /*  fillDataintoSelectTwo(
    itemSelect,
    "Select Item",
    items,
    "item_no",
    "itemname"
  ); */

   //filling to item datalist
    //calling reusable function for data list(elementid,dtaalistname,prportynameOne,proprtynameTwo of the datalist)
 fillDataintoDataList(
    itemList,
    items,
    "item_no",
    "itemname"
  );

  //cant reset because it will reset the main form also
  //so need to clear the values
    textItemName.value="";//clearing datalist
  // itemSelect.disabled = "";
  txtUnitPrice.value = "";
  txtUnitPrice.disabled = "disabled";
  txtQty.value = "";
  txtLinePrice.value = "";
  txtLinePrice.disabled = "disabled";
  //itemSelect.value="";//dynamic no need to clear values

  //Need to clear the colors
  setToDefault([textItemName, txtUnitPrice, txtQty, txtLinePrice]);//textItemName datalist inpufield id


  //disable update button,Enable submit button
  purchaseInnerItemupdateButton.classList.add("d-none");
  purchaseInnerItemsubmitButton.classList.remove("d-none");

  //refresh inner table

  //Datatypes
  //string --> date/string/number
  //function-->object/array/boolean
  //decimal-->decimal/price
  let columnList = [
    { columnName: getPurchaseOrderItemName, dataType: "function" },
    { columnName: "purchase_price", dataType: "decimal" },
    { columnName: "qty", dataType: "string" },
    { columnName: "line_price", dataType: "decimal" },
  ];

  //call the common function to fill data into table(tablebody id,datalist name,column list,edit parameter,
  //delete parameter,view parameter,button visibility)
  // fillDataintoInnerTable(purchaseOrderItemTableBody,purchaseorders,columnList,purchaseOrderItemEdit,purchaseOrderItemDelete,purchaseOrderItemView,true);
  fillDataintoInnerTable(
    purchaseOrderItemTableBody,
    purchaseOrder.purchaseOrderHasItemList,
    columnList,
    purchaseOrderItemEdit,
    purchaseOrderItemDelete,
    true
  );

  //setting value for grand total
  let grandTotal = 0.0;
  for (const orderitem of purchaseOrder.purchaseOrderHasItemList) {
    grandTotal = parseFloat(grandTotal) + parseFloat(orderitem.line_price);
  }
  if (grandTotal != 0.0) {
    console.log(grandTotal);
    txtGrandTotal.value = grandTotal.toFixed(2); //two decimal points
    purchaseOrder.grandtotal = txtGrandTotal.value;

    //set color for grand total
    txtGrandTotal.classList.remove("is-invalid");
    txtGrandTotal.classList.add("is-valid");
  } else {
    console.log("zero", grandTotal);
    //set color for grand total
    txtGrandTotal.classList.remove("is-invalid");
    txtGrandTotal.classList.remove("is-valid");
    txtGrandTotal.value = "";
  }
};

//function to get purchase order item name
const getPurchaseOrderItemName = (dataOb) => {
  return dataOb.item_id.itemname;
};

//function for inner form  edit/refill
const purchaseOrderItemEdit = (dataOb, index) => {

  innerFormIndex=index;

    //if there is an update only the purchaseOrderHasItem variable will be modified since its the passing object in frontend 
  purchaseOrderHasItem = JSON.parse(JSON.stringify(dataOb)); // Working copy for editing
  oldPurchaseOrderHasItem = JSON.parse(JSON.stringify(dataOb)); // Original copy for comparison

  /* JSON.stringify(dataOb) converts the object to a JSON string
JSON.parse() converts that JSON string back to a JavaScript object
This creates a completely new object with the same data */

  //get the items
  let items = getServiceRequest("/item/itemlist"); //calling the ajax request func in coommon func.js

  //calling reusable function for select list(elementid,massege,dtaalistname,prportynameOne,proprtynameTwo of the datalist,selected itemid)
 /*  fillDataintoSelectTwo(
    itemSelect,
    "Select Item",
    items,
    "item_no",
    "itemname",
    purchaseOrderHasItem.item_id.item_no
  );
 */

  //filling to item datalist
  textItemName.value=purchaseOrderHasItem.item_id.item_no+' '+purchaseOrderHasItem.item_id.itemname;

  //itemSelect.disabled = "disabled"; //disabling item selection
  textItemName.disabled = "disabled"; //disabling item selection
  textItemName.classList.remove("is-invalid");
  textItemName.classList.add("is-valid");

 
  txtUnitPrice.value = parseFloat(purchaseOrderHasItem.purchase_price);
  txtQty.value = purchaseOrderHasItem.qty;
  txtLinePrice.value = parseFloat(purchaseOrderHasItem.line_price);

  //disable submit button,Enable update button
  purchaseInnerItemupdateButton.classList.remove("d-none");
  purchaseInnerItemsubmitButton.classList.add("d-none");
};

//function for inner form delete
const purchaseOrderItemDelete = (dataOb, index) => {
  //need to get user confirmation
  let userConfirmation = window.confirm(
    "Are You sure you want to Remove the following Item .. ?" +
      "\nItem Name :" +
      dataOb.item_id.itemname +
      "\n Unit Price :" +
      dataOb.purchase_price +
      "\nQuantity :" +
      dataOb.qty +
      "\nLine Price:" +
      dataOb.line_price
  );
  if (userConfirmation) {
    window.alert("Delete Successfull !..\n");
//remove an existing item record from the inner form list (purchaseOrderHasItemList) if it already exists — based on item_id.
    let extIndex = purchaseOrder.purchaseOrderHasItemList
      .map((orderitem) => orderitem.item_id.id)//Extracts a list of all item_id.id values from the purchaseOrderHasItemList (ex:-[101, 102, 103])
      .indexOf(dataOb.item_id.id);//Searches for the index of the item ID from dataOb in that list.Returns:0, 1, 2, etc., if found,-1 if not found
    if (extIndex != -1) {
      purchaseOrder.purchaseOrderHasItemList.splice(extIndex, 1);//Removes one item at the index extIndex.Effectively deletes that item from the inner form list.
    }
    // window.location.reload(); full browser reload -->reload every image&...
  } else {
    window.alert("Form Contains Errors !..\n");
  }

  refreshPurchaseOrderInnerForm(); //refresh purchase order inner form
};

//function for inner form submit
const purchaseOrderItemSubmitButton = () => {
  console.log(purchaseOrderHasItem);

  //need to get user confirmation
  let userConfirmation = window.confirm(
    "Are You sure you want to add the following Item .. ?" +
      "\nItem Name :" +
      purchaseOrderHasItem.item_id.itemname +
      "\nUnit Price :" +
      purchaseOrderHasItem.purchase_price +
      "\nQuantity :" +
      purchaseOrderHasItem.qty +
      "\nLine Price:" +
      purchaseOrderHasItem.line_price
  );
  if (userConfirmation) {
    window.alert("Submission Successfull !..\n");
    purchaseOrder.purchaseOrderHasItemList.push(purchaseOrderHasItem);
    // window.location.reload(); full browser reload -->reload every image&...
    refreshPurchaseOrderInnerForm(); //refresh purchase order inner form
  } else {
    window.alert("Form Contains Errors !..\n");
  }

  // console.log(employee);

  refreshPurchaseOrderInnerForm();
};

//function for innerform update
const purchaseOrderItemUpdateButton = () => {
  console.log(purchaseOrderHasItem);

  if (purchaseOrderHasItem.qty != oldPurchaseOrderHasItem.qty) {
    //need to get user confirmation
    let userConfirmation = window.confirm(
      "Are You Sure you want to update the following changes.. ?" +
        "\nQuantity Changed from :" +oldPurchaseOrderHasItem.qty+" to "+purchaseOrderHasItem.qty
    );

    if (userConfirmation) {
      window.alert("Update Successfull !..\n");
      purchaseOrder.purchaseOrderHasItemList[innerFormIndex]=purchaseOrderHasItem;
      // window.location.reload(); full browser reload -->reload every image&...
      refreshPurchaseOrderInnerForm(); //refresh purchase order inner form
    } else {
      window.alert("Form Contains Errors !..\n");
    }
  }
  else{
    window.alert("Form Contains No Updates..!");
  }
  refreshPurchaseOrderInnerForm();
};



