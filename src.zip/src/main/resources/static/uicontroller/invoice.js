//Browser load event
window.addEventListener("load", () => {
  console.log("load");

  //enable tooltip
  $('[data-bs-toggle="tooltip"]').tooltip();

  refreshInvoiceTable();

  refreshInvoiceForm();


});

//refresh table area
const refreshInvoiceTable = () => {
  //
  // actionButtons.style.display = "none"; // added for table style 3
  //table

  //calling the ajax request func in coommon func.js to get data
  invoices = getServiceRequest("/invoice/findall");

  //Datatypes
  //string --> date/string/number
  //function-->object/array/boolean
  //decimal-->decimal/price
  let columnList = [
    { columnName: "invoice_no", dataType: "string" },
    { columnName: "customer_name", dataType: "string" },
    { columnName: getItemList, dataType: "function" },
    { columnName: "total_amount", dataType: "decimal" },
    { columnName: "net_amount", dataType: "decimal" },

  ];

  //call the common function to fill data into table(tableBodyId,dataList,columnList,viewFunction,buttonVisibility=true)
  // fillDataintoTable(invoiceTableBody,invoices,columnList,InvoiceView,true);
  fillDataintoTableFour(
    invoiceTableBody,
    invoices,
    columnList,
    InvoiceView,
    true
  );
  // fillDataintoTableThree(invoiceTableBody,invoices,columnList,true);



  $("#invoiceTable").DataTable();
};

//function to get Item List
const getItemList = (dataOb) => {
  let invoiceHasInventoryList = dataOb.invoiceHasInventoryList;
  console.log(invoiceHasInventoryList.length);
  console.log(invoiceHasInventoryList);
  

  let itemNames = "";
  invoiceHasInventoryList.forEach((itemObj, index) => {
    const itemName = itemObj.item_inventory_id.item_id.itemname;
    if (invoiceHasInventoryList.length - 1 == index) {
      itemNames = itemNames + itemName; //remove the comma if its the last value
    } else {
      itemNames = itemNames + itemName + ",";
    }
  });
  return itemNames;
};

//function for view/print row
const InvoiceView = (dataOb, index) => {
  console.log("View", dataOb, index);

  //option 1

  //how to open a new tab and enter html tags and styles using js

  /* 
  let newTab=window.open();
  let printTab="<head><title>Employee Print</title>"+
  "<link rel='stylesheet' href='../resources/bootstrap-5.2.3/css/bootstrap.min.css'></head>"+
  "<body><table class='table table-striped'><tr><th>Full Name</th><td>"+dataOb.fullname+"</td></tr></table></body>";
  newTab.document.write(printTab);

  setTimeout(()=>{
    //what should happen after 1500 ms
    newTab.stop();
    newTab.print();
    newTab.close();
  },1500) */

  //option 2 view in  a modal

  //pod_supllierName.innerText=dataOb.supplier_id.name;
  inv_no.innerText = dataOb.invoice_no;
  inv_cus_name.innerText = dataOb.customer_name;
  inv_tot_amount.innerText = dataOb.total_amount;
  inv_dis_amount.innerText = dataOb.discount_amount;
  inv_net_amount.innerText = dataOb.net_amount;

  $("#invoiceFormModalView").modal("show"); //show modal
};

//option 2 Print row new tab open
const printButtonRow = () => {
  let newTab = window.open();
  let printTab =
    "<head><title>Invoice Print</title>" +
    "<link rel='stylesheet' href='bootstrap-5.2.3/css/bootstrap.min.css'>" +
    "</head>" +
    "<body>" +
    "<h4 class='text-center mt-3'>Invoice Print</h4>" +
    "<div class='container mt-3'>" +
    "  <div class='row justify-content-center'>" +
    "    <div class='col-md-8'>" +
    invoiceTableView.outerHTML +
    "</div>" +
    "  </div>" +
    "</div>" +
    "</body>";
  newTab.document.write(printTab);

  setTimeout(() => {
    //what should happen after 1500 ms
    newTab.stop();
    newTab.print();
    newTab.close();
  }, 1500);
};

/* *************************************************************************** */
/* **************************  FORM *********************************************/

//refresh form area
const refreshInvoiceForm = () => {
  //static element only is cleared
  //Cleaning the values(select list not needed dynamic nm )

  formInvoice.reset(); //clearing the form values

  invoice = new Object(); //creating a new object
  loyaltypoint = new Object(); //creating a new object
  customerPayment = new Object(); //creating a new object
  invoice.invoiceHasInventoryList = new Array();
  customerSelect.disabled = ""; //disabling customer selection at refill/edit need to enable in refreshform function

  //refilling the dynamic elements
  let customer = getServiceRequest("/customer/findall"); //calling the ajax request func in coommon func.js

  //calling reusable function for select list(elementid,massege,dtaalistname,prportyname of the datalist)
  fillDataintoSelect(
    customerSelect,
    "Select Customer",
    customer,
    "customername"
  );

  //customer pay methods select list
  let customerPaymentMethod = getServiceRequest("/customerpaymentmethod/findall"); //calling the ajax request func in coommon func.js
  console.log(customerPaymentMethod);

  //calling reusable function for select list(elementid,massege,dtaalistname,prportyname of the datalist)
  fillDataintoSelect(
    paymentMethodSelect,
    "Select Payment Method",
    customerPaymentMethod,
    "name"
  );


  txtCusPayBalanceAmount.disabled="disabled";
  txtNetAmount.disabled="disabled";
  txtDiscountAmount.disabled="disabled";
  txtTotalAmount.disabled="disabled";
  txtCusPayBalanceAmount.disabled="";

  //Need to clear the colors
  setToDefault([
    customerSelect,
    txtTotalAmount,
    txtDiscountAmount,
    txtNetAmount,
    txtNote,
    txtCustomername,
    txtContactNo,
    txtCusPayBalanceAmount,
    paymentMethodSelect,
    txtPaidAmount
  ]);

  /*  txtFullname.classList.remove("is-valid");
  //  txtFullname.style.border="1px solid #ced4da";
  civilStatus.classList.remove("is-valid");
  //  civilStatus.style.border="1px solid #ced4da"; */

  //disable update button,Enable submit button

  invoiceUpdateBtnn.style.display = "none";
  invoiceSubmitBtn.removeAttribute("style");

  refreshInvoiceInnerForm();
};

//check form errors
const checkInvoiceFormErrors = () => {
  let errors = "";
  if (invoice.total_amount == null) {
    errors = errors + "Please Select Total Amount\n";
  }
  if (invoice.net_amount == null) {
    errors = errors + "Please Enter  Net Amount\n";
  }
  if (invoice.discount_amount == null) {
    errors = errors + "Please Enter Discount Amount\n";
  }
  /*  if (invoice.purchase_order_status_id == null) {
    errors = errors + "Please Select  Purchase Order Status\n";
  } */
  if (invoice.invoiceHasInventoryList.length == 0) {
    errors = errors + "Please Select Invoice has Inventory\n";
  }

  //customername,contact no

  return errors;
};

//invoice form submit event Function
const invoiceSubmitButton = () => {
  console.log(invoice);
  console.log(customerPayment);
  customerPayment.invoice_id=invoice;

  //check form error for required fields
  let errors = checkInvoiceFormErrors(); //call the error function
  if (errors == "") {
    //no errors
    //need to get user confirmation
    let userConfirmation = window.confirm(
      "Are You sure you want to add the following Invoice .. ?" +
        "\nCustomer Name :" +
        invoice.customer_name +
        "\nContact No :" +
        invoice.contact_no +
        "\nTotal Amount :" +
        invoice.total_amount +
        "\nDiscount Amount :" +
        invoice.discount_amount +
        "\nNet Amount :" +
        invoice.net_amount +
        "\nPaid Amount :" +
        customerPayment.paid_amount+
        "\nBalance Amount :" +
        customerPayment.balance_amount+
        "\nPayment Method :" +
        customerPayment.customer_payment_method_id.name

    );
    if (userConfirmation) {
      //Call post service(url,method,data) data means object name-->invoice
      let postServiceResponse = getHTTPServiceRequest(
        "/customerpayment/insert",
        "POST",
        customerPayment
      );
      if (postServiceResponse == "OK") {
        window.alert("Submission Successfull !..\n");
        refreshInvoiceTable(); //refresh invoice table
        // window.location.reload(); full browser reload -->reload every image&...
        refreshInvoiceForm(); //refresh invoice form
         
        $("#invoiceFormModal").modal("hide"); //Hide modal
          // $("#customerPaymentModal").modal("show"); //show customer payment modal
      } else {
        window.alert("Submission Failed !..\n" + postServiceResponse);
      }
    }
  } else {
    window.alert("Form Contains Following Errors !..\n" + errors);
  }

  // console.log(invoice);

  refreshInvoiceTable();
};

const checkInvoiceFormUpdates = () => {
  let updates = "";

  console.log(invoice);
  console.log(oldInvoice); //if there is an update only the invoice variable will be modified since its the passing object in frontend

  if (invoice != null && oldInvoice != null) {
    if (invoice.total_amount != oldInvoice.total_amount) {
      updates =
        updates +
        "Total Amount changed from " +
        oldInvoice.total_amount +
        " into " +
        invoice.total_amount +
        "\n";
    }
    if (invoice.discount_amount != oldInvoice.discount_amount) {
      updates =
        updates +
        "Discount Amount changed from " +
        oldInvoice.discount_amount +
        " into " +
        invoice.discount_amount +
        "\n";
    }
    if (invoice.net_amount != oldInvoice.net_amount) {
      updates =
        updates +
        "Net Amount changed from " +
        oldInvoice.net_amount +
        " into " +
        invoice.net_amount +
        "\n";
    }
    if (invoice.paid_amount != oldInvoice.paid_amount) {
      updates =
        updates +
        "Paid Amount changed from " +
        oldInvoice.paid_amount +
        " into " +
        invoice.paid_amount +
        "\n";
    }

    if (invoice.customer_name != oldInvoice.customer_name) {
      updates =
        updates +
        "Customer Name changed from " +
        oldInvoice.customer_name +
        " into " +
        invoice.customer_name +
        "\n";
    }

    if (invoice.contact_no != oldInvoice.contact_no) {
      updates =
        updates +
        "Contact No changed from " +
        oldInvoice.contact_no +
        " into " +
        invoice.contact_no +
        "\n";
    }
  }

  return updates;
};

//invoice Form update event function
const invoiceUpdateButton = () => {
  //check for form eroors
  let errors = checkInvoiceFormErrors();
  if (errors == "") {
    //check for invoice Form updates
    let updates = checkInvoiceFormUpdates();
    if (updates == "") {
      window.alert("Form Contains No Updates..!");
    } else {
      //Need user confirmation
      let userConfirmation = window.confirm(
        "Are you Sure you want to update the following changes ?\n" + updates
      );
      if (userConfirmation) {
        //call put service

        let putServiceResponse = getHTTPServiceRequest(
          "/invoice/update",
          "PUT",
          invoice
        );

        if (putServiceResponse == "OK") {
          window.alert("Form update Successfull..!");
          refreshInvoiceForm();
          $("#invoiceFormModal").modal("hide"); //Hide modal
        } else {
          window.alert("Form Update Unsucessfull..!\n" + putServiceResponse);
        }
      }
    }
  } else {
    window.alert("Form Contains Following Errors !..\n" + errors);
  }

  refreshInvoiceTable();
};

//purchase order  Form Delete function
const DeleteInvoice = (dataOb, rowIndex) => {
  refreshInvoiceTable();
};

//check discount for main form dicount price-->Based on customer loyalty points,amount-->only to customer with accounts
//calll this inside grandtotal generate function
const discountByLoyaltyPoints = () => {
  console.log(customerSelect.value);
//when customer is selected
  if (customerSelect.value != "") {
    let selectedCustomer = JSON.parse(customerSelect.value);
    console.log("selectedCustomer", selectedCustomer);
    //let selectedCustomer=JSON.parse(customerSelect.value);// Converts the selected value (which is a stringified object) into a usable JavaScript object
    console.log("total_amount", invoice.total_amount);
    //get the loyalty points
    let loyaltyDiscounts = getServiceRequest(
      "/loyalty/listbypointsandtotalamount/" +
        selectedCustomer.loyalty_point +
        "/" +
        invoice.total_amount
    );

    console.log("loyaltyDiscounts", loyaltyDiscounts);

    if (loyaltyDiscounts.length > 0) {
      let rate = loyaltyDiscounts[0].discount_rate; //get the discount rate
      if (rate > 0.0) {
        let disAmount = (parseFloat(txtTotalAmount.value) *(parseFloat(rate) / 100)).toFixed(2);
        txtDiscountAmount.value = disAmount;
        invoice.discounted_price = parseFloat(txtDiscountAmount.value).toFixed(2);

        //set color
        txtDiscountAmount.classList.remove("is-invalid");
        txtDiscountAmount.classList.add("is-valid");

        //set value for net amount also
        txtNetAmount.value = (parseFloat(txtTotalAmount.value) - parseFloat(txtDiscountAmount)).toFixed(2);
        invoice.net_amount=parseFloat(txtNetAmount.value);
        txtNetAmount.classList.remove("is-invalid");
        txtNetAmount.classList.add("is-valid");
      } else {
        txtDiscountAmount.value = 0.0; //no discounts from loyalty points
        invoice.discount_amount = parseFloat(txtDiscountAmount.value).toFixed(2);
        //set colors
        txtDiscountAmount.classList.remove("is-invalid");
        txtDiscountAmount.classList.add("is-valid");

        //set value for net amount also
        txtNetAmount.value = (
          parseFloat(txtTotalAmount.value) - parseFloat(txtDiscountAmount)
        ).toFixed(2);
         invoice.net_amount=parseFloat(txtNetAmount.value);
        txtNetAmount.classList.remove("is-invalid");
        txtNetAmount.classList.add("is-valid");
      }
    }
    else{
      //if length of the loyalty mapping is zero (doesnt happen beacuse evry customer going to get slected a a loyalty)
       txtDiscountAmount.value=parseFloat(0).toFixed(2);//no discounts from loyalty points
      invoice.discount_amount=parseFloat(txtDiscountAmount.value).toFixed(2);
      //set colors
       txtDiscountAmount.classList.remove("is-invalid");
       txtDiscountAmount.classList.add("is-valid");

            //set value for net amount also
      txtNetAmount.value=(parseFloat(txtTotalAmount.value)-parseFloat(txtDiscountAmount.value)).toFixed(2);
      invoice.net_amount=parseFloat(txtNetAmount.value);
      txtNetAmount.classList.remove("is-invalid");
       txtNetAmount.classList.add("is-valid");
    }
  } else {
    console.log("Customer empty");
    txtDiscountAmount.value = parseFloat(0).toFixed(2); //no discounts from loyalty points
    invoice.discount_amount = parseFloat(txtDiscountAmount.value).toFixed(2);
    //set colors
    txtDiscountAmount.classList.remove("is-invalid");
    txtDiscountAmount.classList.add("is-valid");

    //set value for net amount also
    txtNetAmount.value = (
      parseFloat(txtTotalAmount.value) - parseFloat(txtDiscountAmount.value)
    ).toFixed(2);
    invoice.net_amount=parseFloat(txtNetAmount.value);
    txtNetAmount.classList.remove("is-invalid");
    txtNetAmount.classList.add("is-valid");
  }
};

//calculate balance amount
const calculateBalanceAmount=()=>{
  txtCusPayBalanceAmount.value=(parseFloat(txtPaidAmount.value)-parseFloat(txtNetAmount.value)).toFixed(2);
  customerPayment.balance_amount=parseFloat(txtCusPayBalanceAmount.value).toFixed(2);

   txtCusPayBalanceAmount.classList.add("is-valid");
   txtCusPayBalanceAmount.classList.remove("is-invalid");
}

//function to equal paid amount to total amount for cardpayment
const paymentMethodselectionCard=()=>{// supPaymentUpdateButton.style.display = "none";//
  console.log(customerPayment);
  
  if (customerPayment.customer_payment_method_id.name=="Card") {
    //set paid amount to total amount
   txtPaidAmount.value=parseFloat(txtNetAmount.value).toFixed(2);
   txtPaidAmount.classList.add("is-valid");
   txtPaidAmount.classList.remove("is-invalid");
   customerPayment.paid_amount=parseFloat(txtPaidAmount.value).toFixed(2);

   txtCusPayBalanceAmount.disabled="disabled";
   txtCusPayBalanceAmount.value=parseFloat(0).toFixed(2);
   customerPayment.balance_amount=parseFloat(txtCusPayBalanceAmount.value);
   txtCusPayBalanceAmount.classList.add("is-valid");
   txtCusPayBalanceAmount.classList.remove("is-invalid");
  }

}




/* *************************************************************************** */
/* ************************** INNER FORM *********************************************/

//define function to filter item list by existance of inner table(call this in iteminventory select list in invoice.html)
const filterItemListbyExistance = () => {
  let selelctedBatch = JSON.parse(textBatchNo.value); //dynamic nm json parse krnn one
  //let selelctedBatch = invoiceHasInventory.item_inventory_id;//item_inventory_id is batch no
  let alreadyinInnerItem = invoiceHasInventory.item_inventory_id.item_id;

  console.log("selectedInnerItem-previous", alreadyinInnerItem);
  console.log("selelctedBatch.item_id.id", selelctedBatch.item_id.id);

  console.log(
    "Prevoisly Selected Batches:",
    invoiceHasInventory.item_inventory_id
  );
  console.log("Previous Invoice Has Item List:", invoice.invoiceHasInventoryList);

  console.log("invoiceHasInventory", invoiceHasInventory); //returns an object
  console.log("selelctedBatchNo", selelctedBatch); //returns an object

  // find the index of a specific item in a list inside a invoice object.
  let extIndex = invoice.invoiceHasInventoryList
    .map((invbatch) => invbatch.item_inventory_id.id)
    .indexOf(selelctedBatch.id);
  let extItemIndex = invoice.invoiceHasInventoryList
    .map((invitem) => invitem.item_inventory_id.item_id.id)
    .indexOf(selelctedBatch.item_id.id);

  console.log(extItemIndex);
  console.log(extIndex);

  /*
   invoice.invoiceHasInventoryList
      This is assumed to be an array (e.g., a list of items in a purchase order).

      Example structure:

      invoiceHasInventoryList = [
        { item_id: { id: 101 } },
        { item_id: { id: 202 } },
        { item_id: { id: 303 } }
      ];
      2. .map((invitem) => invitem.item_id.id)
      This transforms the array into just a list of item IDs.

      From the above example, you'd get:

      [101, 202, 303]
      .indexOf(selelctedBatch.id)
      This finds the index of selelctedBatch.id in the array of item IDs.

      If selelctedBatch.id = 202, the result would be 1.

      let extIndex = ...
      Stores the index in a variable called extIndex.

      If the selelctedBatch.id is not found, extIndex will be -1. */

  //check if batchno and itemname both in the list --> 1 item can have multiple batches

  if (extIndex != -1 && extItemIndex != -1) {
    //index exists
    window.alert("Selected Batch or Item Name already exists....!");
    refreshInvoiceInnerForm();
    return;
  }

  //check if batch no is alrady in the list  -->only one batch of one item
  if (extIndex != -1 && extItemIndex == -1) {
    //index exists
    window.alert("Selected Batch already exists....!");
    refreshInvoiceInnerForm();
    return;
  } else {
    //need to autaomatically add the value for unit price if have

    txtUnitPrice.value = parseFloat(selelctedBatch.sales_price).toFixed(2); //sales_price here is iteminventory table sales_price
    invoiceHasInventory.unit_price = parseFloat(txtUnitPrice.value).toFixed(2); //unit_price here is invoicehasinventory table unitprice

    //set color for invoice unit price
    txtUnitPrice.classList.remove("is-invalid");
    txtUnitPrice.classList.add("is-valid");
  }
};

//color the item data list when selected and get the item id of the selecteditem
let itemElement = document.querySelector("#textItemName");
itemElement.addEventListener("change", () => {
  selectedItemName = itemElement.value;
  let itemCode = selectedItemName.split(" ")[0]; //split the value from the space, [0] value  when splitted is itemcode
  let extIndex = items.map((item) => item.item_no).indexOf(itemCode); //item list eke tiyna ietmobject eka gane aragen e itemobject eke item code check kriai

  console.log(items[extIndex]);

  if (extIndex != -1) {
    selecteditemid = items[extIndex]; //set the item id
    console.log(selecteditemid.id);
    filterBatchNoByItem(); //call the filterbatchno function
    //set colors
    itemElement.classList.remove("is-invalid");
    itemElement.classList.add("is-valid");
  }
  //set the item id
});

//define function to filter batchno by item
const filterBatchNoByItem = () => {
  console.log(selecteditemid); //id of the selected item

  //get the bathno(inventories)
  let batches = getServiceRequest("/inventory/batcheslistbyitemid/" + selecteditemid.id); //calling the ajax request func in coommon func.js
  //calling reusable function for select list(elementid,massege,dtaalistname,prportynameOne)

  console.log(batches);

  //fill data into batch dat list
  /* fillDataintoDataList(
    batchList,
    batches,
    "batch_no",
    "batch_no"
  );  */

  fillDataintoSelect(textBatchNo, "Select Batch", batches, "batch_no");
};

//define function to calculate line price(unit price*quantity)-->call function at quantity input field onkeyip
const calculateLinePrice = () => {
  if (txtQty.value > 0) {
    //calculating line price
    let linePrice = (
      parseFloat(txtQty.value) * parseFloat(txtUnitPrice.value)
    ).toFixed(2);

    txtLinePrice.value = linePrice;
    invoiceHasInventory.line_price = linePrice;
    //call seasonal discount function
    checkItemSeasonalDiscount();
    //set color
    txtLinePrice.classList.remove("is-invalid");
    txtLinePrice.classList.add("is-valid");
  } else {
    invoiceHasInventory.qty = null;
    invoiceHasInventory.line_price = null;
    //set color for purchase order quantity
    txtQty.classList.remove("is-valid");
    txtQty.classList.add("is-invalid");

    //default color for line price since no value for qty
    // txtLinePrice.style.border="1px solid #ced4da";
    txtLinePrice.classList.remove("is-valid");
    txtLinePrice.classList.remove("is-invalid");
    txtLinePrice.value = "";
  }
};

//Funtion for inner form
const refreshInvoiceInnerForm = () => {
  //creating a new object
  invoiceHasInventory = new Object();

  //get the batches
  batches = [];

  textItemName.value = ""; //clearing datalist
  console.log(textItemName.value);

  if (textItemName.value != "") {
    //get the batches
    batches = getServiceRequest(
      "/inventory/batchlistbyitem/" + textItemName.value.id
    ); //calling the ajax request func in coommon func.js
  } else {
    //get the batches
    batches = getServiceRequest("/inventory/findall"); //calling the ajax request func in coommon func.js
  }
  items = getServiceRequest("/item/findall");
  fillDataintoDataList(itemList, items, "item_no", "itemname");

  //calling reusable function for select list(elementid,massege,dtaalistname,prportynameOne,proprtynameTwo of the datalist)
  fillDataintoSelect(textBatchNo, "Select Batch", batches, "batch_no");

  //filling to batch datalist
  //calling reusable function for data list(elementid,dtaalistname,prportynameOne,proprtynameTwo of the datalist)
  //fill data into batch data list
  /*  fillDataintoDataList(
    batchList,
    batches,
    "batch_no",
    "batch_no" 
  ); */

  //cant reset because it will reset the main form also
  //so need to clear the values

  textBatchNo.value = ""; //clearing select list -->//dynamic no need to clear values
  textItemName.disabled = ""; //enable item selection
  textBatchNo.disabled = ""; //enable batch selection
  // itemSelect.disabled = "";
  txtUnitPrice.value = "";
  txtUnitPrice.disabled = "disabled";
  txtQty.value = "";
  txtLinePrice.value = "";
  txtLinePrice.disabled = "disabled";
  txtDiscountedPrice.value = "";
  txtDiscountedPrice.disabled = "disabled";
  //itemSelect.value="";//dynamic no need to clear values

  //Need to clear the colors
  setToDefault([
    textItemName,
    txtUnitPrice,
    txtQty,
    txtLinePrice,
    textBatchNo,
    txtDiscountedPrice,
  ]); //textItemName,textBatchNo datalists inpufield id

  //disable update button,Enable submit button
  invoiceInnerInventoryupdateButton.classList.add("d-none");
  invoiceInnerInvcentorysubmitButton.classList.remove("d-none");

  //refresh inner table

  //Datatypes
  //string --> date/string/number
  //function-->object/array/boolean
  //decimal-->decimal/price
  let columnList = [
    { columnName: getBatchItemName, dataType: "function" },
    { columnName: getBatchNo, dataType: "function" },
    { columnName: "unit_price", dataType: "decimal" },
    { columnName: "qty", dataType: "string" },
    { columnName: "line_price", dataType: "decimal" },
    { columnName: "discounted_price", dataType: "decimal" },
  ];

  //call the common function to fill data into table(tablebody id,datalist name,column list,edit parameter,
  //delete parameter,view parameter,button visibility)
  // fillDataintoInnerTable(invoiceInventoryTableBody,invoice.invoiceHasInventoryList,columnList,invoiceInventoryEdit,invoiceInventoryDelete,purchaseOrderItemView,true);
  fillDataintoInnerTable(
    invoiceInventoryTableBody,
    invoice.invoiceHasInventoryList,
    columnList,
    invoiceInventoryEdit,
    invoiceInventoryDelete,
    true
  );

  //setting value for grand total
  let grandTotal = 0.0;
  for (const orderitem of invoice.invoiceHasInventoryList) {
    grandTotal =
      parseFloat(grandTotal) + parseFloat(orderitem.discounted_price); //add discounted price together to find the tot amount for main form
  }
  if (grandTotal != 0.0) {
    console.log(grandTotal);
    txtTotalAmount.value = grandTotal.toFixed(2); //two decimal points
    invoice.total_amount = txtTotalAmount.value;
    discountByLoyaltyPoints(); //function to check loyalty discounts in main form based on the total maount

    //set color for grand total
    txtTotalAmount.classList.remove("is-invalid");
    txtTotalAmount.classList.add("is-valid");
  } else {
    console.log("zero", grandTotal);
    //set color for grand total
    txtTotalAmount.classList.remove("is-invalid");
    txtTotalAmount.classList.remove("is-valid");
    txtTotalAmount.value = "";
  }
};

//function to get inventory item name
const getBatchItemName = (dataOb) => {
  return dataOb.item_inventory_id.item_id.itemname;
};

const getBatchNo = (dataOb) => {
  return dataOb.item_inventory_id.batch_no;
};

//function for inner form  edit/refill
const invoiceInventoryEdit = (dataOb, index) => {
  innerFormIndex = index;

  //if there is an update only the invoiceHasInventory variable will be modified since its the passing object in frontend
  invoiceHasInventory = JSON.parse(JSON.stringify(dataOb)); // Working copy for editing
  console.log("invoiceHasInventory", invoiceHasInventory);

  oldinvoiceHasInventory = JSON.parse(JSON.stringify(dataOb)); // Original copy for comparison

  /* JSON.stringify(dataOb) converts the object to a JSON string
JSON.parse() converts that JSON string back to a JavaScript object
This creates a completely new object with the same data */

  //get the items
  let items = getServiceRequest("/item/itemlist"); //calling the ajax request func in coommon func.js

  //calling reusable function for select list(elementid,massege,dtaalistname,prportynameOne,proprtynameTwo of the datalist,selected itemid)
  /*  fillDataintoSelectTwo(
    itemSelect,
    "Select Item",
    items,
    "item_no",
    "itemname",
    invoiceHasInventory.item_id.item_no
  );
 */

  //filling to item datalist
  textItemName.value =
    invoiceHasInventory.item_inventory_id.item_id.item_no +
    " " +
    invoiceHasInventory.item_inventory_id.item_id.itemname;

  //itemSelect.disabled = "disabled"; //disabling item selection
  textItemName.disabled = "disabled"; //disabling item selection

  textBatchNo.value = JSON.stringify(invoiceHasInventory.item_inventory_id); //dynamic nisa mehem
  textBatchNo.disabled = "disabled"; //disabling batch selection
  // textBatchNo.value=invoiceHasInventory.item_inventory_id.batch_no;//setting the batch no -->static datalist/textbox

  txtUnitPrice.value = parseFloat(invoiceHasInventory.unit_price).toFixed(2);
  txtQty.value = invoiceHasInventory.qty;
  txtLinePrice.value = parseFloat(invoiceHasInventory.line_price).toFixed(2);
  txtDiscountedPrice.value = parseFloat(
    invoiceHasInventory.discounted_price
  ).toFixed(2);

  //disable submit button,Enable update button
  invoiceInnerInventoryupdateButton.classList.remove("d-none");
  invoiceInnerInvcentorysubmitButton.classList.add("d-none");
};

//function for inner form delete
const invoiceInventoryDelete = (dataOb, index) => {
  console.log("Delete inner", dataOb);
  console.log("Delete inner", invoice.invoiceHasInventoryList);

  //need to get user confirmation
  let userConfirmation = window.confirm(
    "Are You sure you want to Remove the following Item .. ?" +
      "\nItem Name :" +
      dataOb.item_inventory_id.item_id.itemname +
      "\n Unit Price :" +
      dataOb.unit_price +
      "\nQuantity :" +
      dataOb.qty +
      "\nLine Price:" +
      dataOb.line_price +
      "\nDiscounted Price:" +
      dataOb.discounted_price
  );
  if (userConfirmation) {
    window.alert("Delete Successfull !..\n");
    //remove an existing item record from the inner form list (invoiceHasInventoryList) if it already exists — based on item_id.
    let extIndex = invoice.invoiceHasInventoryList
      .map((orderitem) => orderitem.item_inventory_id.id) //Extracts a list of all item_id.id values from the invoiceHasInventoryList (ex:-[101, 102, 103])
      .indexOf(dataOb.item_inventory_id.id); //Searches for the index of the item ID from dataOb in that list.Returns:0, 1, 2, etc., if found,-1 if not found
    if (extIndex != -1) {
      invoice.invoiceHasInventoryList.splice(extIndex, 1); //Removes one item at the index extIndex.Effectively deletes that item from the inner form list.
    }
    // window.location.reload(); full browser reload -->reload every image&...
  } else {
    window.alert("Form Contains Errors !..\n");
  }

  refreshInvoiceInnerForm(); //refresh purchase order inner form
};

//function for inner form submit
const invoiceInventorySubmitButton = () => {
  console.log(invoiceHasInventory);

  //need to get user confirmation
  let userConfirmation = window.confirm(
    "Are You sure you want to add the following Item .. ?" +
      "\nItem Name :" +
      selectedItemName +
      "\nUnit Price :" +
      invoiceHasInventory.unit_price +
      "\nQuantity :" +
      invoiceHasInventory.qty +
      "\nLine Price:" +
      invoiceHasInventory.line_price+
       "\nDiscounted Price:" +
      invoiceHasInventory.discounted_price
  );
  if (userConfirmation) {
    window.alert("Submission Successfull !..\n");
    invoice.invoiceHasInventoryList.push(invoiceHasInventory);
    // window.location.reload(); full browser reload -->reload every image&...
    refreshInvoiceInnerForm(); //refresh invoice inner form
  } else {
    window.alert("Form Contains Errors !..\n");
  }

  // console.log(employee);

  refreshInvoiceInnerForm();

};

//function for innerform update
const invoiceInventoryUpdateButton = () => {
  console.log(invoiceHasInventory);

  if (invoiceHasInventory.qty != oldinvoiceHasInventory.qty) {
    //need to get user confirmation
    let userConfirmation = window.confirm(
      "Are You Sure you want to update the following changes.. ?" +
        "\nQuantity Changed from :" +
        oldinvoiceHasInventory.qty +
        " to " +
        invoiceHasInventory.qty
    );

    if (userConfirmation) {
      window.alert("Update Successfull !..\n");
      invoice.invoiceHasInventoryList[innerFormIndex] = invoiceHasInventory;
      // window.location.reload(); full browser reload -->reload every image&...
      refreshInvoiceInnerForm(); //refresh purchase order inner form
    } else {
      window.alert("Form Contains Errors !..\n");
    }
  } else {
    window.alert("Form Contains No Updates..!");
  }
  refreshInvoiceInnerForm();
};

//check if the line price of inner form for the item has a discount-->function called inside calulatelineprice function
const checkItemSeasonalDiscount = () => {
  let quantityValue = parseInt(txtQty.value); //get qty
  console.log(selecteditemid.id);

  let innerItemid = selecteditemid.id; //get the selected item id

  let currentDate = new Date();
  let currentMonth = currentDate.getMonth() + 1; //getMonth gives [0-11] so we need to add 1
  if (currentMonth < 10) {
    currentMonth = "0" + currentMonth;
  }
  let CurrentDay = currentDate.getDate(); //[1-31]
  if (CurrentDay < 10) {
    CurrentDay = "0" + CurrentDay;
  }

  let todayDate =
    currentDate.getFullYear() + "-" + currentMonth + "-" + CurrentDay;
  console.log(todayDate);

  //get the item seasonal discounts based on amoun,date,item
  let itemdiscounts = getServiceRequest(
    "/discount/seasonldiscountsbyitemidanddateandqty/" +
      innerItemid +
      "/" +
      todayDate +
      "/" +
      quantityValue
  );

  //this returns an array
  console.log("itemdiscounts", itemdiscounts);

  //need to calcultae the discounted price.
  //first check if the array is empty or not -->empty nma discoun ekk an adala item ekt
  if (itemdiscounts.length > 0) {
    let rate = itemdiscounts[0].discount_rate; //get the discount rate
    let disAmount = (
      parseFloat(txtLinePrice.value) *
      (parseFloat(rate) / 100)
    ).toFixed(2);

    txtDiscountedPrice.value = (
      parseFloat(txtLinePrice.value) - disAmount
    ).toFixed(2); //calculate discount amount
    invoiceHasInventory.discounted_price = parseFloat(
      txtDiscountedPrice.value
    ).toFixed(2);
    console.log(txtDiscountedPrice.value);
    //set color
    txtDiscountedPrice.classList.remove("is-invalid");
    txtDiscountedPrice.classList.add("is-valid");
  } else {
    //No discounts -->set discounted price same as the line  price
    txtDiscountedPrice.value = parseFloat(txtLinePrice.value).toFixed(2);
    invoiceHasInventory.discounted_price = parseFloat(
      txtDiscountedPrice.value
    ).toFixed(2);
    //set color
    txtDiscountedPrice.classList.remove("is-invalid");
    txtDiscountedPrice.classList.add("is-valid");
  }
};

//check available qty from item inventory when user insering qty
const checkAvailableQty = () => {
  let selectedBatch = JSON.parse(textBatchNo.value);
  let availableQty = parseInt(selectedBatch.available_qty); //get the available quantity for selected batch

  if (txtQty.value > availableQty) {
    window.alert(
      "Available Quantity is only " +
        availableQty +
        " Please Enter a value less than that!."
    );
    txtQty.value = ""; //clear the value entered
    txtLinePrice.value = ""; //clear the value entered
    txtDiscountedPrice.value = ""; //clear the value entered
    setToDefault([txtQty, txtLinePrice, txtDiscountedPrice]); //clear the colors
  }
};


//function to fill customer name and contact no when customer is seletced
const fillCusNameandContactNo=(dataOb)=>{

  let cusname=invoice.customer_id.customername;
  txtCustomername.value=cusname;
  //set colors for cusname and contact no
  invoice.customer_name= txtCustomername.value;
  txtCustomername.classList.remove("is-invalid");
  txtCustomername.classList.add("is-valid");

  let CusContactNo=invoice.customer_id.contactno;
  txtContactNo.value=CusContactNo;
  invoice.contact_no= txtContactNo.value;
  txtContactNo.classList.remove("is-invalid");
  txtContactNo.classList.add("is-valid");

  //this also canbe used
  console.log(cusname);
/*   let abc=JSON.parse(customerSelect.value).customername;
  console.log(abc); */
  
  
}
