window.addEventListener("load", () => {
  console.log("load");

  //call refreshuser table function
  refreshUserTable();

  //call refreshuser table function
  refreshUserForm();

  //enable tooltip
  $('[data-bs-toggle="tooltip"]').tooltip();
  console.log(users);
  
});

//Fuction for refresh user table
const refreshUserTable = () => {
  //calling the ajax request func in coommon func.js to get data
  const users = getServiceRequest("/user/findall");

   //Datatypes
  //string --> date/string/number
  //function-->object/array/boolean
  //decimal-->decimal/price
  let columnList = [
    { columnName: getEmployee, dataType: "function" }, //object ekk misa function
    { columnName: "username", dataType: "string" },
    { columnName: "email", dataType: "string" },
    { columnName: getRole, dataType: "function" }, //object ekk misa function
    { columnName: getUserStatus, dataType: "function" }, //boolean nisa function
  ];

  //call the common function to fill data into table(tablebody id,datalist name,column list,edit parameter,
  //delete parameter,view parameter,button visibility)
  // fillDataintoTable(tableBodyEmployee,employees,columnList,employeeEdit,employeeDelete,employeeView,true);
  fillDataintoTableTwo(
    userTableBody,
    users,
    columnList,
    userEdit,
    userDelete,
    userView,
    true
  );
  //disabling modifying buttons based on conditions
  for (const index in users) {

    if (!users[index].status) {
    const row = userTableBody.children[index];         // get the <tr>
    const lastCell = row.lastElementChild;                      // get the last <td>
    const deleteBtn = lastCell.querySelector("ul li:nth-child(3) button"); // third li button = Delete    
    deleteBtn.disabled="disabled";//deleteBtn.classList.add("d-none") for hide delete btn
  }
  }

  $("#userTable").DataTable();
};

//function to get Employee name
const getEmployee = (ob) => {
  if (ob.employee_id != null) {
    return ob.employee_id.fullname;
  } else {
    return "-";
  }
};

//function to get Role
//role is an array e nisa foreach ekkin access krnna one
const getRole = (ob) => {
  let roles = "";//roles is the name of the object coming from backend
  ob.roles.forEach((role, index) => {
    if (ob.roles.length - 1 == index) {
      roles = roles + role.name; //remove the comma if its the last value
    } else {
      roles = roles + role.name + ",";
    }
  });
  return roles;
};

//function to get status
const getUserStatus = (ob) => {
  if (ob.status) {
    let active = "<span class='badge text-bg-success'>Active</span>";
    return active;
  } else {
    let inActive = "<span class='badge text-bg-danger'>Inactive</span>";
    return inActive;
  }
};

//function for edit/refill user
const userEdit = (ob, index) => {
  //old user and user for update checking
  user = JSON.parse(JSON.stringify(ob));
  oldUser = JSON.parse(JSON.stringify(ob));

  console.log("Edit", ob, index);
  //tableBodyEmployee.children[index].style.border="2px solid black";

  //refill the form
  //Employee select list
  employeeSelect.value = JSON.stringify(ob.employee_id); //object ekk nisa (dynamic ewge)

  //username
  txtUserName.value = ob.username;

  //password
  txtPassword.value = ob.password;
txtPassword.disabled="disabled";
  //retype password
  txtReTypePassword.value = ob.password;
txtReTypePassword.disabled="disabled";
  //email
  txtEmail.value = ob.email;

  //required nati nisa -->note
  if (ob.txtNote == null) {
    txtNote.value = " ";
  } else {
    txtNote.value = ob.note;
  }

  //user status checkbox
  if (ob.status) {
    checkboxUserStatus.checked = true;
    labelUserStatus.innerText = "User Account is Active";
  } else {
    checkboxUserStatus.checked = false;
    labelUserStatus.innerText = "User Account is Inactive";
  }

  //Roles checkbox
  ob.roles.forEach((element) => {
    console.log(element.name);
    switch (element.name) {
      case "Manager":
        chkboxRoleManager.checked = true;
        break;
      case "Cashier":
        chkboxRoleCashier.checked = true;
        break;
      case "Assistant_Manager":
        chkboxRoleAssistant_Manager.checked = true;
        break;
      case "Store_Manager":
        chkboxRoleStore_Manager.checked = true;
        break;
      default:
        break;
    }
  });

  $("#userFormModal").modal("show"); //show modal

  //disable submit button,Enable update button in edit function
  submitButton.style.display = "none";
  updateButton.removeAttribute("style");
};

//function for delete user
const userDelete = (dataOb) => {
  let userConfirmation = window.confirm(
    "Are You sure you want to delete the following User .. ?\n" +
      "User Name: " +
      dataOb.username +
      "\nEmail: " +
      dataOb.email
  );
  if (userConfirmation) {
    //getHTTPServiceRequest(URL,METHOD,Data object name)
    let deleteResponse = getHTTPServiceRequest(
      "/user/delete",
      "DELETE",
      dataOb
    );
    if (deleteResponse == "OK") {
      window.alert("Delete Successfull");
      refreshUserForm();
      refreshUserTable();
      $("#userFormModal").modal("hide"); //Hide modal
    } else {
      window.alert(
        "Delete Unsuccessfull..!\nHas Following Errors\n" + deleteResponse
      );
    }
  }
};

//function for view/print user
const userView = (ob) => {
  console.log("View", ob);

  //view in  a modal
  //Employee name
  if (ob.employee_id != null) {
    user_Employee.innerText = ob.employee_id.fullname;
  } else {
    user_Employee.innerText = "---------";
  }

  //username
  user_userName.innerText = ob.username;
  user_Email.innerText = ob.email;

  //Roles checkbox
  let roleNames = [];
  ob.roles.forEach((element) => {
    roleNames.push(element.name);
  });
  //.join(", ") creates a single string with commas only between elements:
  user_Roles.innerText = roleNames.join(", "); //join a comma after a role but no the last role

  //user status
  if (ob.status) {
    user_status.innerText = "Active";
  } else {
    user_status.innerText = "Inactive";
  }

  $("#userFormModalView").modal("show"); //show modal
};

//After clicking print on view modal
//Print row new tab open
const printButtonRow = () => {
  let newTab = window.open();
  let printTab =

"<head><title>User Print</title>" +
"<link rel='stylesheet' href='bootstrap-5.2.3/css/bootstrap.min.css'>" +
"</head>" +
"<body>" +
"<h4 class='text-center mt-3'>User Print</h4>" +
"<div class='container mt-3'>" +
"  <div class='row justify-content-center'>" +
"    <div class='col-md-8'>" + userTableView.outerHTML + "</div>" +
"  </div>" +
"</div>" +
"</body>";
  newTab.document.write(printTab);
  
  setTimeout(() => {
    //what should happen after 1500 ms
    newTab.stop();
    newTab.print();
    newTab.close();
  }, 1500);
};

/* *************************************************************************** */
/* **************************  FORM *********************************************/

//Function for refresh user form
const refreshUserForm = () => {
  
  formUser.reset(); //clearing the form values
  user = new Object(); //create a new object
  user.roles = new Array();

  

  //here in the user form should only have employee names who doest have an user account
  //since user accounts are created when an employee is created.

  //employee  select list
  let employees = getServiceRequest("/employee/employeewithoutuseraccount"); //calling the ajax request func in common func.js

  //calling reusable function for select list(elementid,massege,dtaalistname,prportyname of the datalist)
  fillDataintoSelect(employeeSelect, "Select Employee", employees, "fullname");

  checkboxUserStatus.checked = "checked"; //user status checkbox
  labelUserStatus.innerText = "User Account is Active";
  user.status = true; //initial state of the form user status is true(default)

  //get roles list
  let roles = getHTTPServiceRequest("/role/rolesWithoutAdmin"); //calling the ajax request func in common func.js

  let divRole = document.querySelector("#divRoles");
  divRole.innerHTML = ""; //clearing static html

  roles.forEach((role, index) => {
    let div = document.createElement("div");
    div.className = "form-check form-check-inline";
    divRole.appendChild(div);

    let inputCheckBox = document.createElement("input");
    inputCheckBox.type = "checkbox";
    inputCheckBox.id = "chkboxRole" + role.name;
    inputCheckBox.className = "form-check-input";

    inputCheckBox.onclick = function () {

      // Use function() for proper "this" binding

      /* user.roles might be undefined or null when you first create a user object, especially 
      if it comes from an API or database where roles is optional.
if (!user.roles) checks if user.roles is falsy (meaning it's null, undefined, false, 0, or "").
If user.roles is not already defined, it gets assigned an empty array []. */
      if (!user.roles) {
        user.roles = []; // Initialize roles array if undefined
      }

      if (this.checked) {
        user.roles.push(role); // Push role when checked
      } else {
        // Remove role if unchecked
        let extIndex = user.roles
          .map((userrole) => userrole.name)
          .indexOf(role.name);
        if (extIndex !== -1) {
          user.roles.splice(extIndex, 1);
        }
      }

      console.log(user.roles); // Debugging: Check if roles are updating correctly
    };

    div.appendChild(inputCheckBox); //inputcheckbox appended to div

    let checkLabel = document.createElement("label");
    checkLabel.className = "form-check-label fw-bold";
    checkLabel.innerText = role.name;
    div.appendChild(checkLabel);
  });

   // //Need to clear the colors
  
   setToDefault([employeeSelect,txtUserName,txtPassword,txtReTypePassword,txtEmail,txtNote]);

  //disable update button,Enable submit button
  // updateButton.style.visibility="hidden";
  // submitButton.style.visibility="visible";
  updateButton.style.display = "none";
  submitButton.removeAttribute("style");
};

//check user form errors
const checkUserFormErrors = () => {
  let errors = "";
  if (user.username == null) {
    errors = errors + "Please Enter User Name \n";
  }
  if (user.password == null) {
    errors = errors + "Please Enter Password \n";
  }
  if (txtReTypePassword.value == null) {
    errors = errors + "Please Enter Re-Type Password \n";
  }
  if (user.email == null) {
    errors = errors + "Please Enter Email \n";
  }
  if (user.roles.length == 0) {
    errors = errors + "Please Select Role \n";
  }
  if (user.status == null) {
    errors = errors + "Please Select an User Status \n";
  }
  return errors;
};

const userSubmitButton = () => {
  console.log(user);

  //Roles checkbox
  //also can be done using map -->let roleNames = user.roles.map(role => role.name);
  let roleNames = [];
  user.roles.forEach((element) => {
    roleNames.push(element.name);
  });
  //.join(", ") creates a single string with commas only between elements:
  // user_Roles.innerText = roleNames.join(", ");//join a comma after a role but no the last role

  let errors = checkUserFormErrors();

  if (errors == "") {
    //no errors
    //need to get user confirmation
    let userConfirmation = window.confirm(
      "Are You sure you want to add the following User .. ?" +
        "\nEmployee Name :" +
        user.employee_id.fullname +
        "\nUser Name :" +
        user.username +
        "\nUser Email :" +
        user.email +
        "\nUser Status :" +
        user.status +
        "\nUser Roles :" +
        roleNames.join(", ")
    );
    if (userConfirmation) {
      //Call post service(url,method,data) data means object name-->user
      let postServiceResponse = getHTTPServiceRequest("/user/insert","POST",user);
      if (postServiceResponse == "OK") {
        window.alert("Submission Successfull !..\n");
        refreshUserTable(); //refresh user table
        // window.location.reload(); full browser reload -->reload every image&...
        refreshUserForm(); //refresh employee form
        $("#userFormModal").modal("hide"); //Hide modal
      } else {
        window.alert("Submission Failed !..\n" + postServiceResponse);
      }
    }
  } else {
    window.alert("Form Contains Following Errors !..\n" + errors);
  }
};

//function to check User Form updates
const checkUserFormUpdates = () => {
  let updates = "";

  console.log(user);
  console.log(oldUser);

  if (user != null && oldUser != null) {
    if (user.employee_id.fullname != oldUser.employee_id.fullname) {
      updates =
        updates +
        "Employee changed from " +
        oldUser.employee_id.fullname +
        " into " +
        user.employee_id.fullname +
        "\n";
    }
    if (user.username != oldUser.username) {
      updates =
        updates +
        "User Name changed from " +
        oldUser.username +
        " into " +
        user.username+
        "\n";
    }
    if (user.email != oldUser.email) {
      updates =
        updates +
        "Email changed from " +
        oldUser.email +
        " into " +
        user.email +
        "\n";
    }
    if (user.status != oldUser.status) {
      if (user.status) {
        updates =updates +"User Status changed from Inactive into Active \n";
      } else {
        updates =updates + "User Status changed from Active into Inactive \n";
      }
     
    }

    //code if u want know what roles have changed
   /*  let roleNames = user.roles.map(role => role.name);
    let oldroleNames = oldUser.roles.map(role => role.name);
    let addedRoles = roleNames.filter(role => !oldroleNames.includes(role));
    let removedRoles = oldroleNames.filter(role => !roleNames.includes(role));

    if (addedRoles.length > 0 || removedRoles.length > 0) {
    console.log("Roles updated!");
    console.log("Added Roles:", addedRoles);
    console.log("Removed Roles:", removedRoles);
    }   */

    let roleNames = user.roles.map(role => role.name);
    let oldroleNames = oldUser.roles.map(role => role.name);

    let hasChanges =
    roleNames.length !== oldroleNames.length || // Check if lengths are different
    new Set(roleNames).size !== new Set(oldroleNames).size || // Quick uniqueness check
    roleNames.some(role => !oldroleNames.includes(role)) || // Check if new role was added
    oldroleNames.some(role => !roleNames.includes(role)); // Check if role was removed
    if (hasChanges) {
       updates =updates + "Roles have been updated!\n";
    } 
  }

  return updates;
};

//Function for user update button
const userUpdateButton = () => {
    //check for form eroors
    let errors = checkUserFormErrors();
    if (errors == "") {
      //check for user Form updates
      let updates = checkUserFormUpdates();
      if (updates == "") {
        window.alert("Form Contains No Updates..!");
      } else {
        //Need user confirmation
        let userConfirmation = window.confirm(
          "Are you Sure you want to update the following changes ?\n" + updates
        );
        if (userConfirmation) {
  
          //call put service
  
          let putServiceResponse = getHTTPServiceRequest("/user/update","PUT",user);;
          if (putServiceResponse == "OK") {
            window.alert("Form update Successfull..!");
            refreshUserForm();
            $("#userFormModal").modal("hide"); //Hide modal
          } else {
            window.alert("Form Update Unsucessfull..!\n" + putServiceResponse);
          }
        }
      }
    } else {
      window.alert("Form Contains Following Errors !..\n" + errors);
    }
  
    refreshUserTable();
};

//function to validate retype password
const passwordValidator = () => {
  if (txtPassword.value == txtReTypePassword.value) {
    user.password = txtPassword.value;
    txtReTypePassword.classList.remove("is-invalid");
    txtReTypePassword.classList.add("is-valid");
  } else {
    user.password = null;
    txtReTypePassword.classList.remove("is-valid");
    txtReTypePassword.classList.add("is-invalid");
  }
};
