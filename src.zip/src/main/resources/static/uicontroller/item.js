//Browser load event
window.addEventListener("load", () => {
  console.log("load");

  //enable tooltip
  $('[data-bs-toggle="tooltip"]').tooltip();

  refreshItemForm();
  refreshItemTable();
  refreshSubCategoryForm();
});

//refresh table area
const refreshItemTable = () => {
  //calling the ajax request func in coommon func.js to get data
  items = getServiceRequest("/item/findall");

  //Datatypes
  //string --> date/string/number
  //function-->object/array/boolean
  //decimal-->decimal/price
  let columnList = [
    { columnName: "itemname", dataType: "string" },
    { columnName: getItemBrand, dataType: "function" },
    { columnName: getSubCategory, dataType: "function" },
    { columnName: "rop", dataType: "string" },
    { columnName: "roq", dataType: "string" },
    { columnName: "item_photo", dataType: "image-array" },
    { columnName: getItemStatus, dataType: "function" },
  ];
  //call the common function to fill data into table(tablebody id,datalist name,column list,edit parameter,
  //delete parameter,view parameter,button visibility)
  // fillDataintoTable(tableBodyEmployee,employees,columnList,employeeEdit,employeeDelete,employeeView,true);
  fillDataintoTableTwo(
    itemTableBody,
    items,
    columnList,
    itemEdit,
    itemDelete,
    itemView,
    true
  );

  //disabling modifying buttons based on conditions
  for (const index in items) {
    if (items[index].item_status_id.name == "Deleted") {
      const row = itemTableBody.children[index]; // get the <tr>
      const lastCell = row.lastElementChild; // get the last <td>
      const deleteBtn = lastCell.querySelector("ul li:nth-child(3) button"); // third li button = Delete
      deleteBtn.disabled = "disabled"; //deleteBtn.classList.add("d-none") for hide delete btn
    }
  }

  $("#itemTable").DataTable();
};

//function to get item Brand
const getItemBrand = (dataOb) => {
  return dataOb.item_brand_id.name;
};

//function to get item sub category
const getSubCategory = (dataOb) => {
  return dataOb.item_sub_category_id.name;
};

//function to get item status
const getItemStatus = (dataOb) => {
  if (dataOb.item_status_id.name == "Available") {
    let available =
      "<span class='badge text-bg-success'>" +
      dataOb.item_status_id.name +
      "</span>";
    return available;
  }
  if (dataOb.item_status_id.name == "Not-Available") {
    let notAvailable =
      "<span class='badge text-bg-primary'>" +
      dataOb.item_status_id.name +
      "</span>";
    return notAvailable;
  }
  if (dataOb.item_status_id.name == "Deleted") {
    let deleted =
      "<span class='badge text-bg-danger'>" +
      dataOb.item_status_id.name +
      "</span>";
    return deleted;
  }
};

//function for edit row
const itemEdit = (dataOb, index) => {
  //old item and item for update checking
  item = JSON.parse(JSON.stringify(dataOb));//if there is an update only the item variable will be modified since its the passing object in frontend 
  oldItem = JSON.parse(JSON.stringify(dataOb));

  console.log("Edit", dataOb, index);
  //itemTableBody.children[index].style.border="2px solid black";

  //refill the form

  txtItemName.value = dataOb.itemname;
  txtRop.value = dataOb.rop;
  txtRoq.value = dataOb.roq; //static
  txtpurchasePrice.value = dataOb.purchase_price; //static
  txtProfitRatio.value = dataOb.profit_ratio; //static
  txtSalesPrice.value = dataOb.sales_price; //static
  txtItemSize.value = dataOb.unit_size; //static

  //txtDiscountRatio.value = dataOb.civil_status; //static

  itemCategorySelect.value = JSON.stringify(
    dataOb.item_sub_category_id.item_category_id
  ); //object ekk nisa (dynamic ewge)

  category = JSON.parse(itemCategorySelect.value);
  //filtered sub category list based on category
  //getServiceRequest("/subcategory/bycategory?categoryid="+category.id+"&abc="+category.nmae);
  let itemSubCategorybyCategory = getServiceRequest(
    "/subcategory/bycategory?categoryid=" + category.id
  ); //calling the ajax request func in coommon func.js
  fillDataintoSelect(
    itemSubcategorySelect,
    "Select Item sub-Category",
    itemSubCategorybyCategory,
    "name"
  );

  //filtered Brand list based on category
  //getServiceRequest("/subcategory/bycategory?categoryid="+category.id+"&abc="+category.nmae);
  let itemBrandbyCategory = getServiceRequest(
    "/brand/bycategory/" + category.id
  ); //calling the ajax request func in coommon func.js
  //reusable function for select list(elementid,massege,dtaalistname,prportyname of the datalist)
  fillDataintoSelect(
    itemBrandSelect,
    "Select Item Brand",
    itemBrandbyCategory,
    "name"
  );

  //object ekk nisa (dynamic ewge)
  itemBrandSelect.value = JSON.stringify(dataOb.item_brand_id); //dynmaic
  itemSubcategorySelect.value = JSON.stringify(dataOb.item_sub_category_id);
  itemStatusSelect.value = JSON.stringify(dataOb.item_status_id); //dynmaic
  itemPackageTypeSelect.value = JSON.stringify(dataOb.package_type_id); //dynmaic
  itemUnitsSelect.value = JSON.stringify(dataOb.unit_type_id); //dynmaic

  //required nati nisa
  if (dataOb.note == null) {
    txtItemNote.value = " ";
  } else {
    txtItemNote.value = dataOb.note;
  }

  //required nati nisa
  //not required 
  //set photo
  if (dataOb.item_photo!=null) {
    itemPhotoPreview.src=atob(dataOb.item_photo);
  } else {
    itemPhotoPreview.src="images/defaultitemimage.jpg";
  }

  $("#itemFormModal").modal("show"); //show modal

  //disable submit button,Enable update button in edit function
  submitButton.style.display = "none";
  updateButton.removeAttribute("style");
};

//function for delete row
const itemDelete = (dataOb, index) => {
  console.log("Delete", dataOb, index);

  /* 
  //add sweet alert
  let userDeleteMsg =
    "\nEmployee Full Name :" +dataOb.fullname +
    "\nEmployee Calling Name :" +dataOb.callingname +
    "\nEmployee DOB :" +dataOb.dob +
    "\nEmployee NIC :" +dataOb.nic +
    "\nEmployee Email :" +dataOb.email +
    "\nEmployee Designation :" +dataOb.designaton_id.name+
    "\nEmployee Mobile No :" +dataOb.mobile_no +
    "\nEmployee Land No :" +dataOb.landno +
    "\nEmployee Gender :" +dataOb.gender +
    "\nEmployee Civil Status :" +dataOb.civil_status;

  Swal.fire({
    title: "Are you sure?",
    text: userDeleteMsg,
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes, delete it!",
  }).then((userResponse) => {
    if (userResponse.isConfirmed) {
      //employee=dataOb need to change the object name based on theobject name used in delete employeeDelete()

      let deleteResponse=getHTTPServiceRequest("/employee/delete","DELETE",dataOb);

      if (deleteResponse) {
        Swal.fire({
          title: "Delete Sucessfull!",
          text: "Your file has been deleted.",
          icon: "success",
        });
        refreshEmpTable();
        refreshEmpForm();
        $("#employeeFormModal").modal("hide"); //Hide modal
      } else {
        Swal.fire({
          title: "Delete unsucessfull!",
          text: "Your file has not been deleted.\n"+deleteResponse,
          icon: "error",
        });
      }

      
    }
  }); */

  //need to get user confirmation
  let userConfirmation = window.confirm(
    "Are You sure you want to delete the following Item .. ?" +
      "\n Item Name :" +
      dataOb.itemname +
      "\n Item Category :" +
      dataOb.item_sub_category_id.item_category_id.name +
      "\n Item Sub-Category :" +
      dataOb.item_sub_category_id.name +
      "\n Item Brand :" +
      dataOb.item_brand_id.name +
      "\n Item ROQ :" +
      dataOb.roq +
      "\n Item ROP :" +
      dataOb.rop +
      "\n Item Status :" +
      dataOb.item_status_id.name +
      "\n Item Sales Price :" +
      dataOb.sales_price
  );
  if (userConfirmation) {
    let deleteResponse = getHTTPServiceRequest(
      "/item/delete",
      "DELETE",
      dataOb
    );
    //Call delete service
    if (deleteResponse == "OK") {
      window.alert("Delete Successfull !..\n");
      refreshItemTable(); //refresh item table
      // window.location.reload(); full browser reload -->reload every image&...
      refreshItemForm(); //refresh item form
    } else {
      window.alert("Submission Failed !..\n" + deleteResponse);
    }
  }
};

//function for view/print row
const itemView = (dataOb, index) => {
  console.log("View", dataOb, index);

  //option 2 view in  a modal

  item_name.innerText = dataOb.itemname;
  item_rop.innerText = dataOb.rop;
  item_roq.innerText = dataOb.roq;
  item_category.innerText = dataOb.item_sub_category_id.item_category_id.name;
  item_brand.innerText = dataOb.item_brand_id.name;
  item_salesprice.innerText = dataOb.sales_price;
  item_status.innerText = dataOb.item_status_id.name;

  $("#itemFormModalView").modal("show"); //show modal
};

//option 2 Print row new tab open
const printButtonRow = () => {
  let newTab = window.open();
  let printTab =
"<head><title>Item Print</title>" +
"<link rel='stylesheet' href='bootstrap-5.2.3/css/bootstrap.min.css'>" +
"</head>" +
"<body>" +
"<h4 class='text-center mt-3'>Item Print</h4>" +
"<div class='container mt-3'>" +
"  <div class='row justify-content-center'>" +
"    <div class='col-md-8'>" + itemTableView.outerHTML + "</div>" +
"  </div>" +
"</div>" +
"</body>";
  newTab.document.write(printTab);

  setTimeout(() => {
    //what should happen after 1500 ms
    newTab.stop();
    newTab.print();
    newTab.close();
  }, 1500);
};

/* *************************************************************************** */
/* **************************  FORM *********************************************/

//refresh form area
const refreshItemForm = () => {
  //static element only is cleared
  //Cleaning the values(select list not needed dynamic nm )

  formItem.reset(); //clearing the form values

  itemPhotoFile.value="";//clearing image file input field
  itemPhotoPreview.src="images/defaultitemimage.jpg"; //default photo

  itemCategorySelect2.value="";//for subctegory form
  txtSubCategoryName.value="";
  setToDefault([itemCategorySelect2, txtSubCategoryName]);//remove colors
  $("#subCategoryCollapse").collapse("hide"); //Hide collapse

  item = new Object(); //creating a new object

  //refilling the dynamic elements

  let itemCategory = getServiceRequest("/category/findall"); //calling the ajax request func in coommon func.js
  let itemBrand = getServiceRequest("/brand/findall"); //calling the ajax request func in coommon func.js
  let itemPackageType = getServiceRequest("/packagetype/findall"); //calling the ajax request func in coommon func.js
  let itemUnitType = getServiceRequest("/unittype/findall"); //calling the ajax request func in coommon func.js
  let itemStatus = getServiceRequest("/itemstatus/findall"); //calling the ajax request func in coommon func.js
  let itemSubCategory = getServiceRequest("/subcategory/findall"); //calling the ajax request func in coommon func.js

  //reusable function for select list(elementid,massege,dtaalistname,prportyname of the datalist)
  fillDataintoSelect(
    itemCategorySelect,
    "Select Item Category",
    itemCategory,
    "name"
  );
  //brand eka
  fillDataintoSelect(itemBrandSelect, "Select Item Brand", itemBrand, "name");

  //subcategory
  fillDataintoSelect(
    itemSubcategorySelect,
    "Select Sub-Category",
    itemSubCategory,
    "name"
  );

  fillDataintoSelect(
    itemPackageTypeSelect,
    "Select Item Package Type",
    itemPackageType,
    "name"
  );
  fillDataintoSelect(
    itemUnitsSelect,
    "Select Item Unit Type",
    itemUnitType,
    "name"
  );
  fillDataintoSelect(
    itemStatusSelect,
    "Select Item status",
    itemStatus,
    "name"
  );
  //set item status aailable when loading form
  itemStatusSelect.value = JSON.stringify(itemStatus[0]); //[0] is "available" in item status table
  item.item_status_id = JSON.parse(itemStatusSelect.value);

  // //Need to clear the colors

  setToDefault([
    itemCategorySelect,
    itemBrandSelect,
    itemSubcategorySelect,
    itemPackageTypeSelect,
    itemUnitsSelect,
    itemStatusSelect,
    txtItemSize,
    txtItemName,
    txtRop,
    txtRoq,
    txtpurchasePrice,
    txtProfitRatio,
    txtSalesPrice,
    txtItemNote,
  ]);

  //set color for itemstatus
  itemStatusSelect.classList.remove("is-invalid");
  itemStatusSelect.classList.add("is-valid");

  //disable update button,Enable submit button
  // updateButton.style.visibility="hidden";
  // submitButton.style.visibility="visible";

  updateButton.style.display = "none";
  submitButton.removeAttribute("style");
};


//clearing the selected image
const clearSelectedPhotoFile=()=>{

  itemPhotoFile.value="";//clearing image file input field
  itemPhotoPreview.src="images/defaultitemimage.jpg"; //default photo
}

//refresh Subcategory form
const refreshSubCategoryForm = () => {
  //clear form values
  itemCategorySelect2.value="";

  subcategory = new Object(); //creating a new object

  let itemCategorynew = getServiceRequest("/category/findall"); //calling the ajax request func in coommon func.js
console.log(itemCategorynew);

  //reusable function for select list(elementid,massege,dtaalistname,prportyname of the datalist)
  fillDataintoSelect(
    itemCategorySelect2,
    "Select Item Category",
    itemCategorynew,
    "name"
  );

  setToDefault([itemCategorySelect2, txtSubCategoryName]);//remove colors
};

//check  Subcategory form errors
const checkSubCategoryFormErrors = () => {
  let errors = "";
  if (subcategory.item_category_id == null) {
    errors = errors + "Please Select Item Category \n";
  }
  if (subcategory.name == null) {
    errors = errors + "Please Enter Sub-Category Name\n";
  }
  return errors;
};

//Subcategory form submit event Function
const subCategoryFormSubmitButton = () => {
  console.log(" subcategory form submit");
  console.log(subcategory);
  console.log(subcategory.item_category_id.name);

  //check form error for required fields
  let errors = checkSubCategoryFormErrors(); //call the error function

  if (errors == "") {
    //no errors
    //need to get user confirmation
    let userConfirmation = window.confirm(
      "Are You sure you want to add the following Sub Category .. ?" +
        "\nItem Category :" +
        subcategory.item_category_id.name +
        "\nItem Sub-Category :" +
        subcategory.name
    );

    if (userConfirmation) {
      //Call post service(url,method,data) data means object name-->subcategory
      let postServiceResponse = getHTTPServiceRequest(
        "/subcategory/insert",
        "POST",
        subcategory
      );
      if (postServiceResponse == "OK") {
        window.alert("Submission Successfull !..\n");
        refreshSubCategoryForm(); //refresh subcategory form
        $("#subCategoryCollapse").collapse("hide"); //Hide collapse

        let subcategories = getServiceRequest("/subcategory/findall"); //calling the ajax request func in coommon func.js
        //reusable function for select list(elementid,massege,dtaalistname,prportyname of the datalist)
        //subcategory
        fillDataintoSelect(
          itemSubcategorySelect,
          "Select Sub-Category",
          subcategories,
          "name"
        );
        //fill the newest subcategory automaticllay
        itemSubcategorySelect.value = JSON.stringify(subcategories[0]); //subcategories[0] is the newsest added sub category

        //bind
        item.item_sub_category_id=subcategories[0];
        //add colors
        itemSubcategorySelect.classList.remove("is-invalid");
        itemSubcategorySelect.classList.add("is-valid");

        
      } else {
        window.alert("Submission Failed !..\n" + postServiceResponse);
      }
    }
  } else {
    window.alert("Form Contains Following Errors !..\n" + errors);
  }
};

//check form errors
const checkItemFormErrors = () => {
  let errors = "";
  if (item.item_sub_category_id.item_category_id == null) {
    errors = errors + "Please Select Item Category \n";
  }
  if (item.item_brand_id == null) {
    errors = errors + "Please Select Item Brand \n";
  }
  if (item.item_sub_category_id == null) {
    errors = errors + "Please Select Item Sub-Category \n";
  }
  if (item.itemname == null) {
    errors = errors + "Please Enter Item Name \n";
  }
  if (item.package_type_id == null) {
    errors = errors + "Please Select Package type \n";
  }
  if (item.item_status_id == null) {
    errors = errors + "Please Select Item Status \n";
  }
  if (item.purchase_price == null) {
    errors = errors + "Please Enter Purchase Price \n";
  }
  if (item.profit_ratio == null) {
    errors = errors + "Please Enter Profit Ratio\n";
  }
  if (item.sales_price == null) {
    errors = errors + "Please Enter Sales Price \n";
  }

  if (item.unit_size == null) {
    errors = errors + "Please Enter Unit Size \n";
  }
  if (item.unit_type_id == null) {
    errors = errors + "Please Select Unit Type \n";
  }
  if (item.rop == null) {
    errors = errors + "Please Select ROP \n";
  }
  if (item.roq == null) {
    errors = errors + "Please Enter ROQ \n";
  }

  return errors;
};

//Item form submit event Function
const itemSubmitButton = () => {
  console.log(item);
  console.log("item Submit");

  //check form error for required fields
  let errors = checkItemFormErrors(); //call the error function
  if (errors == "") {
    //no errors
    //need to get user confirmation
    let userConfirmation = window.confirm(
      "Are You sure you want to add the following Item .. ?" +
        "\nItem Category :" +
        item.item_sub_category_id.item_category_id.name +
        "\nItem Brand:" +
        item.item_brand_id.name +
        "\nItem Sub-Category :" +
        item.item_sub_category_id.name +
        "\nItem Package Type :" +
        item.package_type_id.name +
        "\nItem Package Size :" +
        item.unit_size +
        item.unit_type_id.name +
        "\nItem Status:" +
        item.item_status_id.name +
        "\nItem Name:" +
        item.itemname +
        "\nROP :" +
        item.rop +
        "\nROQ :" +
        item.roq +
        "\nPurchase Price :" +
        item.purchase_price +
        "\nProfit Ratio :" +
        item.profit_ratio +
        "\nSales Price:" +
        item.sales_price
    );
    if (userConfirmation) {
      //Call post service(url,method,data) data means object name-->employee
      let postServiceResponse = getHTTPServiceRequest(
        "/item/insert",
        "POST",
        item
      );
      if (postServiceResponse == "OK") {
        window.alert("Submission Successfull !..\n");
        refreshItemTable(); //refresh item table
        // window.location.reload(); full browser reload -->reload every image&...
        refreshItemForm(); //refresh item form
        $("#itemFormModal").modal("hide"); //Hide modal
      } else {
        window.alert("Submission Failed !..\n" + postServiceResponse);
      }
    }
  } else {
    window.alert("Form Contains Following Errors !..\n" + errors);
  }

  refreshItemTable();
};

//check for updates
const checkItemUpdates = () => {
  let updates = "";

  console.log(item);//if there is an update only the item variable will be modified since its the passing object in frontend 
  console.log(oldItem);

  if (item != null && oldItem != null) {
    if (
      item.item_sub_category_id.item_category_id.name !=
      oldItem.item_sub_category_id.item_category_id.name
    ) {
      updates =
        updates +
        "Item Category changed from " +
        oldItem.item_sub_category_id.item_category_id.name +
        " into " +
        item.item_sub_category_id.item_category_id.name +
        "\n";
    }
    if (item.item_brand_id.name != oldItem.item_brand_id.name) {
      updates =
        updates +
        "Item Brand changed from " +
        oldItem.item_brand_id.name +
        " into " +
        item.item_brand_id.name +
        "\n";
    }
    if (item.itemname != oldItem.itemname) {
      updates =
        updates +
        "Item Name changed from " +
        oldItem.itemname +
        " into " +
        item.itemname +
        "\n";
    }
    if (item.item_sub_category_id.name != oldItem.item_sub_category_id.name) {
      updates =
        updates +
        "Item Sub-Category changed from " +
        oldItem.item_sub_category_id.name +
        " into " +
        item.item_sub_category_id.name +
        "\n";
    }
    if (item.package_type_id.name != oldItem.package_type_id.name) {
      updates =
        updates +
        "Package Type changed from " +
        oldItem.package_type_id.name +
        " into " +
        item.package_type_id.name +
        "\n";
    }
    if (item.profit_ratio != oldItem.profit_ratio) {
      updates =
        updates +
        "Profit Ratio changed from " +
        oldItem.profit_ratio +
        " into " +
        item.profit_ratio +
        "\n";
    }
    if (item.item_status_id.name != oldItem.item_status_id.name) {
      updates =
        updates +
        "Item Status changed from " +
        oldItem.item_status_id.name +
        " into " +
        item.item_status_id.name +
        "\n";
    }
    if (item.unit_size != oldItem.unit_size) {
      updates =
        updates +
        "Unit Size changed from " +
        oldItem.unit_size +
        " into " +
        item.unit_size +
        "\n";
    }
    if (item.unit_type_id.name != oldItem.unit_type_id.name) {
      updates =
        updates +
        "Unit Type changed from " +
        oldItem.unit_type_id.name +
        " into " +
        item.unit_type_id.name +
        "\n";
    }
    if (item.purchase_price != oldItem.purchase_price) {
      updates =
        updates +
        "Purchase Price changed from " +
        oldItem.purchase_price +
        " into " +
        item.purchase_price +
        "\n";
    }
    if (item.sales_price != oldItem.sales_price) {
      updates =
        updates +
        "Sales Price changed from " +
        oldItem.sales_price +
        " into " +
        item.sales_price +
        "\n";
    }
    if (item.rop != oldItem.rop) {
      updates =
        updates +
        "ROP changed from " +
        oldItem.rop +
        " into " +
        item.rop +
        "\n";
    }
    if (item.roq != oldItem.roq) {
      updates =
        updates +
        "ROQ changed from " +
        oldItem.roq +
        " into " +
        item.roq +
        "\n";
    }
    if (item.item_photo!=oldItem.item_photo) {
      updates=updates+"Item Photo Changed\n";
    }
      if (item.note != oldItem.note) {
      updates =
        updates +
        "Note changed from " +
        oldItem.note +
        " into " +
        item.note +
        "\n";
    }
  }

  return updates;
};

//Item Form update event function
const itemUpdateButton = () => {
  //check for form eroors
  let errors = checkItemFormErrors();
  if (errors == "") {
    //check for Item Form updates
    let updates = checkItemUpdates();
    if (updates == "") {
      window.alert("Form Contains No Updates..!");
    } else {
      //Need user confirmation
      let userConfirmation = window.confirm(
        "Are you Sure you want to update the following changes ?\n" + updates
      );
      if (userConfirmation) {
        //call put service

        let putServiceResponse = getHTTPServiceRequest(
          "/item/update",
          "PUT",
          item
        );
        if (putServiceResponse == "OK") {
          window.alert("Form update Successfull..!");
          refreshItemForm();
          $("#itemFormModal").modal("hide"); //Hide modal
        } else {
          window.alert("Form Update Unsucessfull..!\n" + putServiceResponse);
        }
      }
    }
  } else {
    window.alert("Form Contains Following Errors !..\n" + errors);
  }

  refreshItemTable();
};

//Item Form Delete function
const DeleteItem = (dataOb, rowIndex) => {
  refreshItemTable();
};

//function to filter brand and sub category based on category selection
let selectItemCategoryElement = document.querySelector("#itemCategorySelect");
selectItemCategoryElement.addEventListener("change", () => {
  category = JSON.parse(selectItemCategoryElement.value);
  selectItemCategoryElement.classList.remove("is-invalid");
  selectItemCategoryElement.classList.add("is-valid");

  /* 
  if (category.name == "Rice") {
    //elementId.disabled="disabled"; or elementId.classList("d-none");
    txtRop.disabled = "disabled";
    txtRoq.disabled = "";
  }
  if (category.name == "Milk") {
    //elementId.disabled="disabled"; or elementId.classList("d-none");
    txtRoq.disabled = "disabled";
    txtRop.disabled = "";
  } */
  // //set value for item name input
  txtItemName.value = category.name; //(idname.value=jsonvariablecreated.attributename)

  //filtered sub category list based on category
  //getServiceRequest("/subcategory/bycategory?categoryid="+category.id+"&abc="+category.nmae);
  let itemSubCategorybyCategory = getServiceRequest("/subcategory/bycategory?categoryid=" + category.id); //calling the ajax request func in coommon func.js
  fillDataintoSelect(
    itemSubcategorySelect,
    "Select Item sub-Category",
    itemSubCategorybyCategory,
    "name"
  );

  item.item_sub_category_id = null;
  //itemSubcategorySelect.style.border="1px solid #ced4da";
  itemSubcategorySelect.classList.remove("is-invalid");
  itemSubcategorySelect.classList.remove("is-valid");

  //filtered Brand list based on category
  //getServiceRequest("/subcategory/bycategory?categoryid="+category.id+"&abc="+category.nmae);
  let itemBrandbyCategory = getServiceRequest("/brand/bycategory/" + category.id); //calling the ajax request func in coommon func.js
  //reusable function for select list(elementid,massege,dtaalistname,prportyname of the datalist)
  fillDataintoSelect(
    itemBrandSelect,
    "Select Item Brand",
    itemBrandbyCategory,
    "name"
  );

  item.item_brand_id = null;
  itemBrandSelect.classList.remove("is-invalid");
  itemBrandSelect.classList.remove("is-valid");
});

//function to filter item name  based on subcategory,brand,packagetype,unitsize selection
let selectUnitTypeElement = document.querySelector("#itemUnitsSelect");
selectUnitTypeElement.addEventListener("change", () => {
  selectUnitTypeElement.classList.remove("is-invalid");
  selectUnitTypeElement.classList.add("is-valid");

  item.unit_type_id = JSON.parse(selectUnitTypeElement.value);
  console.log(item.unit_type_id);

  generateItemName();
});

//create function for generate item name
const generateItemName = () => {
  let subcategory = JSON.parse(itemSubcategorySelect.value);
  let itembrand = JSON.parse(itemBrandSelect.value);
  let packagetype = JSON.parse(itemPackageTypeSelect.value);
  let unittype = JSON.parse(itemUnitsSelect.value);
  let unitsize = txtItemSize.value; //text element nisa json parse one na

  if (
    item.item_sub_category_id != null &&
    item.item_brand_id != null &&
    item.package_type_id != null &&
    item.unit_type_id != null &&
    item.unit_size != null
  ) {
    //set value for item input
    txtItemName.value =
      itembrand.name +
      " " +
      subcategory.name +
      " " +
      unitsize +
      " " +
      unittype.name +
      " " +
      packagetype.name;
    //(idname.value=jsonvariablecreated.attributename)
    item.itemname = txtItemName.value;
    txtItemName.classList.remove("is-invalid");
    txtItemName.classList.add("is-valid");
    console.log(txtItemName.value);
  } else {
    //set value for item input
    txtItemName.value = "";
    //(idname.value=jsonvariablecreated.attributename)
    item.itemname = null;
    txtItemName.classList.remove("is-invalid");
    txtItemName.classList.remove("is-valid");
    console.log(null);
  }
};

//function to filter sales price based on purcahse price and profit ratio selection
let profitRatioElement = document.querySelector("#txtProfitRatio");
profitRatioElement.addEventListener("keyup", () => {
  let purchasePrice = parseFloat(txtpurchasePrice.value); //these are text elemets so json parse not needed
  let profitRatio = parseFloat(profitRatioElement.value);
  profitRatioElement.classList.remove("is-invalid");
  profitRatioElement.classList.add("is-valid");

  let ratio=(profitRatio + 100)*0.01;
  console.log(ratio);
  
  let salesPrice = purchasePrice *ratio;

  txtSalesPrice.value = parseFloat(salesPrice).toFixed(2);
  item.sales_price = txtSalesPrice.value;
  txtSalesPrice.classList.remove("is-invalid");
  txtSalesPrice.classList.add("is-valid");
});
