//Browser load event
window.addEventListener("load", () => {
  console.log("load");

  //enable tooltip
  $('[data-bs-toggle="tooltip"]').tooltip();

  refreshSupplierPaymentTable();

  refreshSupplierPaymentForm();
    

});

//refresh table area
const refreshSupplierPaymentTable = () => {
  //
  // actionButtons.style.display = "none"; // added for table style 3
  //table

  //calling the ajax request func in coommon func.js to get data
  supplierpayments = getServiceRequest("/supplierpayment/findall");

  //Datatypes
  //string --> date/string/number
  //function-->object/array/boolean
  //decimal-->decimal/price
  let columnList = [
    { columnName: "bill_no", dataType: "string" },
    { columnName: getSupplier, dataType: "function" },
    { columnName: "total_amount", dataType: "decimal" },
    { columnName: "paid_amount", dataType: "decimal" },
    { columnName: "balance_amount", dataType: "decimal" },
    { columnName: getPaymentMethod, dataType: "function" }
  ];

  //call the common function to fill data into table(tablebody id,datalist name,column list,edit parameter,
  //delete parameter,view parameter,button visibility)
  // fillDataintoTable(supplierPaymentTableBody,supplierpayments,columnList,supplierPaymentEdit,supplierPaymentDelete,supplierPaymentView,true);
  fillDataintoTableTwo(
    supplierPaymentTableBody,
    supplierpayments, // Array of objects (e.g., [dataOb1, dataOb2, ...])
    columnList,
    supplierPaymentEdit,
    supplierPaymentDelete,
    supplierPaymentView,
    true
  );
  // fillDataintoTableThree(supplierPaymentTableBody,employees,columnList,true);


  //disabling modifying buttons based on conditions
  for (const index in supplierpayments) {

    if (supplierpayments[index].purchase_order_status_id.name=="Deleted") {
    const row = supplierPaymentTableBody.children[index];         // get the <tr>
    const lastCell = row.lastElementChild;                      // get the last <td>
    const deleteBtn = lastCell.querySelector("ul li:nth-child(3) button"); // third li button = Delete    
    deleteBtn.disabled="disabled";//deleteBtn.classList.add("d-none") for hide delete btn
  }
  }

  $("#supplierPaymentTable").DataTable();
};

//function to get Item List --If items need to be shown in the Main table
/* const getItemList = (dataOb) => {
  let supplierPaymentHasGrnList = dataOb.supplierPaymentHasGrnList;
  console.log(supplierPaymentHasGrnList.length );
  
  let itemNames="";
  supplierPaymentHasGrnList.forEach((itemObj, index) => {
    const itemName = itemObj.item_id.itemname;
    if (supplierPaymentHasGrnList.length - 1 == index) {
      itemNames = itemNames +itemName; //remove the comma if its the last value
    } else {
      itemNames = itemNames+itemName+",";
    }
  });
  return itemNames;
}; */


//function to get supplier List
const getSupplier = (dataOb) => {
  return dataOb.supplier_id.suppliername;
};

//function to get supplier payments method
const getPaymentMethod=(dataOb)=>{
 return dataOb.payment_method_id.name;
}


//function for edit/refill row
const supplierPaymentEdit = (dataOb, index) => {
  //old supplierPayment and supplierPayment for update checking
  supplierPayment = JSON.parse(JSON.stringify(dataOb));//if there is an update only the supplierpayment variable will be modified since its the passing object in frontend
  oldsupplierPayment = JSON.parse(JSON.stringify(dataOb));

  console.log("Edit", dataOb, index);
  //tableBodysupplierPayment.children[index].style.border="2px solid black";

  //refill the form

  //supplier select list
  supplierSelect.value = JSON.stringify(dataOb.supplier_id); //object ekk nisa (dynamic ewge)
  supplierSelect.disabled="disabled";//disabling supplier selection at refill/edit need to enable in refreshform function
  supplierSelect.classList.remove("is-invalid");
  supplierSelect.classList.add("is-valid");
 
  //toatal amount
  txtTotalAmount.disabled="disabled";//it will automatically refill by calling the refreshSupplierPaymentInnerForm() function at end 

  //payment method
  paymentMethodSelect.value=JSON.stringify(dataOb.payment_method_id);// a dynamic selct lsit , e nisa json parse krnw
  paymentMethodSelect.classList.remove("is-invalid");
  paymentMethodSelect.classList.add("is-valid");

  //paid amount
  txtPaidAmount.value=dataOb.paid_amount;
  txtPaidAmount.classList.remove("is-invalid");//filling the colors
  txtPaidAmount.classList.add("is-valid");

  //balance amount
  txtBalanceAmount.disabled="disabled";
  txtBalanceAmount.value=dataOb.balance_amount;
  txtBalanceAmount.classList.remove("is-invalid");//filling the colors
  txtBalanceAmount.classList.add("is-valid");


  //required nati nisa
  if (dataOb.txtNote == null) {
    txtNote.value = " ";
  } else {
    txtNote.value = dataOb.note;
  }
 
  $("#supplierPaymentFormModal").modal("show"); //show modal

  //disable submit button,Enable update button in edit function
  supPaymentSubmitButton.style.display = "none";
  supPaymentUpdateButton.removeAttribute("style");//removing the style which will show the button because mek hide krl tiyennne submit function ekedi
  refreshSupplierPaymentInnerForm();

  

 
};

//function for delete row
const supplierPaymentDelete = (dataOb, index) => {
  console.log("Delete", dataOb, index);



   //need to get user confirmation
    let userConfirmation=window.confirm("Are You sure you want to delete the following Supplier Payment .. ?"+
      "\Bill No :"+dataOb.bill_no +
      "\nSupplier :"+dataOb.supplier_id.suppliername +
      "\nTotal Amount:"+dataOb.total_amount +
      "\nPayment Method:"+dataOb.payment_method_id.name +
      "\nPaid Amount :"+dataOb.paid_amount +
      "\Balance Amount :"+dataOb.balance_amount

    );
    if (userConfirmation) {
       //Call delete service
       let deleteResponse=getHTTPServiceRequest("/supplierPayment/delete","DELETE",dataOb);
      if (deleteResponse=="OK") {

        window.alert("Delete Successfull !..\n");
        refreshSupplierPaymentTable();//refresh purchase order table
        // window.location.reload(); full browser reload -->reload every image&...
        refreshSupplierPaymentForm();//refresh purchase order form

      } else {
        window.alert("Submission Failed !..\n"+deleteResponse);
      }
    }
};

//function for view/print row
const supplierPaymentView = (dataOb, index) => {
  console.log("View", dataOb, index);

  //option 1

  //how to open a new tab and enter html tags and styles using js

  /* 
  let newTab=window.open();
  let printTab="<head><title>Employee Print</title>"+
  "<link rel='stylesheet' href='../resources/bootstrap-5.2.3/css/bootstrap.min.css'></head>"+
  "<body><table class='table table-striped'><tr><th>Full Name</th><td>"+dataOb.fullname+"</td></tr></table></body>";
  newTab.document.write(printTab);

  setTimeout(()=>{
    //what should happen after 1500 ms
    newTab.stop();
    newTab.print();
    newTab.close();
  },1500) */

  //option 2 view in  a modal

//setting the values to the view modal in frontend
  sup_pay_bill_no.innerText = dataOb.bill_no;
  sup_pay_supplier.innerText = dataOb.supplier_id.suppliername;;
  sup_pay_total_amount.innerText = dataOb.total_amount;
  sup_pay_paid_amount.innerText = dataOb.paid_amount;
  sup_pay_balance_amount.innerText = dataOb.balance_amount;
  sup_pay_payment_method.innerText = dataOb.payment_method_id.name;


  $("#supplierPaymentFormModalView").modal("show"); //show modal
};

//option 2 Print row new tab open
const printButtonRow = () => {
  let newTab = window.open();
  let printTab =
  "<head><title>Supplier Payment Print</title>" +
"<link rel='stylesheet' href='bootstrap-5.2.3/css/bootstrap.min.css'>" +
"</head>" +
"<body>" +
"<h4 class='text-center mt-3'>Supplier Payment Print</h4>" +
"<div class='container mt-3'>" +
"  <div class='row justify-content-center'>" +
"    <div class='col-md-8'>" + supplierPaymentTableView.outerHTML + "</div>" +
"  </div>" +
"</div>" +
"</body>";
  newTab.document.write(printTab);
  
  setTimeout(() => {
    //what should happen after 1500 ms
    newTab.stop();
    newTab.print();
    newTab.close();
  }, 1500);
};

/* *************************************************************************** */
/* **************************  FORM *********************************************/

//refresh form area
const refreshSupplierPaymentForm = () => {
  //static element only is cleared
  //Cleaning the values(select list not needed dynamic nm )

  formSupplierPayment.reset(); //clearing the form values

  supplierPayment = new Object(); //creating a new object
  supplierPayment.supplierPaymentHasGrnList = new Array();
  supplierSelect.disabled="";//disabling supplier selection at refill/edit need to enable in refreshform function


   //refilling the dynamic elements
   let supplier = getServiceRequest("/supplier/findall"); //calling the ajax request func in coommon func.js

   //calling reusable function for select list(elementid,massege,dtaalistname,prportyname of the datalist)
    fillDataintoSelect(
      supplierSelect,
      "Select Supplier",
      supplier,
      "suppliername"
    );

 
  //purchase order status select list
  let supplierPaymentMethod = getServiceRequest("/supplierpaymentmethod/findall"); //calling the ajax request func in coommon func.js

  //calling reusable function for select list(elementid,massege,dtaalistname,prportyname of the datalist)
  fillDataintoSelect(
    paymentMethodSelect,
    "Select Payment Method",
    supplierPaymentMethod,
    "name"
  );


  //Need to clear the colors

  setToDefault([
    supplierSelect,
    paymentMethodSelect,
    txtBalanceAmount,
    txtTotalAmount,
    txtNote,
    txtPaidAmount,
    txtChequeNo,
    txtChequeDate,
    txtTransferId,
    txtTranferDate
  ]);

  /*  txtFullname.classList.remove("is-valid");
  //  txtFullname.style.border="1px solid #ced4da";
  civilStatus.classList.remove("is-valid");
  //  civilStatus.style.border="1px solid #ced4da"; */

 
  //disable update button,Enable submit button
  supPaymentUpdateButton.style.display = "none";//
  supPaymentSubmitButton.removeAttribute("style");//show submit button by remoing style set at paymentedit function


   $("#collapsePaymethodCheque").collapse("hide"); 
   $("#collapsePaymethodTransfer").collapse("hide"); 

  refreshSupplierPaymentInnerForm();
};

//check form errors
const checkSupplierPaymentFormErrors = () => {
  let errors = "";
  if (supplierPayment.supplier_id == null) {
    errors = errors + "Please Select Supplier\n";
  }
  if (supplierPayment.total_amount == null) {
    errors = errors + "Please Enter  Toatal Amount\n";
  }
  if (supplierPayment.payment_method_id == null) {
    errors = errors + "Please Select Payment Method\n";
  }
  if (supplierPayment.paid_amount == null) {
    errors = errors + "Please Enter Paid Amount\n";
  }
  if (supplierPayment.balance_amount == null) {
    errors = errors + "Please Enter Balance Amount\n";
  }
  if (supplierPayment.supplierPaymentHasGrnList.length == 0) {
    errors = errors + "Please Enter values to Supplier Payment Grn Inner Form\n";
  }

  return errors;
};

//Supplier payment form submit event Function
const supplierPaymentSubmitButton = (dataOb) => {
  console.log(dataOb);
  console.log(supplierPayment);

  //check form error for required fields
  let errors = checkSupplierPaymentFormErrors(); //call the error function
  if (errors == "") {
    //no errors
    //need to get user confirmation
    let userConfirmation = window.confirm(
      "Are You sure you want to add the following Supplier Payment.. ?" +
      "\nSupplier :"+supplierPayment.supplier_id.suppliername +
      "\nTotal Amount:"+supplierPayment.total_amount +
      "\nPayment Method:"+supplierPayment.payment_method_id.name +
      "\nPaid Amount :"+supplierPayment.paid_amount +
      "\Balance Amount :"+supplierPayment.balance_amount
    );
    if (userConfirmation) {
      //Call post service(url,method,data) data means object name-->supplierPayment
      let postServiceResponse = getHTTPServiceRequest(
        "/supplierPayment/insert",
        "POST",
        supplierPayment
      );
      if (postServiceResponse == "OK") {
        window.alert("Submission Successfull !..\n");
        refreshSupplierPaymentTable(); //refresh supplierPayment table
        // window.location.reload(); full browser reload -->reload every image&...
        refreshSupplierPaymentForm(); //refresh supplierPayment form
        $("#supplierPaymentFormModal").modal("hide"); //Hide modal
      } else {
        window.alert("Submission Failed !..\n" + postServiceResponse);
      }
    }
  } else {
    window.alert("Form Contains Following Errors !..\n" + errors);
  }

  // console.log(supplierPayment);

  refreshSupplierPaymentTable();
};

const checkSupplierPaymentFormUpdates = () => {
  let updates = "";

  console.log(supplierPayment);//if there is an update only the supplierpayment variable will be modified since its the passing object in frontend
  console.log(oldsupplierPayment);

  if (supplierPayment != null && oldsupplierPayment != null) {
   
    
    if (supplierPayment.total_amount != oldsupplierPayment.total_amount) {
      updates =
        updates +
        "Total amount changed from " +
        oldsupplierPayment.total_amount +
        " into " +
        supplierPayment.total_amount +
        "\n";
    }
    
    if (supplierPayment.paid_amount != oldsupplierPayment.paid_amount) {
      updates =
        updates +
        "Paid Amount changed from " +
        oldsupplierPayment.paid_amount +
        " into " +
        supplierPayment.paid_amount +
        "\n";
    }
    if (supplierPayment.balance_amount != oldsupplierPayment.balance_amount) {
      updates =
        updates +
        "Balance Amount changed from " +
        oldsupplierPayment.balance_amount +
        " into " +
        supplierPayment.balance_amount +
        "\n";
    }
    if (supplierPayment.payment_method_id.name != oldsupplierPayment.payment_method_id.name) {
      updates =
        updates +
        "Payment Method changed from " +
        oldsupplierPayment.payment_method_id.name +
        " into " +
        supplierPayment.payment_method_id.name +
        "\n";
    }
  }

  return updates;
};


//supplier payment  Form update event function
const supplierPaymentUpdateButton = () => {
  //check for form eroors
  let errors = checkSupplierPaymentFormErrors();
  if (errors == "") {
    //check for supplier paymentForm updates
    let updates = checkSupplierPaymentFormUpdates();
    if (updates == "") {
      window.alert("Form Contains No Updates..!");
    } else {
      //Need user confirmation
      let userConfirmation = window.confirm(
        "Are you Sure you want to update the following changes ?\n" + updates
      );
      if (userConfirmation) {
        //call put service
 
        let putServiceResponse = getHTTPServiceRequest(
          "/supplierPayment/update",
          "PUT",
          supplierPayment
        );
       
        
        if (putServiceResponse == "OK") {
          window.alert("Form update Successfull..!");
          refreshSupplierPaymentForm();
          $("#supplierPaymentFormModal").modal("hide"); //Hide modal
        } else {
          window.alert("Form Update Unsucessfull..!\n" + putServiceResponse);
        }
      }
    }
  } else {
    window.alert("Form Contains Following Errors !..\n" + errors);
  }

  refreshSupplierPaymentTable();
};

//supplier payment   Form Delete function
const DeleteSupplierPayment = (dataOb, rowIndex) => {
  refreshSupplierPaymentTable();
};

//calculate main form balance amount
const calculateMainBalanceAmount = () => {

    //calculating line price
    let BalanceAmount = (parseFloat(txtTotalAmount.value) - parseFloat(txtPaidAmount.value)).toFixed(2);

    txtBalanceAmount.value = BalanceAmount;
    supplierPayment.balance_amount = BalanceAmount;//binding the value to backend

    //set color
    txtBalanceAmount.classList.remove("is-invalid");
    txtBalanceAmount.classList.add("is-valid");

}


/* *************************************************************************** */
/* ************************** INNER FORM *********************************************/

//define function to filter grn list by existance of inner table(call this in grn select list in supplierPayment.html)
const filterGrnListbyExistance = () => {

 // let selectedItem = JSON.parse(itemSelect.value);//dynamic nm json parse krnn one
   let selectedGrn = supplierPaymentHasGrn.grn_id;//datalist nisa dynmaic neme
   console.log(selectedGrn);
   

    // find the index of a specific grn in a list inside a supplierPayment object.
  let extIndex = supplierPayment.supplierPaymentHasGrnList
    .map((supgrn) => supgrn.grn_id.id)
    .indexOf(selectedGrn.id);

   /*
   supplierPayment.supplierPaymentHasGrnList
      This is assumed to be an array (e.g., a list of grns in a supplier payment).

      Example structure:

      supplierPaymentHasGrnList = [
        { grn_id: { id: 101 } },
        { grn_id: { id: 202 } },
        { grn_id: { id: 303 } }
      ];
      2. .map((supgrn) => supgrn.grn_id.id)
      This transforms the array into just a list of grn IDs.

      From the above example, you'd get:

      [101, 202, 303]
      .indexOf(selectedGrn.id)
      This finds the index of selectedGrn.id in the array of grn IDs.

      If selectedGrn.id = 202, the result would be 1.

      let extIndex = ...
      Stores the index in a variable called extIndex.

      If the selectedGrn.id is not found, extIndex will be -1. */

  if (extIndex != -1) {
    //index exists
    window.alert("Selected Grn already exists....!");
    refreshSupplierPaymentInnerForm();
  } else {

    //need to autaomatically add the values for total amount if have
    // grandtotal here is grn table grand total 
    txtInnerTotalAmount.value=(parseFloat(selectedGrn.net_amount)-parseFloat(selectedGrn.paid_amount)).toFixed(2);//total amount is filled automatically by grn data (grn.netamount-grn.paidamount)
    supplierPaymentHasGrn.total_amount = parseFloat(txtInnerTotalAmount.value).toFixed(2); //total_amount here is total amount supplierpaymenthasgrn total_amount


    //set color for total amount
    txtInnerTotalAmount.classList.remove("is-invalid");
    txtInnerTotalAmount.classList.add("is-valid");
  }
};


//define function to filter grn data list by supplier (need to call this function at supplier dropdown in supplierpayment.html)
const filterGrnListbySupplier = () => {
  //get the grns
  let grns = getServiceRequest("/grn/listbysupplier/" + JSON.parse(supplierSelect.value).id); //calling the ajax request func in coommon func.js

  console.log(grns);

   //filling to Grn datalist
  //calling reusable function for data list(elementid,dtaalistname,prportynameOne,proprtynameTwo of the datalist)
 fillDataintoDataListTwo(
    grnList,
    grns,
    "grn_no"
  );

};



//define function to calculate innerform balance amount(totalamount-balanceamount)-->call function at paidamount innerform input field onkeyip
const calculateInnerBalanceAmount = () => {

    //calculating line price
    let innerBalanceAmount = (parseFloat(txtInnerTotalAmount.value) - parseFloat(txtInnerPaidAmount.value)).toFixed(2);

    txtInnerBalanceAmount.value = innerBalanceAmount;
    supplierPaymentHasGrn.balance_amount = innerBalanceAmount;//binding the value to backend

    //set color
    txtInnerBalanceAmount.classList.remove("is-invalid");
    txtInnerBalanceAmount.classList.add("is-valid");
   

}


//Funtion for inner form
const refreshSupplierPaymentInnerForm = () => {
  //creating a new object
  supplierPaymentHasGrn = new Object();

  //get the grns
    grns = [];

  console.log(supplierSelect.value);
  
  if (supplierSelect.value != "") {
    //get the grns
    grns = getServiceRequest("/grn/listbysupplier/" + JSON.parse(supplierSelect.value).id); //calling the ajax request func in coommon func.js
  } else {
    //get the grns
    grns = getServiceRequest("/grn/findall"); //calling the ajax request func in coommon func.js
  }

  //calling reusable function for select list(elementid,massege,dtaalistname,prportynameOne,proprtynameTwo of the datalist)
 /*  fillDataintoSelectTwo(
    itemSelect,
    "Select Item",
    items,
    "item_no",
    "itemname"
  ); */

   //filling to Grn datalist
    //calling reusable function for data list(elementid,dtaalistname,prportynameOne)
  fillDataintoDataListTwo(
    grnList,
    grns,
    "grn_no"
  );

  //cant reset because it will reset the main form also
  //so need to clear the values
  grnSelect.value="";//clearing datalist
  txtInnerTotalAmount.value = "";
  txtInnerTotalAmount.disabled = "disabled";
  txtInnerPaidAmount.value = "";
  txtInnerBalanceAmount.value = "";
  txtInnerBalanceAmount.disabled = "disabled";
  //itemSelect.value="";//dynamic no need to clear values

  //Need to clear the colors
  setToDefault([grnSelect, txtInnerTotalAmount, txtInnerPaidAmount, txtInnerBalanceAmount]);//grnSelect datalist inpufield id


  //disable update button,Enable submit button
  supplierPaymentInnerGrnUpdateButton.classList.add("d-none");
  supplierPaymentInnerGrnSubmitButton.classList.remove("d-none");

  //refresh inner table

  //Datatypes
  //string --> date/string/number
  //function-->object/array/boolean
  //decimal-->decimal/price
  let columnList = [
    { columnName: getsupplierPaymentGrn, dataType: "function" },
    { columnName: "total_amount", dataType: "decimal" },
    { columnName: "paid_amount", dataType: "decimal" },
    { columnName: "balance_amount", dataType: "decimal" },
  ]; 

  //call the common function to fill data into table(tablebody id,datalist name,column list,edit parameter,
  //delete parameter,view parameter,button visibility)
  // fillDataintoInnerTable(supplierPaymentGrnTableBody,supplierPayments,columnList,supplierPaymentGrnEdit,supplierPaymentGrnDelete,supplierPaymentGrnView,true);
  fillDataintoInnerTable(
    supplierPaymentGrnTableBody,
    supplierPayment.supplierPaymentHasGrnList,
    columnList,
    supplierPaymentGrnEdit,
    supplierPaymentGrnDelete,
    true
  );

  //setting value for  total Amount in main form
  let totalAmount = 0.0;
  for (const orderitem of supplierPayment.supplierPaymentHasGrnList) {//iterate wenwa orderitem supplierPayment.supplierPaymentHasGrnList.-->innerform eke total amount wla ektuwa gnna
    totalAmount = parseFloat(totalAmount) + parseFloat(orderitem.total_amount);//getting the sum of all the totalamount in innerform
  }

  if (totalAmount != 0.0) {
    console.log(totalAmount);
    txtTotalAmount.value = totalAmount.toFixed(2); //two decimal points
    supplierPayment.total_amount = txtTotalAmount.value;//binding the value to backend

    //set color for  total amount in main form
    txtTotalAmount.classList.remove("is-invalid");
    txtTotalAmount.classList.add("is-valid");
  } else {
    console.log("zero", totalAmount);
    //set default color for total amount in main form
    txtTotalAmount.classList.remove("is-invalid");
    txtTotalAmount.classList.remove("is-valid");
    txtTotalAmount.value = "";
  }

  //setting the value for paid amount 
  let paidAmount = 0.0;
  for (const ordergrn of supplierPayment.supplierPaymentHasGrnList) {//iterate wenwa ordergrn supplierPayment.supplierPaymentHasGrnList.-->innerform eke total amount wla ektuwa gnna
    paidAmount = parseFloat(paidAmount) + parseFloat(ordergrn.paid_amount);//getting the sum of all the paidAmount in innerform
  }

  if (paidAmount != 0.0) {
    console.log(paidAmount);
    txtPaidAmount.value = paidAmount.toFixed(2); //two decimal points
    supplierPayment.paid_amount = txtPaidAmount.value;//binding the value to backend

    //set color for  paid amount in main form
    txtPaidAmount.classList.remove("is-invalid");
    txtPaidAmount.classList.add("is-valid");
    calculateMainBalanceAmount();//calculate for main balance amount 
  } else {
    console.log("zero", paidAmount);
    //set default color for paid amount in main form
    txtPaidAmount.classList.remove("is-invalid");
    txtPaidAmount.classList.remove("is-valid");
    txtPaidAmount.value = "";
  }
};

//function to get supplier payment grn no
const getsupplierPaymentGrn = (dataOb) => {
  return dataOb.grn_id.grn_no;
};

//function for inner form  edit/refill
const supplierPaymentGrnEdit = (dataOb, index) => {

  innerFormIndex=index;//innserform row index

  //if there is an update only the supplierPaymentHasGrn variable will be modified since its the passing object in frontend 
  supplierPaymentHasGrn = JSON.parse(JSON.stringify(dataOb)); // Working copy for editing
  oldsupplierPaymentHasGrn = JSON.parse(JSON.stringify(dataOb)); // Original copy for comparison


  /* JSON.stringify(dataOb) converts the object to a JSON string
JSON.parse() converts that JSON string back to a JavaScript object
This creates a completely new object with the same data */

  //filling to grn no to datalist
  grnSelect.value=supplierPaymentHasGrn.grn_id.grn_no;

  //itemSelect.disabled = "disabled"; //disabling item selection
  grnSelect.disabled = "disabled"; //disabling grn selection
  grnSelect.classList.remove("is-invalid");
  grnSelect.classList.add("is-valid");

 
  txtInnerTotalAmount.value = parseFloat(supplierPaymentHasGrn.total_amount);
  txtInnerPaidAmount.value = parseFloat(supplierPaymentHasGrn.paid_amount);
  txtBalanceAmount.value = parseFloat(supplierPaymentHasGrn.balance_amount);

  //disable submit button,Enable update button
  supplierPaymentInnerGrnUpdateButton.classList.remove("d-none");
  supplierPaymentInnerGrnSubmitButton.classList.add("d-none");
};

//function for inner form delete
const supplierPaymentGrnDelete = (dataOb, index) => {
  //need to get user confirmation
  let userConfirmation = window.confirm(
    "Are You sure you want to Remove the following Grn .. ?" +
     "\nGrn No :" +
      dataOb.grn_id.grn_no +
      "\nTotal Amount :" +
      dataOb.total_amount +
      "\nPaid Amount :" +
      dataOb.paid_amount +
      "\nBalance Amount:" +
      dataOb.balance_amount
  );
  if (userConfirmation) {
    window.alert("Delete Successfull !..\n");

    //remove an existing GRN record from the inner form list (supplierPaymentHasGrnList) if it already exists — based on grn_id.
    let extIndex = supplierPayment.supplierPaymentHasGrnList
      .map((orderitem) => orderitem.grn_id.id)//Extracts a list of all grn_id.id values from the supplierPaymentHasGrnList (ex:-[101, 102, 103])
      .indexOf(dataOb.grn_id.id);//Searches for the index of the GRN ID from dataOb in that list.Returns:0, 1, 2, etc., if found,-1 if not found
    if (extIndex != -1) {
      supplierPayment.supplierPaymentHasGrnList.splice(extIndex, 1);//Removes one item at the index extIndex.Effectively deletes that GRN from the inner form list.
    }
    // window.location.reload(); full browser reload -->reload every image&...
  } else {
    window.alert("Form Contains Errors !..\n");
  }

  refreshSupplierPaymentInnerForm(); //refresh supplier payment inner form
};

//function for inner form submit
const supplierPaymentGrnSubmitButton = () => {
  console.log(supplierPaymentHasGrn);

  //need to get user confirmation
  let userConfirmation = window.confirm(
    "Are You sure you want to add the following Grn .. ?" +
      "\nGrn No :" +
      supplierPaymentHasGrn.grn_id.grn_no +
      "\nTotal Amount :" +
      supplierPaymentHasGrn.total_amount +
      "\nPaid Amount :" +
      supplierPaymentHasGrn.paid_amount +
      "\nBalance Amount:" +
      supplierPaymentHasGrn.balance_amount
  );
  if (userConfirmation) {
    window.alert("Submission Successfull !..\n");
    supplierPayment.supplierPaymentHasGrnList.push(supplierPaymentHasGrn);//It adds a new  payment record (supplierPaymentHasGrn) to the array supplierPayment.supplierPaymentHasGrnList.
    // window.location.reload(); full browser reload -->reload every image&...
    refreshSupplierPaymentInnerForm(); //refresh purchase order inner form
  } else {
    window.alert("Form Contains Errors !..\n");
  }

  // console.log(employee);

  refreshSupplierPaymentInnerForm();
};

//function for innerform update
const supplierPaymentGrnUpdateButton = () => {
  console.log(supplierPaymentHasGrn);

  if (supplierPaymentHasGrn.paid_amount != oldsupplierPaymentHasGrn.paid_amount) {
    //need to get user confirmation
    let userConfirmation = window.confirm(
      "Are You Sure you want to update the following changes.. ?" +
        "\nPaid Amount Changed from :" +oldsupplierPaymentHasGrn.paid_amount+" to "+supplierPaymentHasGrn.paid_amount+
        +"\nBalance Amount Changed from :" +oldsupplierPaymentHasGrn.balance_amount+" to "+supplierPaymentHasGrn.balance_amount
        
    );

    if (userConfirmation) {
      window.alert("Update Successfull !..\n");
      supplierPayment.supplierPaymentHasGrnList[innerFormIndex]=supplierPaymentHasGrn;//meken krnne supplierPayment.supplierPaymentHasGrnList array eke index eka ta adala row eka update krnwa
      // window.location.reload(); full browser reload -->reload every image&...
      refreshSupplierPaymentInnerForm(); //refresh purchase order inner form
    } else {
      window.alert("Form Contains Errors !..\n");
    }
  }
  else{
    window.alert("Form Contains No Updates..!");
  }
  refreshSupplierPaymentInnerForm();
};

//function to show collapse based on payment method(bank transfer/cheque)
const paymentMethodCollapse=()=>{// supPaymentUpdateButton.style.display = "none";//
  console.log(supplierPayment);
  
  if (supplierPayment.payment_method_id.name=="Bank-Transfer") {
    console.log(supplierPayment.payment_method_id.name);
  
   // chequeCollapse.classList.add("d-none");//hide cheque collapse
    $("#collapsePaymethodCheque").collapse("hide"); //hide collapse
     $("#collapsePaymethodTransfer").collapse("show"); //show collapse
    
    
    
  }
  if (supplierPayment.payment_method_id.name=="Cheque") {
     console.log(supplierPayment.payment_method_id.name);
       //bankTransferCollase.classList.add("d-none");//hide bank transfer collapse
      $("#collapsePaymethodTransfer").collapse("hide"); //hide collapse
      $("#collapsePaymethodCheque").collapse("show"); //show collapse

      
  }
  else{//hide both collapses if other payment method
      $("#collapsePaymethodTransfer").collapse("hide"); //hide collapse
      $("#collapsePaymethodCheque").collapse("hide"); //hide collapse
  }
}



