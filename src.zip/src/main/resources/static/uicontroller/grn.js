//Browser load event
window.addEventListener("load", () => {
  console.log("load");

  //enable tooltip
  $('[data-bs-toggle="tooltip"]').tooltip();

  refreshGrnTable();

  refreshGrnForm();
});

//refresh table area
const refreshGrnTable = () => {
  //
  // actionButtons.style.display = "none"; // added for table style 3
  //table

  //calling the ajax request func in coommon func.js to get data
  grns = getServiceRequest("/grn/findall");

  //Datatypes
  //string --> date/string/number
  //function-->object/array/boolean
  //decimal-->decimal/price
  let columnList = [
    { columnName: "grn_no", dataType: "string" },
    { columnName: getItemList, dataType: "function" },
    { columnName: "grandtotal", dataType: "decimal" },
    { columnName: "received_date", dataType: "string" },
    { columnName: getGrnStatus, dataType: "function" },
  ];

  //call the common function to fill data into table(tablebody id,datalist name,column list,edit parameter,
  //delete parameter,view parameter,button visibility)
  // fillDataintoTable(grnTableBody,grns,columnList,grnEdit,grnDelete,grnView,true);
  fillDataintoTableTwo(
    grnTableBody,
    grns,
    columnList,
    grnEdit,
    grnDelete,
    grnView,
    true
  );
  // fillDataintoTableThree(grnTableBody,grns,columnList,true);

      //disabling modifying buttons based on conditions
   for (const index in grns) {

    if (grns[index].grn_status_id.name=="Deleted") {
    const row = grnTableBody.children[index];         // get the <tr>
    const lastCell = row.lastElementChild;                      // get the last <td>
    const deleteBtn = lastCell.querySelector("ul li:nth-child(3) button"); // third li button = Delete    
    deleteBtn.disabled="disabled";//deleteBtn.classList.add("d-none") for hide delete btn
  }
    
  }

  $("#grnTable").DataTable();
};

//function to get Item List
const getItemList = (dataOb) => {
  let grnHasItemList = dataOb.grnHasItemList;
  console.log(grnHasItemList.length );
  
  let itemNames="";
  grnHasItemList.forEach((itemObj, index) => {
    const itemName = itemObj.item_id.itemname;
    if (grnHasItemList.length - 1 == index) {
      itemNames = itemNames +itemName; //remove the comma if its the last value
    } else {
      itemNames = itemNames+itemName+",";
    }
  });
  return itemNames;
};


//function to get Grn Status
const getGrnStatus = (dataOb) => {

  if (dataOb.grn_status_id.name == "Received") {
    let received =
      "<span class='badge text-bg-primary'>" +
      dataOb.grn_status_id.name +
      "</span>";
    return received;
  }
  if (dataOb.grn_status_id.name == "Completed") {
    let completed =
      "<span class='badge text-bg-success'>" +
      dataOb.grn_status_id.name +
      "</span>";
    return completed;
  }
  if (dataOb.grn_status_id.name == "Deleted") {
    let deleted =
      "<span class='badge text-bg-danger'>" +
      dataOb.grn_status_id.name +
      "</span>";
    return deleted;
  }
};

//function for edit/refill row
const grnEdit = (dataOb, index) => {
  //old grn and grn for update checking
  grn = JSON.parse(JSON.stringify(dataOb));//if there is an update only the grn variable will be modified since its the passing object in frontend 
  oldGrn = JSON.parse(JSON.stringify(dataOb));

  console.log("Edit", dataOb, index);
  //tableBodyPurchaseOrder.children[index].style.border="2px solid black";

  //refill the form
  //txtGrandTotal.value = dataOb.grandtotal; it will automatically refill by calling the refreshGrnInnerForm() function at end
  txtGrandTotal.disabled="disabled";
  txtGrandTotal.classList.remove("is-invalid");
  txtGrandTotal.classList.add("is-valid");

  txtReceivedDate.value = dataOb.received_date;//static
  txtReceivedDate.classList.remove("is-invalid");
  txtReceivedDate.classList.add("is-valid");

  txtDiscountRate.value = dataOb.discount_rate;//static
  txtDiscountRate.classList.remove("is-invalid");
  txtDiscountRate.classList.add("is-valid");

  txtNetAmount.value = dataOb.net_amount;//static
  txtNetAmount.classList.remove("is-invalid");
  txtNetAmount.classList.add("is-valid");

  

  txtBillNo.value = dataOb.billno;//static
  txtBillNo.classList.remove("is-invalid");
  txtBillNo.classList.add("is-valid");

  //supplier select list
  supplierSelect.value = JSON.stringify(dataOb.supplier_id); //object ekk nisa (dynamic ewge)
  supplierSelect.disabled="disabled";//disabling supplier selection at refill/edit need to enable in refreshform function
  supplierSelect.classList.remove("is-invalid");
  supplierSelect.classList.add("is-valid");

  purchaseOrderSelect.value = JSON.stringify(dataOb.purchase_order_id); //dynmaic
  purchaseOrderSelect.disabled="disabled";//disabling supplier selection at refill/edit need to enable in refreshform function
  purchaseOrderSelect.classList.remove("is-invalid");
  purchaseOrderSelect.classList.add("is-valid");

  grnStatusSelect.value = JSON.stringify(dataOb.grn_status_id); //dynmaic (colors are filled beacuse it is already set in the refresh )
 

  //required nati nisa
  if (dataOb.txtNote == null) {
    txtNote.value = " ";
  } else {
    txtNote.value = dataOb.note;
  }
 
  $("#grnFormModal").modal("show"); //show modal

  //disable submit button,Enable update button in edit function
  grnSubmitBtn.style.display = "none";
  grnUpdateBtn.removeAttribute("style");
  refreshGrnInnerForm();

  
 
};

//function for delete row
const grnDelete = (dataOb, index) => {
  console.log("Delete", dataOb, index);


   //need to get user confirmation
    let userConfirmation=window.confirm("Are You sure you want to delete the following Grn .. ?"+
      "\nSupplier :"+dataOb.supplier_id.suppliername +
      "\nPurchase Order No :"+dataOb.purchase_order_id.pod_no +
      "\nBill No :"+dataOb.billno +
      "\nGrand Total :"+dataOb.grandtotal +
      "\nDiscount Rate :"+dataOb.discount_rate +
      "\nNet Amount:"+dataOb.net_amount +
      "\nnRecievedDate :"+dataOb.received_date +
      "\nGrn Status :"+dataOb.grn_status_id.name 

    );
    if (userConfirmation) {
       //Call delete service
       let deleteResponse=getHTTPServiceRequest("/grn/delete","DELETE",dataOb);
      if (deleteResponse=="OK") {

        window.alert("Delete Successfull !..\n");
        refreshGrnTable();//refresh purchase order table
        // window.location.reload(); full browser reload -->reload every image&...
        refreshGrnForm();//refresh purchase order form

      } else {
        window.alert("Submission Failed !..\n"+deleteResponse);
      }
    }
};

//function for view/print row
const grnView = (dataOb, index) => {
  console.log("View", dataOb, index);

  //option 1

  //how to open a new tab and enter html tags and styles using js

  /* 
  let newTab=window.open();
  let printTab="<head><title>Employee Print</title>"+
  "<link rel='stylesheet' href='../resources/bootstrap-5.2.3/css/bootstrap.min.css'></head>"+
  "<body><table class='table table-striped'><tr><th>Full Name</th><td>"+dataOb.fullname+"</td></tr></table></body>";
  newTab.document.write(printTab);

  setTimeout(()=>{
    //what should happen after 1500 ms
    newTab.stop();
    newTab.print();
    newTab.close();
  },1500) */

  //option 2 view in  a modal

  //pod_supllierName.innerText=dataOb.supplier_id.name;
  grn_supplier.innerText = dataOb.supplier_id.suppliername;
  grn_bill_no.innerText = dataOb.billno;
  grn_grand_total.innerText = dataOb.grandtotal;
  grn_net_amount.innerText = dataOb.net_amount;
  grn_discount_rate.innerText = dataOb.discount_rate;
  grn_received_date.innerText = dataOb.received_date;
  grn_status.innerText = dataOb.grn_status_id.name;


  $("#grnFormModalView").modal("show"); //show modal
};

//option 2 Print row new tab open
const printButtonRow = () => {
  let newTab = window.open();
  let printTab =
"<head><title>GRN Print</title>" +
"<link rel='stylesheet' href='bootstrap-5.2.3/css/bootstrap.min.css'>" +
"</head>" +
"<body>" +
"<h4 class='text-center mt-3'>GRN Print</h4>" +
"<div class='container mt-3'>" +
"  <div class='row justify-content-center'>" +
"    <div class='col-md-8'>" + grnTableView.outerHTML + "</div>" +
"  </div>" +
"</div>" +
"</body>";
  newTab.document.write(printTab);


  setTimeout(() => {
    //what should happen after 1500 ms
    newTab.stop();
    newTab.print();
    newTab.close();
  }, 1500);
};

/* *************************************************************************** */
/* **************************  FORM *********************************************/

//refresh form area
const refreshGrnForm = () => {
  //static element only is cleared
  //Cleaning the values(select list not needed dynamic nm )

  formGrn.reset(); //clearing the form values

  grn = new Object(); //creating a new object
  grn.grnHasItemList = new Array();
  supplierSelect.disabled="";//disabling supplier selection at refill/edit need to enable in refreshform function
  purchaseOrderSelect.disabled="";//enable in refreshform function
  
   //refilling the dynamic elements
   let supplier = getServiceRequest("/supplier/findall"); //calling the ajax request func in coommon func.js

   //calling reusable function for select list(elementid,massege,dtaalistname,prportyname of the datalist)
    fillDataintoSelect(
      supplierSelect,
      "Select Supplier",
      supplier,
      "suppliername"
    );



  let purchaseOrder = getServiceRequest("/purchaseorder/findall"); //calling the ajax request func in coommon func.js

   //calling reusable function for select list(elementid,massege,dtaalistname,propertyname of the datalist)
  fillDataintoSelect(
    purchaseOrderSelect,
    "Select Purchase Order",
    purchaseOrder,
    "pod_no"
  );

  //purchase order status select list
  let GrnStatus = getServiceRequest("/grnstatus/findall"); //calling the ajax request func in coommon func.js


 
  //calling reusable function for select list(elementid,massege,dtaalistname,prportyname of the datalist)
  fillDataintoSelect(
    grnStatusSelect,
    "Select Grn Status",
    GrnStatus,
    "name"
  );

  //set grnstatus aailable when loading form
  grnStatusSelect.value = JSON.stringify(GrnStatus[0]); //[0] is "Recieved" in grn status table
  grn.grn_status_id = JSON.parse(
    grnStatusSelect.value
  );

  //Need to clear the colors

  setToDefault([
    purchaseOrderSelect,
    supplierSelect,
    txtReceivedDate,
    txtGrandTotal,
    txtNetAmount,
    txtBillNo,
    txtDiscountRate,
    txtNote,
    grnStatusSelect,
  ]);

  //disabling to enter values for grand total and net amount because they are auto calculated and filled
    txtGrandTotal.disabled="disabled";
    txtNetAmount.disabled="disabled";
   

  /*  txtFullname.classList.remove("is-valid");
  //  txtFullname.style.border="1px solid #ced4da";
  civilStatus.classList.remove("is-valid");
  //  civilStatus.style.border="1px solid #ced4da"; */

  //set color for grn Status
  grnStatusSelect.classList.remove("is-invalid");
  grnStatusSelect.classList.add("is-valid");


  //disable update button,Enable submit button

  grnUpdateBtn.style.display = "none";
  grnSubmitBtn.removeAttribute("style");

  //set min max value for recieved date[YYYY-MM-DD]
  let currentDate = new Date();
  let currentMonth = currentDate.getMonth() + 1; //getMonth gives [0-11] so we need to add 1
  if (currentMonth < 10) {
    currentMonth = "0" + currentMonth;
  }
  let CurrentDay = currentDate.getDate(); //[1-31]
  if (CurrentDay < 10) {
    CurrentDay = "0" + CurrentDay;
  }

 // txtReceivedDate.min =currentDate.getFullYear() + "-" + currentMonth + "-" + CurrentDay;

  

  //after setting the day after 14 days need to check the month again
 /*  let maximumcurrentMonth = currentDate.getMonth() + 1; //getMonth gives [0-11] so we need to add 1
  if (maximumcurrentMonth < 10) {
    maximumcurrentMonth = "0" + maximumcurrentMonth;
  }
  let maximumCurrentDay = currentDate.getDate(); //[1-31]
  if (maximumCurrentDay < 10) {
    maximumCurrentDay = "0" + maximumCurrentDay;
  } */

 // txtReceivedDate.max =currentDate.getFullYear() + "-" +maximumcurrentMonth +"-" +maximumCurrentDay;

  //recieved dte min and max 
  currentDate.setDate(currentDate.getDate() - 14); //substracting 14 days of current date to get the min date
 
  let mincurrentMonth = currentDate.getMonth() +1; //getMonth gives [0-11] so we need to add 1
  if (mincurrentMonth < 10) {
    mincurrentMonth = "0" + mincurrentMonth;
  }

  let minCurrentDay = currentDate.getDate(); //[1-31]
  if (minCurrentDay < 10) {
    minCurrentDay = "0" + minCurrentDay;//recieved day should be a date before today that why this
  } 

 

    //set default zero for discount rate
    txtDiscountRate.value =parseFloat(0).toFixed(2);
    grn.discount_rate=parseFloat(txtDiscountRate.value);
    txtDiscountRate.classList.remove("is-invalid");
    txtDiscountRate.classList.add("is-valid");


  refreshGrnInnerForm();
};

//check form errors
const checkGrnFormErrors = () => {
  let errors = "";
  if (grn.purchase_order_id == null) {
    errors = errors + "Please Select Purchase Order\n";
  }
  if (grn.received_date == null) {
    errors = errors + "Please Enter  Received Date\n";
  }
   if (grn.billno == null) {
    errors = errors + "Please Enter  Bill No\n";
  }
  if (grn.grandtotal == null) {
    errors = errors + "Please Enter Grand Total\n";
  }
  if (grn.net_amount == null) {
    errors = errors + "Please Enter Net Amount\n";
  }
  if (grn.discount_rate == null) {
    errors = errors + "Please Enter Discount Rate \n";
  }
  if (grn.grn_status_id == null) {
    errors = errors + "Please Select  Grn Status\n";
  }
  if (grn.grnHasItemList.length == 0) {
    errors = errors + "Please Select Grn Item\n";
  }

  return errors;
};

//grn form submit event Function
const grnSubmitButton = () => {
  console.log(grn);

  //check form error for required fields
  let errors = checkGrnFormErrors(); //call the error function
  if (errors == "") {
    //no errors
    //need to get user confirmation
    let userConfirmation = window.confirm(
      "Are You sure you want to add the following Grn .. ?" +
      "\nSupplier :"+grn.supplier_id.suppliername +
      "\nPurchase Order No :"+grn.purchase_order_id.pod_no +
      "\nBill No :"+grn.billno +
      "\nGrand Total :"+grn.grandtotal +
      "\nDiscount Rate :"+grn.discount_rate +
      "\nNet Amount:"+grn.net_amount +
      "\nnRecievedDate :"+grn.received_date +
      "\nGrn Status :"+grn.grn_status_id.name 
    );
    if (userConfirmation) {
      //Call post service(url,method,data) data means object name-->grn
      let postServiceResponse = getHTTPServiceRequest(
        "/grn/insert",
        "POST",
        grn
      );
      if (postServiceResponse == "OK") {
        window.alert("Submission Successfull !..\n");
        refreshGrnTable(); //refresh grn table
        // window.location.reload(); full browser reload -->reload every image&...
        refreshGrnForm(); //refresh grn form
        $("#grnFormModal").modal("hide"); //Hide modal
      } else {
        window.alert("Submission Failed !..\n" + postServiceResponse);
      }
    }
  } else {
    window.alert("Form Contains Following Errors !..\n" + errors);
  }

  // console.log(grn);

  refreshGrnTable();
};

//grn check update function
const checkgrnFormUpdates = () => {
  let updates = "";

  console.log(grn);//if there is an update only the grn variable will be modified since its the passing object in frontend 
  console.log(oldGrn);

  if (grn != null && oldGrn != null) {
   
    if (grn.grandtotal != oldGrn.grandtotal) {
      updates =
        updates +
        "Grand Total changed from " +
        oldGrn.grandtotal +
        " into " +
        grn.grandtotal +
        "\n";
    }
     if (grn.net_amount != oldGrn.net_amount) {
      updates =
        updates +
        "Net Amount changed from " +
        oldGrn.net_amount +
        " into " +
        grn.net_amount +
        "\n";
    }
     if (grn.discount_rate != oldGrn.discount_rate) {
      updates =
        updates +
        "Discount Rate changed from " +
        oldGrn.discount_rate +
        " into " +
        grn.discount_rate +
        "\n";
    }
     if (grn.billno != oldGrn.billno) {
      updates =
        updates +
        "Bill No changed from " +
        oldGrn.billno +
        " into " +
        grn.billno +
        "\n";
    }
    if (grn.received_date != oldGrn.received_date) {
      updates =
        updates +
        "Received Date changed from " +
        oldGrn.received_date +
        " into " +
        grn.received_date +
        "\n";
    }
    if (grn.grn_status_id.name != oldGrn.grn_status_id.name) {
      updates =
        updates +
        "Purchase Order Status changed from " +
        oldGrn.grn_status_id.name +
        " into " +
        grn.grn_status_id.name +
        "\n";
    }
  }

  return updates;
};


//grn  Form update event function
const grnUpdateButton = () => {
  //check for form eroors
  let errors = checkGrnFormErrors();
  if (errors == "") {
    //check for grn Form updates
    let updates = checkgrnFormUpdates();
    if (updates == "") {
      window.alert("Form Contains No Updates..!");
    } else {
      //Need user confirmation
      let userConfirmation = window.confirm(
        "Are you Sure you want to update the following changes ?\n" + updates
      );
      if (userConfirmation) {
        //call put service
 
        let putServiceResponse = getHTTPServiceRequest(
          "/grn/update",
          "PUT",
          grn
        );
       
        
        if (putServiceResponse == "OK") {
          window.alert("Form update Successfull..!");
          refreshGrnForm();
          $("#grnFormModal").modal("hide"); //Hide modal
        } else {
          window.alert("Form Update Unsucessfull..!\n" + putServiceResponse);
        }
      }
    }
  } else {
    window.alert("Form Contains Following Errors !..\n" + errors);
  }

  refreshGrnTable();
};

//grn  Form Delete function
const DeleteGrn= (dataOb, rowIndex) => {
  refreshGrnTable();
};




//define function to calculate Net Amount(grandtotal-discount amount)-->call function at discount rate input field onkeyup & grandtotal onkeyup
const calculateNetAmount = () => {
 
    let netAmount=0.00;
    console.log(txtGrandTotal.value);
    
    //calculating Net Amount
    let discountAmount=(parseFloat(txtGrandTotal.value) * parseFloat(txtDiscountRate.value)/100);
     netAmount = (parseFloat(txtGrandTotal.value) - discountAmount).toFixed(2);

    txtNetAmount.value = netAmount;
    grn.net_amount = netAmount;
    grn.discount_rate=parseFloat(txtDiscountRate.value);
    //set color
    txtNetAmount.classList.remove("is-invalid");
    txtNetAmount.classList.add("is-valid");
 
 
};






/* *************************************************************************** */
/* ************************** INNER FORM *********************************************/

//define function to filter item list by existance of inner table(call this in item select list in grn.html)
const filterItemListbyExistance = () => {
 // let selectedItem = JSON.parse(itemSelect.value);no jason prse since data list is used

    // let selectedItem = JSON.parse(itemSelect.value);//dynamic nisa json parse krnwa
  selectedItem = grnHasItem.item_id;
 console.log(selectedItem);
 

   // find the index of a specific item in a list inside a grn object.
 let extIndex = grn.grnHasItemList .map((grnitem) => grnitem.item_id.id).indexOf(selectedItem.id);

  /*
   grn.grnHasItemList
      This is assumed to be an array (e.g., a list of items in a GRN – Goods Received Note).

      Example structure:

      grnHasItemList = [
        { item_id: { id: 101 } },
        { item_id: { id: 202 } },
        { item_id: { id: 303 } }
      ];
      2. .map((grnitem) => grnitem.item_id.id)
      This transforms the array into just a list of item IDs.

      From the above example, you'd get:

      [101, 202, 303]
      .indexOf(selectedItem.id)
      This finds the index of selectedItem.id in the array of item IDs.

      If selectedItem.id = 202, the result would be 1.

      let extIndex = ...
      Stores the index in a variable called extIndex.

      If the selectedItem.id is not found, extIndex will be -1. */
 
  if (extIndex != -1) {
    //index exists
    window.alert("Selected item already exists....!");
    refreshGrnInnerForm();
  } else {
    //need to automatically add the value for unit price if have

    let grnUnitPrice=getServiceRequest("/purchaseorder/unitpricebyitem/"+JSON.parse(purchaseOrderSelect.value).id +"/"+selectedItem.id);
    txtUnitPrice.value = parseFloat(grnUnitPrice).toFixed(2); //purchase_price here is item table purchase price
    grnHasItem.purchase_price = parseFloat(txtUnitPrice.value).toFixed(2); //purchase_price here is unit price grnhasitemtable purchase_price
    
      //set color for unit price
    txtUnitPrice.classList.remove("is-invalid");
    txtUnitPrice.classList.add("is-valid");

   
  
  }
};


//define fnction to filter purchase orders by supplier
const filterPodBySupplier=()=>{
  //get the quotations
  let pods = getServiceRequest("/pod/podlistbysupplier/" + JSON.parse(supplierSelect.value).id); //calling the ajax request func in coommon func.js
  //calling reusable function for select list(elementid,massege,dtaalistname,prportynameOne)
  console.log(pods);
  
  fillDataintoSelect(
    purchaseOrderSelect,
    "Select Purchase Order",
    pods,
    "pod_no",
  ); 
}

//define function to filter item list by purchase order (need to call this function at supplier dropdown in quotation.html)
const filterItemListbyPod= () => {
  //get the items
  let items = getServiceRequest("/item/listbypod/" + JSON.parse(purchaseOrderSelect.value).id); //calling the ajax request func in coommon func.js

  //calling reusable function for select list(elementid,massege,dtaalistname,prportynameOne,proprtynameTwo of the datalist)
 /*  fillDataintoSelectTwo(
    itemSelect,
    "Select Item",
    items,
    "item_no",
    "itemname"
  ); */

   //filling to item datalist
  //calling reusable function for data list(elementid,dtaalistname,prportynameOne,proprtynameTwo of the datalist)
 fillDataintoDataList(
    itemList,
    items,
    "item_no",
    "itemname"
  );

};

//filter quantity based on pod and item selected -->returns just a number not a list-->need to calll in dtalist in html
const filterQtybyPODandItem=()=>{
  console.log(selectedItem);
  
  let qtys = getServiceRequest("/pod/qtybypodanditemid/" + JSON.parse(purchaseOrderSelect.value).id+"/"+selectedItem.id); 

  console.log(qtys);
  txtQty.value=parseInt(qtys);
  txtQty.classList.remove("is-invalid");
  txtQty.classList.add("is-valid");
  grnHasItem.qty=parseInt(txtQty.value);
  calculateLinePrice();
  calculateTotalQty();//calculate tot quantity 
}




//Funtion for inner form
const refreshGrnInnerForm = () => {
  //creating a new object
  grnHasItem = new Object();

  items = [];
  if (purchaseOrderSelect.value != "") {
    //get the items
    items = getServiceRequest("/item/listbypod/" + JSON.parse(purchaseOrderSelect.value).id); //calling the ajax request func in coommon func.js
  } else {
    //get the items
    items = getServiceRequest("/item/findall"); //calling the ajax request func in coommon func.js
  }
  //calling reusable function for select list(elementid,massege,dtaalistname,prportynameOne,proprtynameTwo of the datalist)
/*   fillDataintoSelectTwo(
    itemSelect,
    "Select Item",
    items,
    "item_no",
    "itemname"
  ); */

    //filling to item datalist
    //calling reusable function for data list(elementid,dtaalistname,prportynameOne,proprtynameTwo of the datalist)
 fillDataintoDataList(
    itemList,
    items,
    "item_no",
    "itemname"
  );

  //cant reset because it will reset the main form also
  //so need to clear the values
  textItemName.value="";//clearing datalist
 // itemSelect.disabled = "";
  txtUnitPrice.value = "";
  txtUnitPrice.disabled = "disabled";
  txtQty.value = "";
  txtLinePrice.value = "";
  txtLinePrice.disabled = "disabled";
  txtTotalQty.value = "";
  txtTotalQty.disabled = "disabled";
  txtSellingPrice.value = "";
  txtManufactureDate.value = "";
  txtExpireDate.value = "";
  txtBatchNo.value = "";

 

 
  //itemSelect.value="";//dynamic no need to clear values

  //Need to clear the colors
  setToDefault([textItemName, txtUnitPrice, txtQty, txtLinePrice,txtFreeQty,txtManufactureDate,txtSellingPrice,txtTotalQty,txtExpireDate,txtBatchNo]);

  //disable update button,Enable submit button
  grnInnerItemupdateButton.classList.add("d-none");
  grnInnerItemsubmitButton.classList.remove("d-none");

  //set default zero for free quantity
    txtFreeQty.value =parseFloat(0);
    txtFreeQty.classList.remove("is-invalid");
    txtFreeQty.classList.add("is-valid");

  //refresh inner table

  //Datatypes
  //string --> date/string/number
  //function-->object/array/boolean
  //decimal-->decimal/price
  let columnList = [
    { columnName: getGrnItemName, dataType: "function" },
    { columnName: "purchase_price", dataType: "decimal" },
    { columnName: "qty", dataType: "string" },
    { columnName: "line_price", dataType: "decimal" },
  ];

  //call the common function to fill data into table(tablebody id,datalist name,column list,edit parameter,
  //delete parameter,button visibility)
  // fillDataintoInnerTable(grnItemTableBody,purchaseorders,columnList,grnItemEdit,grnItemDelete,true);
  fillDataintoInnerTable(
    grnItemTableBody,
    grn.grnHasItemList,
    columnList,
    grnItemEdit,
    grnItemDelete,
    true
  );

  //setting value for grand total
  let grandTotal = 0.0;
  for (const orderitem of grn.grnHasItemList) {
    grandTotal = parseFloat(grandTotal) + parseFloat(orderitem.line_price);
  }
  // if (grandTotal != 0.0) {
    console.log(grandTotal);
    txtGrandTotal.value = grandTotal.toFixed(2); //two decimal points
    grn.grandtotal = txtGrandTotal.value;

    //set color for grand total
    txtGrandTotal.classList.remove("is-invalid");
    txtGrandTotal.classList.add("is-valid");
  // } 

  //call function to calculate net amount
  calculateNetAmount();

 
};

//function to get purchase order item name
const getGrnItemName = (dataOb) => {
  return dataOb.item_id.itemname;
};

//function for inner form  edit/refill
const grnItemEdit = (dataOb, index) => {

  innerFormIndex=index;

  //if there is an update only the grnHasItem variable will be modified since its the passing object in frontend 
  grnHasItem = JSON.parse(JSON.stringify(dataOb)); // Working copy for editing
  oldGrnHasItem = JSON.parse(JSON.stringify(dataOb)); // Original copy for comparison

  /* JSON.stringify(dataOb) converts the object to a JSON string
JSON.parse() converts that JSON string back to a JavaScript object
This creates a completely new object with the same data */

  //get the items list only a few no of properties (written in  itemcontroller.java file)
  let items = getServiceRequest("/item/itemlist"); //calling the ajax request func in coommon func.js


  //calling reusable function for select list(elementid,massege,dtaalistname,prportynameOne,proprtynameTwo of the datalist,selected itemid)
 /*  fillDataintoSelectTwo(
    itemSelect,
    "Select Item",
    items,
    "item_no",
    "itemname",
    grnHasItem.item_id.item_no
  ); */

   //filling to item datalist
  textItemName.value=grnHasItem.item_id.item_no+' '+grnHasItem.item_id.itemname;
  textItemName.disabled="disabled";//disabling item selection

  // itemSelect.disabled = "disabled"; 
  txtUnitPrice.value = parseFloat(grnHasItem.purchase_price);
  txtQty.value = grnHasItem.qty;
  txtLinePrice.value = parseFloat(grnHasItem.line_price);
  txtSellingPrice.value=grnHasItem.selling_price;
  txtManufactureDate.value=grnHasItem.mfd_date;
  txtExpireDate.value=grnHasItem.exp_date;
  txtFreeQty.value=grnHasItem.free_qty;
  txtTotalQty.value=grnHasItem.tot_qty;
  txtBatchNo.value=grnHasItem.batch_no;

  //disable submit button,Enable update button
  grnInnerItemupdateButton.classList.remove("d-none");
  grnInnerItemsubmitButton.classList.add("d-none");
};

//function for inner form delete
const grnItemDelete = (dataOb, index) => {
  //need to get user confirmation
  let userConfirmation = window.confirm(
    "Are You sure you want to Remove the following Item .. ?" +
      "\nItem Name :" +
      dataOb.item_id.itemname +
      "\n Unit Price :" +
      dataOb.purchase_price +
      "\nQuantity :" +
      dataOb.qty +
      "\nLine Price:" +
      dataOb.line_price+
      "\nSelling Price:"+
      grnHasItem.selling_price+
      "\Manufacture Date:"+
       grnHasItem.mfd_date+
      "\nExpire Price:"+
       grnHasItem.exp_date+
      "\nFree Quantity:"+
       grnHasItem.free_qty+
       "\nTotal Quantity:"+
       grnHasItem.tot_qty
  );
  if (userConfirmation) {
    window.alert("Delete Successfull !..\n");

    let extIndex = purchaseOrder.grnHasItemList
      .map((orderitem) => orderitem.item_id.id)
      .indexOf(dataOb.item_id.id);
    if (extIndex != -1) {
      grn.grnHasItemList.splice(extIndex, 1);
    }
    // window.location.reload(); full browser reload -->reload every image&...
  } else {
    window.alert("Form Contains Errors !..\n");
  }

  refreshGrnInnerForm(); //refresh grn inner form
};

//function for inner form submit
const grnItemSubmitButton = () => {
  console.log(grnHasItem);

  //need to get user confirmation
  let userConfirmation = window.confirm(
    "Are You sure you want to add the following Item .. ?" +
      "\nItem Name :" +
      grnHasItem.item_id.itemname +
      "\nUnit Price :" +
      grnHasItem.purchase_price +
      "\nQuantity :" +
      grnHasItem.qty +
      "\nLine Price:" +
      grnHasItem.line_price+
      "\nBatch No:"+
      grnHasItem.batch_no+
      "\nSelling Price:"+
       grnHasItem.selling_price+
      "\Manufacture Date:"+
       grnHasItem.mfd_date+
      "\nExpire Price:"+
       grnHasItem.exp_date+
      "\nFree Quantity:"+
       grnHasItem.free_qty+
       "\nTotal Quantity:"+
       grnHasItem.tot_qty
  );
  if (userConfirmation) {
    window.alert("Submission Successfull !..\n");
    grn.grnHasItemList.push(grnHasItem);
    // window.location.reload(); full browser reload -->reload every image&...
    refreshGrnInnerForm(); //refresh grn inner form
  } else {
    window.alert("Form Contains Errors !..\n");
  }

  // console.log(employee);

  refreshGrnInnerForm();
};

//function for innerform update
const grnItemUpdateButton = () => {
  console.log(grnHasItem);

  if (grnHasItem.qty != oldGrnHasItem.qty) {
    //need to get user confirmation
    let userConfirmation = window.confirm(
      "Are You Sure you want to update the following changes.. ?" +
        "\nQuantity Changed from :" +oldGrnHasItem.qty+" to "+grnHasItem.qty
    );

    if (userConfirmation) {
      window.alert("Update Successfull !..\n");
      grn.grnHasItemList[innerFormIndex]=grnHasItem;
      // window.location.reload(); full browser reload -->reload every image&...
      refreshGrnInnerForm(); //refresh grn inner form
    } else {
      window.alert("Form Contains Errors !..\n");
    }
  }
  else{
    window.alert("Form Contains No Updates..!");
  }
  refreshGrnInnerForm();
};





//define function to calculate line price(unit price*quantity)-->call function at quantity input field onkeyup
const calculateLinePrice = () => {
  if (txtQty.value > 0) {
    //calculating line price ->parseFloat converts string to float
    let linePrice = (parseFloat(txtQty.value) * parseFloat(txtUnitPrice.value)).toFixed(2);//to two decimal points(toFixed)

    txtLinePrice.value = linePrice;
    grnHasItem.line_price = linePrice;
    //set color
    txtLinePrice.classList.remove("is-invalid");
    txtLinePrice.classList.add("is-valid");
  } else {
    grnHasItem.qty = null;
    grnHasItem.line_price = null;
    //set color for purchase order quantity
    txtQty.classList.remove("is-valid");
    txtQty.classList.add("is-invalid");

    //default color for line price since no value for qty
    // txtLinePrice.style.border="1px solid #ced4da";
    txtLinePrice.classList.remove("is-valid");
    txtLinePrice.classList.remove("is-invalid");
    txtLinePrice.value = "";
  }
};

//claculate total qty
const calculateTotalQty=()=>{
 let totalqty=parseInt(txtFreeQty.value)+parseInt(txtQty.value);//parseInt ->convert a string into an integer.
 txtTotalQty.value=totalqty;//show the value in input filed
 grnHasItem.tot_qty = totalqty;//Binding the value
 txtTotalQty.classList.remove("is-invalid");//setting the colors to totalqty
 txtTotalQty.classList.add("is-valid");

}

//validateExpdate based on manufacture date
const validateExpdate=()=>{


  let manufactureDate=txtManufactureDate.value;
  
  console.log(manufactureDate);
  
 txtExpireDate.min=manufactureDate;
}

