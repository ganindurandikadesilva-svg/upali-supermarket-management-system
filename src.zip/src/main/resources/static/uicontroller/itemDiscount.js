//Browser load event
window.addEventListener("load", () => {
  console.log("load");

  //enable tooltip
  $('[data-bs-toggle="tooltip"]').tooltip();

  refreshItemDiscountTable();

  refreshItemDiscountForm();
});

//refresh table area
const refreshItemDiscountTable = () => {
  //
  // actionButtons.style.display = "none"; // added for table style 3
  //table

  //calling the ajax request func in common func.js to get data
  itemDiscounts = getServiceRequest("/itemseasonaldiscount/findall");

  //Datatypes
  //string --> date/string/number
  //function-->object/array/boolean
  let columnList = [
    { columnName: getItemName, dataType: "function" },
    { columnName: "discount_rate", dataType: "string" },
    { columnName: "start_date", dataType: "string" },
    { columnName: "end_date", dataType: "string" }, 
    { columnName: "minimum_qty", dataType: "string" }
  ];

  //call the common function to fill data into table(tablebody id,datalist name,column list,edit parameter,
  //delete parameter,view parameter,button visibility)
  // fillDataintoTable(itemDiscountTableBody,itemDiscounts,columnList,itemDiscountEdit,itemDiscountDelete,itemDiscountView,true);
  fillDataintoTableTwo(
    itemDiscountTableBody,
    itemDiscounts,
    columnList,
    itemDiscountEdit,
    itemDiscountDelete,
    itemDiscountView,
    true
  );
  
  //disabling modifying buttons based on conditions
  for (const index in itemDiscounts) {

    if (itemDiscounts[index].item_id==null) {
    const row = itemDiscountTableBody.children[index];         // get the <tr>
    const lastCell = row.lastElementChild;                      // get the last <td>
    const deleteBtn = lastCell.querySelector("ul li:nth-child(3) button"); // third li button = Delete    
    deleteBtn.disabled="disabled";//deleteBtn.classList.add("d-none") for hide delete btn
  }
  }

  $("#itemDiscountTable").DataTable();
};

//function to get Item Name
const getItemName = (dataOb) => {
  if (dataOb.item_id!= null) {
    return dataOb.item_id.itemname;
  } else {
    return "-";
  }
};

//function for edit row
const itemDiscountEdit = (dataOb, index) => {
  //oldItemDiscount and itemDiscount for update checking
  itemDiscount = JSON.parse(JSON.stringify(dataOb));//if there is an update only the itemDiscount variable will be modified since its the passing object in frontend 
  oldItemDiscount = JSON.parse(JSON.stringify(dataOb));

  console.log("Edit", dataOb, index);
  //itemDiscountTableBody.children[index].style.border="2px solid black";

  //refill the form
  txtDiscountRate.value = dataOb.discount_rate;
  txtMinimumQty.value = dataOb.minimum_qty;
  txtstartDate.value = dataOb.start_date;//static
  txtEndDate.value = dataOb.end_date;//static 

  //object ekk nisa (dynamic ewge)
  itemNameSelect.value = JSON.stringify(dataOb.item_id); //dynmaic

 

  $("#itemDiscountFormModal").modal("show"); //show modal

  //disable submit button,Enable update button in edit function
  submitButton.style.display = "none";
  updateButton.removeAttribute("style");
};

//function for delete row
const itemDiscountDelete = (dataOb, index) => {
  console.log("Delete", dataOb, index);

  /* 
    //add sweet alert
    let userDeleteMsg =
      "\nEmployee Full Name :" +dataOb.fullname +
      "\nEmployee Calling Name :" +dataOb.callingname +
      "\nEmployee DOB :" +dataOb.dob +
      "\nEmployee NIC :" +dataOb.nic +
      "\nEmployee Email :" +dataOb.email +
      "\nEmployee Designation :" +dataOb.designaton_id.name+
      "\nEmployee Mobile No :" +dataOb.mobile_no +
      "\nEmployee Land No :" +dataOb.landno +
      "\nEmployee Gender :" +dataOb.gender +
      "\nEmployee Civil Status :" +dataOb.civil_status;
  
    Swal.fire({
      title: "Are you sure?",
      text: userDeleteMsg,
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    }).then((userResponse) => {
      if (userResponse.isConfirmed) {
        //employee=dataOb need to change the object name based on theobject name used in delete employeeDelete()
  
        let deleteResponse=getHTTPServiceRequest("/employee/delete","DELETE",dataOb);
  
        if (deleteResponse) {
          Swal.fire({
            title: "Delete Sucessfull!",
            text: "Your file has been deleted.",
            icon: "success",
          });
          refreshEmpTable();
          refreshEmpForm();
          $("#employeeFormModal").modal("hide"); //Hide modal
        } else {
          Swal.fire({
            title: "Delete unsucessfull!",
            text: "Your file has not been deleted.\n"+deleteResponse,
            icon: "error",
          });
        }
  
        
      }
    }); */

  //need to get user confirmation
  let userConfirmation = window.confirm(
    "Are You sure you want to delete the following Item Seasonal Discount .. ?" +
      "\nItem Name :" +
      dataOb.item_id.itemname +
      "\nDiscount Rate :" +
       dataOb.discount_rate+
      "\nMinimum Quantity:" +
     dataOb.minimum_qty +
      "\nStart Date:" +
     dataOb.start_date +
      "\nEnd Date :" +
      dataOb.end_date 
      
  );
  if (userConfirmation) {
    //Call delete service
    let deleteResponse=getHTTPServiceRequest("/itemseasonaldiscount/delete","DELETE",dataOb);
    if (deleteResponse == "OK") {
      window.alert("Delete Successfull !..\n");
      refreshItemDiscountTable(); //refresh Item Seasonal Discount table
      // window.location.reload(); full browser reload -->reload every image&...
      refreshItemDiscountForm(); //refresh Item Seasonal Discount form
    } else {
      window.alert("Submission Failed !..\n" + deleteResponse);
    }
  }
};

//function for view/print row
const itemDiscountView = (dataOb, index) => {
  console.log("View", dataOb, index);

  //option 1

  //how to open a new tab and enter html tags and styles using js

  /* 
    let newTab=window.open();
    let printTab="<head><title>Employee Print</title>"+
    "<link rel='stylesheet' href='../resources/bootstrap-5.2.3/css/bootstrap.min.css'></head>"+
    "<body><table class='table table-striped'><tr><th>Full Name</th><td>"+dataOb.fullname+"</td></tr></table></body>";
    newTab.document.write(printTab);
  
    setTimeout(()=>{
      //what should happen after 1500 ms
      newTab.stop();
      newTab.print();
      newTab.close();
    },1500) */

  //option 2 view in  a modal

  itemDis_item_name.innerText = dataOb.item_id.itemname;
  itemDis_discount_rate.innerText =  dataOb.discount_rate;
  itemDis_minimum_Qty.innerText = dataOb.minimum_qty;
  itemDis_start_date.innerText = dataOb.start_date;
  itemDis_end_date.innerText = dataOb.end_date;
 

  $("#itemDiscountFormModalView").modal("show"); //show modal
};

//option 2 Print row new tab open
const printButtonRow = () => {
  let newTab = window.open();
  let printTab =
  "<head><title>Item Discount Print</title>" +
"<link rel='stylesheet' href='bootstrap-5.2.3/css/bootstrap.min.css'>" +
"</head>" +
"<body>" +
"<h4 class='text-center mt-3'>Item Discount Print</h4>" +
"<div class='container mt-3'>" +
"  <div class='row justify-content-center'>" +
"    <div class='col-md-8'>" + itemDiscountTableView.outerHTML + "</div>" +
"  </div>" +
"</div>" +
"</body>";
  newTab.document.write(printTab);

  setTimeout(() => {
    //what should happen after 1500 ms
    newTab.stop();
    newTab.print();
    newTab.close();
  }, 1500);
};







/* *************************************************************************** */
/* **************************  FORM *********************************************/

//refresh form area
const refreshItemDiscountForm = () => {
  itemDiscount = new Object(); //creating a new object

  //static element only is cleared
  //Cleaning the values(select list not needed dynamic nm )

  formItemDiscount.reset(); //clearing the form values

  /* txtFullname.value="";
     txtCallingName.value="";
     radioMale.value=""; */

  // //Need to clear the colors

  setToDefault([
    itemNameSelect,
    txtDiscountRate,
    txtMinimumQty,
    txtstartDate,
    txtEndDate
    
  ]);

  /*  txtFullname.classList.remove("is-valid");
    //  txtFullname.style.border="1px solid #ced4da";
  
    txtCallingName.classList.remove("is-valid");
    //  txtCallingName.style.border="1px solid #ced4da";
  
    civilStatus.classList.remove("is-valid");
    //  civilStatus.style.border="1px solid #ced4da"; */

  //refilling the dynamic elements

  //itemDiscount item name select
  //calling reusable function for select list(elementid,massege,dtaalistname,prportyname of the datalist)
  let itemName = getServiceRequest("/item/findall"); //calling the ajax request func in coommon func.js


  fillDataintoSelect(
    itemNameSelect,
    "Select Item Name",
    itemName,
    "itemname"
  );

  //disable update button,Enable submit button
  // updateButton.style.visibility="hidden";
  // submitButton.style.visibility="visible";

  updateButton.style.display = "none";
  submitButton.removeAttribute("style");
};

//check form errors

const checkItemDiscountFormErrors = () => {
  let errors = "";
  if (itemDiscount.item_id == null) {
    errors = errors + "Please Select Item Name \n";
  }
  if (itemDiscount.discount_rate == null) {
    errors = errors + "Please Enter Discount Rate \n";
  }
  if (itemDiscount.minimum_qty == null) {
    errors = errors + "Please Enter Minimum Quantity\n";
  }
  if (itemDiscount.start_date == null) {
    errors = errors + "Please Enter Start Date \n";
  }
  if (itemDiscount.end_date == null) {
    errors = errors + "Please Enter  End Date \n";
  }
  

  return errors;
};

//itemDiscount form submit event Function
const itemDiscountSubmitButton = () => {
  console.log(itemDiscount);

  //check form error for required fields
  let errors = checkItemDiscountFormErrors(); //call the error function
  if (errors == "") {
    //no errors
    //need to get user confirmation
    let userConfirmation = window.confirm(
      "Are You sure you want to add the following Item Seasonal Discount.. ?" +
        "\nItem Name :" +
        itemDiscount.item_id.itemname +
        "\nDiscount Rate :" +
        itemDiscount.discount_rate +
        "\nMinimum Quantity :" +
        itemDiscount.minimum_qty +  
        "\nStart Date :" +
        itemDiscount.start_date +
        "\nEnd Date :" +
        itemDiscount.end_date 
       
        
    );
    if (userConfirmation) {
      //Call post service(url,method,data) data means object name-->itemDiscount
      let postServiceResponse = getHTTPServiceRequest(
        "/itemseasonaldiscount/insert",
        "POST",
        itemDiscount
      );
      if (postServiceResponse == "OK") {
        window.alert("Submission Successfull !..\n");
        refreshItemDiscountTable(); //refresh item Discount table
        // window.location.reload(); full browser reload -->reload every image&...
        refreshItemDiscountForm(); //refresh item Discount form
        $("#itemDiscountFormModal").modal("hide"); //Hide modal
      } else {
        window.alert("Submission Failed !..\n" + postServiceResponse);
      }
    }
  } else {
    window.alert("Form Contains Following Errors !..\n" + errors);
  }

  // console.log(itemDiscount);

  refreshItemDiscountTable();
};

const checkitemDiscountFormUpdates = () => {
  let updates = "";

  console.log(itemDiscount);//if there is an update only the itemDiscount variable will be modified since its the passing object in frontend 
  console.log(oldItemDiscount);

  if (itemDiscount != null && oldItemDiscount != null) {
    if (itemDiscount.item_id.itemname != oldItemDiscount.item_id.itemname) {
      updates =
        updates +
        "Item Name changed from " +
        oldItemDiscount.item_id.itemname +
        " into " +
        itemDiscount.item_id.itemname +
        "\n";
    }
    if (itemDiscount.discount_rate != oldItemDiscount.discount_rate) {
      updates =
        updates +
        "Discount Rate changed from " +
        oldItemDiscount.discount_rate +
        " into " +
        itemDiscount.discount_rate +
        "\n";
    }
    if (itemDiscount.minimum_qty != oldItemDiscount.minimum_qty) {
      updates =
        updates +
        "Minimum Quantity changed from " +
        oldItemDiscount.minimum_qty +
        " into " +
        itemDiscount.minimum_qty +
        "\n";
    }
    if (itemDiscount.start_date != oldItemDiscount.start_date) {
      updates =
        updates +
        "Start Date changed from " +
        oldEmployee.start_date +
        " into " +
        itemDiscount.start_date +
        "\n";
    }   
    if (itemDiscount.end_date != oldItemDiscount.end_date) {
      updates =
        updates +
        "End Date changed from " +
        oldItemDiscount.end_date +
        " into " +
        itemDiscount.end_date +
        "\n";
    }
   
    
  
  }

  return updates;
};

//itemDiscount Form update event function
const itemDiscountUpdateButton = () => {
  //check for form erors
  let errors = checkItemDiscountFormErrors();
  if (errors == "") {
    //check for item Discount Form updates
    let updates = checkitemDiscountFormUpdates();
    if (updates == "") {
      window.alert("Form Contains No Updates..!");
    } else {
      //Need user confirmation
      let userConfirmation = window.confirm(
        "Are you Sure you want to update the following changes ?\n" + updates
      );
      if (userConfirmation) {
        //call put service

        let putServiceResponse = getHTTPServiceRequest(
          "/itemseasonaldiscount/update",
          "PUT",
          itemDiscount
        );
        if (putServiceResponse == "OK") {
          window.alert("Form update Successfull..!");
          refreshItemDiscountForm();
          $("#itemDiscountFormModal").modal("hide"); //Hide modal
        } else {
          window.alert("Form Update Unsucessfull..!\n" + putServiceResponse);
        }
      }
    }
  } else {
    window.alert("Form Contains Following Errors !..\n" + errors);
  }

  refreshItemDiscountTable();
};

//Item Seasonal Discount Form Delete function
const DeleteItemDiscount = (dataOb, rowIndex) => {
  refreshItemDiscountTable();
};


//set item seasonal discount start date validation 
 // Get today's date in YYYY-MM-DD format
 const today = new Date().toISOString().split('T')[0];
 document.getElementById("txtstartDate").setAttribute('min', today);

 //new Date() - This creates a JavaScript Date object representing right now (current date and time).
 //.toISOString()-Converts the date into an ISO 8601 string format:Example: "2025-04-16T10:30:00.000Z"
// .split('T')[0]-Splits the string at the "T" character and takes the first part:"2025-04-16T..." becomes "2025-04-16"
//setAttribute('min', today)-This sets the min attribute on the input field dynamically.

