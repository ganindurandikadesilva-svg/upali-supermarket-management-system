const ctx = document.getElementById('myChart');

  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
      datasets: [{
        label: '# of Votes',
        data: [12, 19, 3, 5, 2, 3],
        borderWidth: 1
      }]
    },
    options: {
      scales: {
        y: {
          beginAtZero: true
        }
      }
    }
  });

  //function to print the chart
const printChart=()=>{
  let newTab = window.open();
  let printTab =
    "<head><title>Chart Print</title>" +
    "<link rel='stylesheet' href='../resources/bootstrap-5.2.3/css/bootstrap.min.css'>" +
    "</head>" +
    "<body> <h4 class='text-center'>Chart Print</h4>"+
    "<br><img src='" + ctx.toDataURL() + "'/></div>"+
    "</body>";
  newTab.document.write(printTab);

  setTimeout(() => {
    //what should happen after 1500 ms
    newTab.stop();
    newTab.print();
    newTab.close();
  }, 1500);
  }
  
