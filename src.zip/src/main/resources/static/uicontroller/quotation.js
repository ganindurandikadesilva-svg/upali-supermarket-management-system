//Browser load event
window.addEventListener("load", () => {
  console.log("load");

  //enable tooltip
  $('[data-bs-toggle="tooltip"]').tooltip();

  refreshQuotationTable();

  refreshQuotationForm();
});

//refresh table area
const refreshQuotationTable = () => {
  //
  // actionButtons.style.display = "none"; // added for table style 3
  //table

  //calling the ajax request func in coommon func.js to get data
  quotations = getServiceRequest("/quotation/findall");

  //Datatypes
  //string --> date/string/number
  //function-->object/array/boolean
  //decimal-->decimal/price
  let columnList = [
    { columnName: "quotation_no", dataType: "string" },
    { columnName: getItemList, dataType: "function" },
    { columnName: "received_date", dataType: "string" },
    { columnName: "deadline_date", dataType: "string" },
    { columnName: getQuotationStatus, dataType: "function" },
  ];

  //call the common function to fill data into table(tablebody id,datalist name,column list,edit parameter,
  //delete parameter,view parameter,button visibility)
  // fillDataintoTable(quotationTableBody,quotations,columnList,quotationEdit,quotationDelete,quotationView,true);
  fillDataintoTableTwo(
    quotationTableBody,
    quotations,
    columnList,
    quotationEdit,
    quotationDelete,
    quotationView,
    true
  );
  // fillDataintoTableThree(quotationTableBody,quotations,columnList,true);

  //disabling modifying buttons based on conditions
  for (const index in quotations) {
    if (quotations[index].quotation_status_id.name == "Deleted") {
      const row = quotationTableBody.children[index]; // get the <tr>
      const lastCell = row.lastElementChild; // get the last <td>
      const deleteBtn = lastCell.querySelector("ul li:nth-child(3) button"); // third li button = Delete
      deleteBtn.disabled = "disabled"; //deleteBtn.classList.add("d-none") for hide delete btn
    }
  }

  $("#quotationTable").DataTable();
};

//function to get Item List
const getItemList = (dataOb) => {
  let quotationHasItemList = dataOb.quotationHasItemList;
  let itemNames = "";
  quotationHasItemList.forEach((itemObj, index) => {
    const itemName = itemObj.item_id.itemname;
    if (quotationHasItemList.length - 1 == index) {
      itemNames = itemNames + itemName; //remove the comma if its the last value
    } else {
      itemNames = itemNames + itemName + ",";
    }
  });
  return itemNames;
};

//function to get Quotation Status
const getQuotationStatus = (dataOb) => {
  if (dataOb.quotation_status_id.name == "Valid") {
    let valid =
      "<span class='badge text-bg-secondary'>" +
      dataOb.quotation_status_id.name +
      "</span>";
    return valid;
  }
  if (dataOb.quotation_status_id.name == "Invalid") {
    let invalid =
      "<span class='badge text-bg-primary'>" +
      dataOb.quotation_status_id.name +
      "</span>";
    return invalid;
  }

  if (dataOb.quotation_status_id.name == "Removed") {
    let removed =
      "<span class='badge text-bg-warning'>" +
      dataOb.quotation_status_id.name +
      "</span>";
    return removed;
  }
};

//function for edit row
const quotationEdit = (dataOb, index) => {
  //old quotation and oldquotation for update checking
  quotation = JSON.parse(JSON.stringify(dataOb));
  oldquotation = JSON.parse(JSON.stringify(dataOb)); //if there is an update only the quotation variable will be modified since its the passing object in frontend

  console.log("Edit", dataOb, index);
  //tableBodyQuotation.children[index].style.border="2px solid black";

  //refill the form
  txtDeadlineDate.value = dataOb.deadline_date;
  txtDeadlineDate.classList.remove("is-invalid");
  txtDeadlineDate.classList.add("is-valid");

  txtReceivedDate.value = dataOb.received_date;
  txtReceivedDate.classList.remove("is-invalid");
  txtReceivedDate.classList.add("is-valid");

  supplierSelect.value = JSON.stringify(dataOb.supplier_id); //object ekk nisa (dynamic ewge)
  supplierSelect.disabled = "disabled"; //disabling supplier selection at refill/edit need to enable in refreshform function
  supplierSelect.classList.remove("is-invalid");
  supplierSelect.classList.add("is-valid");

  quotationRequestNoSelect.disabled = "disabled"; //disabling selecting of quotation request no when editing
  quotationRequestNoSelect.value = JSON.stringify(dataOb.quotation_request_id); //dynmaic (quotation_request_id-foreign key in quotation table)
  quotationRequestNoSelect.classList.remove("is-invalid");
  quotationRequestNoSelect.classList.add("is-valid");

  quotationStatusSelect.value = JSON.stringify(dataOb.quotation_status_id); //dynmaic (colors are filled beacuse it is already set in the refresh )

  //required nati nisa
  if (dataOb.txtNote == null) {
    txtNote.value = " ";
  } else {
    txtNote.value = dataOb.note;
  }

  $("#quotationFormModal").modal("show"); //show modal

  //disable submit button,Enable update button in edit function
  quotationSubmitButtonId.style.display = "none";
  quotationUpdateButtonId.removeAttribute("style");

  refreshQuotationInnerForm();
};

//function for delete row
const quotationDelete = (dataOb, index) => {
  console.log("Delete", dataOb, index);

  //need to get user confirmation
  let userConfirmation = window.confirm(
    "Are You sure you want to delete the following Quotation .. ?" +
      "\nQuotation No :" +
      dataOb.quotation_no +
      "\nSupplier Name :" +
      dataOb.supplier_id.suppliername +
      "\nDeadline Date :" +
      dataOb.deadline_date +
      "\nRecevied Date :" +
      dataOb.received_date +
      "\nQuotation Status:" +
      dataOb.quotation_status_id.name
  );
  if (userConfirmation) {
    //Call delete service
    let deleteResponse = getHTTPServiceRequest(
      "/quotation/delete",
      "DELETE",
      dataOb
    );
    if (deleteResponse == "OK") {
      window.alert("Delete Successfull !..\n");
      refreshQuotationTable(); //refresh quotation table
      // window.location.reload(); full browser reload -->reload every image&...
      refreshQuotationForm(); //refresh quotation form
    } else {
      window.alert("Delete Failed !..\n" + deleteResponse);
    }
  }
};

//function for view/print row
const quotationView = (dataOb, index) => {
  console.log("View", dataOb, index);

  //option 1

  //how to open a new tab and enter html tags and styles using js

  /* 
  let newTab=window.open();
  let printTab="<head><title>quotation Print</title>"+
  "<link rel='stylesheet' href='../resources/bootstrap-5.2.3/css/bootstrap.min.css'></head>"+
  "<body><table class='table table-striped'><tr><th>Full Name</th><td>"+dataOb.fullname+"</td></tr></table></body>";
  newTab.document.write(printTab);

  setTimeout(()=>{
    //what should happen after 1500 ms
    newTab.stop();
    newTab.print();
    newTab.close();
  },1500) */

  //option 2 view in  a modal

  q_quotation_no.innerText = dataOb.quotation_no;
  q_supplier.innerText = dataOb.supplier_id.suppliername;
  q_deadline_date.innerText = dataOb.deadline_date;
  q_received_date.innerText = dataOb.received_date;
  q_status.innerText = dataOb.quotation_status_id.name;

  $("#quotationModalView").modal("show"); //show modal
};

//option 2 Print row new tab open
const printButtonRow = () => {
  let newTab = window.open();
  let printTab =
    "<head><title>Quotation Print</title>" +
    "<link rel='stylesheet' href='bootstrap-5.2.3/css/bootstrap.min.css'>" +
    "</head>" +
    "<body>" +
    "<h4 class='text-center mt-3'>Quotation Print</h4>" +
    "<div class='container mt-3'>" +
    "  <div class='row justify-content-center'>" +
    "    <div class='col-md-8'>" +
    quotationTableView.outerHTML +
    "</div>" +
    "  </div>" +
    "</div>" +
    "</body>";
  newTab.document.write(printTab);

  setTimeout(() => {
    //what should happen after 1500 ms
    newTab.stop();
    newTab.print();
    newTab.close();
  }, 1500);
};

/* *************************************************************************** */
/* **************************  FORM *********************************************/

//refresh form area
const refreshQuotationForm = () => {
  //static element only is cleared
  //Cleaning the values(select list not needed dynamic nm )

  formQuotation.reset(); //clearing the form values

  quotation = new Object(); //creating a new object
  quotation.quotationHasItemList = new Array();

  quotationRequestNoSelect.disabled = ""; //enable in refreshform function and disabling supplier selection at refill/edit
  let quotationRequestNo = getServiceRequest("/quotationrequest/findall"); //calling the ajax request func in coommon func.js

  //calling reusable function for select list(elementid,massege,dtaalistname,prportyname of the datalist)
  fillDataintoSelect(
    quotationRequestNoSelect,
    "Select Quotation Request No",
    quotationRequestNo,
    "quotation_request_no"
  );

  supplierSelect.disabled = ""; //enable in refreshform function and disabling supplier selection at refill/edit
  //refilling the dynamic elements
  let supplier = getServiceRequest("/supplier/findall"); //calling the ajax request func in coommon func.js

  //quotation Status select list
  let quotationStatus = getServiceRequest("/quotationstatus/findall"); //calling the ajax request func in coommon func.js

  //calling reusable function for select list(elementid,massege,dtaalistname,prportyname of the datalist)
  fillDataintoSelect(
    supplierSelect,
    "Select Supplier",
    supplier,
    "suppliername"
  );
  //calling reusable function for select list(elementid,massege,dtaalistname,prportyname of the datalist)
  fillDataintoSelect(
    quotationStatusSelect,
    "Select Quotation Status",
    quotationStatus,
    "name"
  );

  //set Quotation status aailable when loading form
  quotationStatusSelect.value = JSON.stringify(quotationStatus[0]); //[0] is "pending" in Quotation  status list
  quotation.quotation_status_id = JSON.parse(quotationStatusSelect.value);

  //Need to clear the colors

  setToDefault([
    supplierSelect,
    txtDeadlineDate,
    txtReceivedDate,
    txtNote,
    quotationStatusSelect,
    quotationRequestNoSelect,
  ]);

  /*  txtFullname.classList.remove("is-valid");
  //  txtFullname.style.border="1px solid #ced4da";
  civilStatus.classList.remove("is-valid");
  //  civilStatus.style.border="1px solid #ced4da"; */

  //set color for quotation Request Status
  quotationStatusSelect.classList.remove("is-invalid");
  quotationStatusSelect.classList.add("is-valid");

  //disable update button,Enable submit button

  quotationUpdateButtonId.style.display = "none";
  quotationSubmitButtonId.removeAttribute("style");

  //set min max value for require date[YYYY-MM-DD]
  let currentDate = new Date();
  let currentMonth = currentDate.getMonth() + 1; //getMonth gives [0-11] so we need to add 1
  if (currentMonth < 10) {
    currentMonth = "0" + currentMonth;
  }
  let CurrentDay = currentDate.getDate(); //[1-31]
  if (CurrentDay < 10) {
    CurrentDay = "0" + CurrentDay;
  }

  txtDeadlineDate.min =
    currentDate.getFullYear() + "-" + currentMonth + "-" + CurrentDay;

  currentDate.setDate(currentDate.getDate() + 21); //adding 21 days to current date to get the max date

  let maximumcurrentMonth = currentDate.getMonth() + 1; //getMonth gives [0-11] so we need to add 1
  if (maximumcurrentMonth < 10) {
    maximumcurrentMonth = "0" + maximumcurrentMonth;
  }
  let maximumCurrentDay = currentDate.getDate(); //[1-31]
  if (maximumCurrentDay < 10) {
    maximumCurrentDay = "0" + maximumCurrentDay;
  }

  txtDeadlineDate.max =
    currentDate.getFullYear() +
    "-" +
    maximumcurrentMonth +
    "-" +
    maximumCurrentDay;

  // Get today's date
  let today = new Date();

  // Set max to today
  let maxDate = new Date(today);

  // Set min to 14 days before today
  let minDate = new Date();
  minDate.setDate(today.getDate() - 14);

  // Format date to yyyy-mm-dd
  function formatDate(dateObj) {
    let year = dateObj.getFullYear();
    let month = String(dateObj.getMonth() + 1).padStart(2, "0"); // Months [0-11]
    let day = String(dateObj.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  }

  // Assign to input
  txtReceivedDate.min = formatDate(minDate);
  txtReceivedDate.max = formatDate(maxDate);

  refreshQuotationInnerForm();
};

//check form errors
const checkQuotationFormErrors = () => {
  let errors = "";
  if (quotation.supplier_id == null) {
    errors = errors + "Please Select Supplier\n";
  }
  if (quotation.received_date == null) {
    errors = errors + "Please Enter  Received Date\n";
  }
  if (quotation.deadline_date == null) {
    errors = errors + "Please Enter  Deadline Date\n";
  }
  if (quotation.quotation_status_id == null) {
    errors = errors + "Please Select  Quotation Status\n";
  }
  if (quotation.quotationHasItemList.length == 0) {
    errors = errors + "Please Select Quotation Item\n";
  }

  return errors;
};

//Quotation  form submit event Function
const quotationSubmitButton = () => {
  console.log(quotation);

  //check form error for required fields
  let errors = checkQuotationFormErrors(); //call the error function
  if (errors == "") {
    //no errors
    //need to get user confirmation
    let userConfirmation = window.confirm(
      "Are You sure you want to add the following Quotation .. ?" +
        "\nQuotation Request no :" +
        quotation.quotation_request_id.quotation_request_no +
        "\nReceived Date :" +
        quotation.received_date +
        "\nDeadline Date :" +
        quotation.deadline_date +
        "\nSupplier Name :" +
        quotation.supplier_id.suppliername +
        "\nQuotation Status:" +
        quotation.quotation_status_id.name
    );
    if (userConfirmation) {
      //Call post service(url,method,data) data means object name-->quotation
      let postServiceResponse = getHTTPServiceRequest(
        "/quotation/insert",
        "POST",
        quotation
      );
      if (postServiceResponse == "OK") {
        window.alert("Submission Successfull !..\n");
        refreshQuotationTable(); //refresh quotation table
        // window.location.reload(); full browser reload -->reload every image&...
        refreshQuotationForm(); //refresh quotation form
        $("#quotationFormModal").modal("hide"); //Hide modal
      } else {
        window.alert("Submission Failed !..\n" + postServiceResponse);
      }
    }
  } else {
    window.alert("Form Contains Following Errors !..\n" + errors);
  }

  // console.log(purchaseorder);

  refreshQuotationTable();
};

const quotationFormUpdates = () => {
  let updates = "";

  console.log(quotation); //if there is an update only the quotation variable will be modified since its the passing object in frontend
  console.log(oldquotation);

  if (quotation != null && oldquotation != null) {
    if (quotation.deadline_date != oldquotation.deadline_date) {
      updates =
        updates +
        "Deadline Date changed from " +
        oldquotation.deadline_date +
        " into " +
        quotation.deadline_date +
        "\n";
    }
    if (quotation.requested_date != oldquotation.requested_date) {
      updates =
        updates +
        "Requested Date changed from " +
        oldquotation.requested_date +
        " into " +
        quotation.requested_date +
        "\n";
    }
    if (
      quotation.quotation_status_id.name !=
      oldquotation.quotation_status_id.name
    ) {
      updates =
        updates +
        "Quotation Status changed from " +
        oldquotation.quotation_status_id.name +
        " into " +
        quotation.quotation_status_id.name +
        "\n";
    }
  }

  return updates;
};

//quotation  Form update event function
const quotationUpdateButton = () => {
  //check for form errors
  let errors = checkQuotationFormErrors();
  if (errors == "") {
    //check for quotation  Form updates
    let updates = quotationFormUpdates();
    if (updates == "") {
      window.alert("Form Contains No Updates..!");
    } else {
      //Need user confirmation
      let userConfirmation = window.confirm(
        "Are you Sure you want to update the following changes ?\n" + updates
      );
      if (userConfirmation) {
        //call put service

        let putServiceResponse = getHTTPServiceRequest(
          "/quotation/update",
          "PUT",
          quotation
        );
        if (putServiceResponse == "OK") {
          window.alert("Form update Successfull..!");
          refreshQuotationForm();
          $("#quotationModalView").modal("hide"); //Hide modal
        } else {
          window.alert("Form Update Unsucessfull..!\n" + putServiceResponse);
        }
      }
    }
  } else {
    window.alert("Form Contains Following Errors !..\n" + errors);
  }

  refreshQuotationTable();
};

//quotation   Form Delete function
const DeleteQuotation = (dataOb, rowIndex) => {
  refreshQuotationTable();
};

/* *************************************************************************** */
/* ************************** INNER FORM *********************************************/

//define function to filter item list by existance of inner table
const filterItemListbyExistance = () => {
  // let selectedItem = JSON.parse(itemSelect.value);

  selectedItem = quotationHasItem.item_id;
  // find the index of a specific item in a list inside a quotation object.
  let extIndex = quotation.quotationHasItemList
    .map((qitem) => qitem.item_id.id)
    .indexOf(selectedItem.id);

  console.log("index" + extIndex);
  /*
   quotation.quotationHasItemList
      This is assumed to be an array (e.g., a list of items in a Quotations).

      Example structure:

      quotationHasItemList = [
        { item_id: { id: 101 } },
        { item_id: { id: 202 } },
        { item_id: { id: 303 } }
      ];
      2. .map((qitem) => qitem.item_id.id)
      This transforms the array into just a list of item IDs.

      From the above example, you'd get:

      [101, 202, 303]
      .indexOf(selectedItem.id)
      This finds the index of selectedItem.id in the array of item IDs.

      If selectedItem.id = 202, the result would be 1.

      let extIndex = ...
      Stores the index in a variable called extIndex.

      If the selectedItem.id is not found, extIndex will be -1. */
  if (extIndex != -1) {
    //index exists
    window.alert("Selected item already exists....!");
    refreshQuotationInnerForm();
  }
};

//define fnction to filter quotations requests by supplier
const filterQuotationRequestBySupplier = () => {
  //get the quotations
  let quotationReqs = getServiceRequest(
    "/qr/qrlistbysupplier/" + JSON.parse(supplierSelect.value).id
  ); //calling the ajax request func in coommon func.js
  //calling reusable function for select list(elementid,massege,dtaalistname,prportynameOne)
  console.log(quotationReqs);

  fillDataintoSelect(
    quotationRequestNoSelect,
    "Select Quotation Request",
    quotationReqs,
    "quotation_request_no"
  );
};

//define function to filter item list by supplier (need to call this function at supplier dropdown in quotation.html)
const filterItemListbyQuotationRequest = () => {
  //get the items
  let items = getServiceRequest(
    "/item/listbyquotationrequest/" +
      JSON.parse(quotationRequestNoSelect.value).id
  ); //calling the ajax request func in coommon func.js

  //calling reusable function for select list(elementid,massege,dtaalistname,prportynameOne,proprtynameTwo of the datalist)
  /*  fillDataintoSelectTwo(
    itemSelect,
    "Select Item",
    items,
    "item_no",
    "itemname"
  ); */

  //filling to item datalist
  //calling reusable function for data list(elementid,dtaalistname,prportynameOne,proprtynameTwo of the datalist)
  fillDataintoDataList(itemList, items, "item_no", "itemname");
};

//filter quantity based on quatation request and item selected-->returns just a number not a list
const filterQtybyQRandItem = () => {
  console.log(selectedItem);

  let qtys = getServiceRequest(
    "/qr/listbyqtyandqr/" +
      JSON.parse(quotationRequestNoSelect.value).id +
      "/" +
      selectedItem.id
  );

  console.log(qtys);
  txtQty.value = parseInt(qtys);
  txtQty.classList.remove("is-invalid");
  txtQty.classList.add("is-valid");
  quotationHasItem.qty = parseInt(txtQty.value);
};

//Funtion for inner form
const refreshQuotationInnerForm = () => {
  //creating a new object
  quotationHasItem = new Object();

  items = [];
  console.log(quotationRequestNoSelect.value);

  if (quotationRequestNoSelect.value != "") {
    //get the items
    items = getServiceRequest(
      "/item/listbyquotationrequest/" +
        JSON.parse(quotationRequestNoSelect.value).id
    ); //calling the ajax request func in coommon func.js
  } else {
    //get the items
    items = getServiceRequest("/item/findall"); //calling the ajax request func in coommon func.js
  }

  //calling reusable function for select list(elementid,massege,dtaalistname,prportynameOne,proprtynameTwo of the datalist)
  /* fillDataintoSelectTwo(
    itemSelect,
    "Select Item",
    items,
    "item_no",
    "itemname"
  ); */

  //filling to item datalist
  //calling reusable function for data list(elementid,dtaalistname,prportynameOne,proprtynameTwo of the datalist)
  fillDataintoDataList(itemList, items, "item_no", "itemname");

  //cant reset because it will reset the main form also
  //so need to clear the values
  //itemSelect.disabled = "";
  textItemName.value = ""; //clearing datalist
  txtPurchasePrice.value = "";
  txtLastPrice.value = "";
  txtQty.value = "";
  //itemSelect.value="";//for dynamic no need to clear values

  //Need to clear the colors
  setToDefault([textItemName, txtQty, txtLastPrice, txtPurchasePrice]); //textItemName datalist inpufield id

  //disable update button,Enable submit button
  quotationInnerItemupdateButton.classList.add("d-none");
  quotationInnerItemsubmitButton.classList.remove("d-none");

  //refresh inner table

  //Datatypes
  //string --> date/string/number
  //function-->object/array/boolean
  //decimal-->decimal/price
  let columnList = [
    { columnName: getQuotationItemName, dataType: "function" },
    { columnName: "purchase_price", dataType: "decimal" },
    { columnName: "qty", dataType: "string" },
    { columnName: "last_price", dataType: "decimal" },
  ];

  //call the common function to fill data into table(tablebody id,datalist name,column list,edit parameter,
  //delete parameter,view parameter,button visibility)
  // fillDataintoInnerTable(quotationItemTableBody,quotation.quotationHasItemList,columnList,quotationItemEdit,quotationItemDelete,true);
  fillDataintoInnerTable(
    quotationItemTableBody,
    quotation.quotationHasItemList,
    columnList,
    quotationItemEdit,
    quotationItemDelete,
    true
  );
};

//function to get quotation  item name
const getQuotationItemName = (dataOb) => {
  return dataOb.item_id.itemname;
};

//function to edit/refill inner form
const quotationItemEdit = (dataOb, index) => {
  innerFormIndex = index;

  //if there is an update only the quotationHasItem variable will be modified since its the passing object in frontend
  quotationHasItem = JSON.parse(JSON.stringify(dataOb)); // Working copy for editing
  oldquotationHasItem = JSON.parse(JSON.stringify(dataOb)); // Original copy for comparison

  /* JSON.stringify(dataOb) converts the object to a JSON string
JSON.parse() converts that JSON string back to a JavaScript object
This creates a completely new object with the same data */

  //get the items
  let items = getServiceRequest("/item/itemlist"); //calling the ajax request func in coommon func.js

  //calling reusable function for select list(elementid,massege,dtaalistname,prportynameOne,proprtynameTwo of the datalist,selected itemid)
  /*   fillDataintoSelectTwo(
    itemSelect,
    "Select Item",
    items,
    "item_no",
    "itemname",
    quotationHasItem.item_id.item_no
  ); */

  //filling to item datalist
  textItemName.value =
    quotationHasItem.item_id.item_no + " " + quotationHasItem.item_id.itemname;

  //itemSelect.disabled = "disabled"; //disabling item selection
  textItemName.disabled = "disabled"; //disabling item selection
  textItemName.classList.remove("is-invalid");
  textItemName.classList.add("is-valid");

  txtPurchasePrice.value = quotationHasItem.purchase_price;
  txtPurchasePrice.disabled = "disabled"; //disabling purchase price entry
  txtQty.value = quotationHasItem.qty;
  txtLastPrice.value = quotationHasItem.last_price; //last price can be changed based on the quantity

  //disable submit button,Enable update button
  quotationInnerItemupdateButton.classList.remove("d-none");
  quotationInnerItemsubmitButton.classList.add("d-none");
};

const quotationItemDelete = (dataOb, index) => {
  //need to get user confirmation
  let userConfirmation = window.confirm(
    "Are You sure you want to Remove the following Item .. ?" +
      "\nItem Name :" +
      dataOb.item_id.itemname +
      "\n Quantity :" +
      dataOb.qty
  );
  if (userConfirmation) {
    window.alert("Delete Successfull !..\n");

    //remove an existing item record from the inner form list (quotationHasItemList) if it already exists — based on item_id.
    let extIndex = quotation.quotationHasItemList
      .map((orderitem) => orderitem.item_id.id) //Extracts a list of all item_id.id values from the quotationHasItemList (ex:-[101, 102, 103])
      .indexOf(dataOb.item_id.id); //Searches for the index of the item ID from dataOb in that list.Returns:0, 1, 2, etc., if found,-1 if not found
    if (extIndex != -1) {
      quotation.quotationHasItemList.splice(extIndex, 1); //Removes one item at the index extIndex.Effectively deletes that item from the inner form list.
    }
    // window.location.reload(); full browser reload -->reload every image&...
  } else {
    window.alert("Form Contains Errors !..\n");
  }

  refreshQuotationInnerForm(); //refresh quotation  inner form
};

const quotationItemSubmitButton = () => {
  console.log(quotationHasItem);

  //need to get user confirmation
  let userConfirmation = window.confirm(
    "Are You sure you want to add the following Item .. ?" +
      "\nItem Name :" +
      quotationHasItem.item_id.itemname +
      "\nPurchase Price :" +
      quotationHasItem.purchase_price +
      "\nQuantity :" +
      quotationHasItem.qty +
      "\nLast Price :" +
      quotationHasItem.last_price
  );
  if (userConfirmation) {
    window.alert("Submission Successfull !..\n");
    quotation.quotationHasItemList.push(quotationHasItem);
    // window.location.reload(); full browser reload -->reload every image&...
    refreshQuotationInnerForm(); //refresh quotation  inner form
  } else {
    window.alert("Form Contains Errors !..\n");
  }

  // console.log(quotation);

  refreshQuotationInnerForm();
};

//check for innerform updates
const checkquotationInnerUpdate = () => {
  let innerUpdates = "";
  if (quotationHasItem.qty != oldquotationHasItem.qty) {
    innerUpdates =
      "\nQuantity Changed from :" +
      oldquotationHasItem.qty +
      " to " +
      quotationHasItem.qty;
  }
  if (oldquotationHasItem.last_price != quotationHasItem.last_price) {
    innerUpdates =
      "\nLast Price Changed from :" +
      oldquotationHasItem.last_price +
      " to " +
      quotationHasItem.last_price;
  }
  return innerUpdates;
};

//innerform update button function
const quotationItemUpdateButton = () => {
  console.log(quotationHasItem);
  let innerUpdates = checkquotationInnerUpdate();
  if (innerUpdates != "") {
    let userConfirmation = window.confirm(
      "Are You Sure you want to update the following changes.. ?" + innerUpdates
    );
    if (userConfirmation) {
      window.alert("Update Successfull !..\n");
      quotation.quotationHasItemList[innerFormIndex] = quotationHasItem;
      // window.location.reload(); full browser reload -->reload every image&...
      refreshQuotationInnerForm(); //refresh purchase order inner form
    } else {
      window.alert("Form Contains Errors !..\n");
    }
  } else {
    window.alert("Form Contains No Updates..!");
  }

  refreshQuotationInnerForm();
};
