//Browser load event
window.addEventListener("load", () => {
  console.log("load");

  //enable tooltip
  $('[data-bs-toggle="tooltip"]').tooltip();

  refreshCustomerTable();

  refreshCustomerForm();
});

//refresh table area
const refreshCustomerTable = () => {
  //
  // actionButtons.style.display = "none"; // added for table style 3
  //table

  //calling the ajax request func in coommon func.js to get data
  customers = getServiceRequest("/customer/findall");

  //Datatypes
  //string --> date/string/number
  //function-->object/array/boolean
  let columnList = [
    { columnName: "customername", dataType: "string" },
    { columnName: "email", dataType: "string" },
    { columnName: "nic", dataType: "string" },
    { columnName: "customeraddress", dataType: "string" },
    { columnName: "contactno", dataType: "string" },
    { columnName: "loyalty_point", dataType: "decimal" },
    { columnName: getCusStatus, dataType: "function" },
  ];

  //call the common function to fill data into table(tablebody id,datalist name,column list,edit parameter,
  //delete parameter,view parameter,button visibility)
  // fillDataintoTable(customerTableBody,customers,columnList,customerEdit,customerDelete,customerView,true);
  fillDataintoTableTwo(
    customerTableBody,
    customers,
    columnList,
    customerEdit,
    customerDelete,
    customerView,
    true
  );
  // fillDataintoTableThree(customerTableBody,customers,columnList,true);

   //disabling modifying buttons based on conditions
  for (const index in customers) {

    if (customers[index].customer_status_id.name=="Deleted") {
    const row = customerTableBody.children[index];         // get the <tr>
    const lastCell = row.lastElementChild;                      // get the last <td>
    const deleteBtn = lastCell.querySelector("ul li:nth-child(3) button"); // third li button = Delete    
    deleteBtn.disabled="disabled";//deleteBtn.classList.add("d-none") for hide delete btn
  }
  }

  $("#customerTable").DataTable();
};

//function to get customer status
const getCusStatus = (dataOb) => {
  if (dataOb.customer_status_id.name == "Active") {
    let active =
      "<span class='badge text-bg-success'>" +
      dataOb.customer_status_id.name +
      "</span>";
    return active;
  }
  if (dataOb.customer_status_id.name == "Inactive") {
    let inactive =
      "<span class='badge text-bg-primary'>" +
      dataOb.customer_status_id.name +
      "</span>";
    return inactive;
  }
  if (dataOb.customer_status_id.name == "Deleted") {
    let deleted =
      "<span class='badge text-bg-danger'>" +
      dataOb.customer_status_id.name +
      "</span>";
    return deleted;
  }
};

//function for edit row
const customerEdit = (dataOb, index) => {
  //old customer and customer for update checking
  customer = JSON.parse(JSON.stringify(dataOb));//if there is an update only the customer variable will be modified since its the passing object in frontend 
  oldCustomer = JSON.parse(JSON.stringify(dataOb));

  console.log("Edit", dataOb, index);
  //customerTableBody.children[index].style.border="2px solid black";

  //refill the form
  txtCustomername.value = dataOb.customername;
  txtEmail.value = dataOb.email;
  txtNic.value = dataOb.nic;
  customerContactNo.value = dataOb.contactno;
  customerTxtAddress.value = dataOb.customeraddress; //static
  

  //object ekk nisa (dynamic ewge)
  customerStatusSelect.value = JSON.stringify(dataOb.customer_status_id); //dynmaic

  //required nati nisa
  if (dataOb.txtCustomerNote == null) {
    txtCustomerNote.value = " ";
  } else {
    txtCustomerNote.value = dataOb.note;
  }

  $("#customerFormModal").modal("show"); //show modal

  //disable submit button,Enable update button in edit function
  submitButton.style.display = "none";
  updateButton.removeAttribute("style");
};

//function for delete row
const customerDelete = (dataOb, index) => {
  console.log("Delete", dataOb, index);


  //need to get user confirmation
  let userConfirmation = window.confirm(
    "Are You sure you want to delete the following Customer .. ?" +
      "\nCustomer Name :" +
      dataOb.customername +
      "\nCustomer Email :" +
      dataOb.email +
      "\nCustomer NIC :" +
      dataOb.nic +
      "\nCustomer Contact No :" +
      dataOb.contactno +
      "\nCustomer Loyalty Points :" +
      dataOb.loyalty_point +
      "\nCustomer Address:" +
      dataOb.customeraddress +
      "\nCustomer Status :" +
      dataOb.customer_status_id.name
  );
  if (userConfirmation) {
    //Call delete service
    let deleteResponse=getHTTPServiceRequest("/customer/delete","DELETE",dataOb);
    if (deleteResponse == "OK") {
      window.alert("Delete Successfull !..\n");
      refreshCustomerTable(); //refresh customer table
      // window.location.reload(); full browser reload -->reload every image&...
      refreshCustomerForm(); //refresh customer form
    } else {
      window.alert("Submission Failed !..\n" + deleteResponse);
    }
  }
};

//function for view/print row
const customerView = (dataOb, index) => {
  console.log("View", dataOb, index);

  //option 1

  //how to open a new tab and enter html tags and styles using js

  /* 
    let newTab=window.open();
    let printTab="<head><title>Employee Print</title>"+
    "<link rel='stylesheet' href='../resources/bootstrap-5.2.3/css/bootstrap.min.css'></head>"+
    "<body><table class='table table-striped'><tr><th>Full Name</th><td>"+dataOb.fullname+"</td></tr></table></body>";
    newTab.document.write(printTab);
  
    setTimeout(()=>{
      //what should happen after 1500 ms
      newTab.stop();
      newTab.print();
      newTab.close();
    },1500) */

  //option 2 view in  a modal

  cus_name.innerText = dataOb.customername;
  cus_email.innerText = dataOb.email;
  cus_nic.innerText = dataOb.nic;
  cus_address.innerText = dataOb.customeraddress;
  contact_no.innerText = dataOb.contactno;
  customer_status.innerText = dataOb.customer_status_id.name;

  $("#customerFormModalView").modal("show"); //show modal
};

//option 2 Print row new tab open
const printButtonRow = () => {
  let newTab = window.open();
  let printTab =
"<head><title>Customer Print</title>" +
"<link rel='stylesheet' href='bootstrap-5.2.3/css/bootstrap.min.css'>" +
"</head>" +
"<body>" +
"<h4 class='text-center mt-3'>Customer Print</h4>" +
"<div class='container mt-3'>" +
"  <div class='row justify-content-center'>" +
"    <div class='col-md-8'>" + customerTableView.outerHTML + "</div>" +
"  </div>" +
"</div>" +
"</body>";
  newTab.document.write(printTab);

  setTimeout(() => {
    //what should happen after 1500 ms
    newTab.stop();
    newTab.print();
    newTab.close();
  }, 1500);
};

/* *************************************************************************** */
/* **************************  FORM *********************************************/

//refresh form area
const refreshCustomerForm = () => {
 

  //static element only is cleared
  //Cleaning the values(select list not needed dynamic nm )

  formCustomer.reset(); //clearing the form values

  customer = new Object(); //creating a new object

   //customer status select list
  //calling reusable function for select list(elementid,massege,dtaalistname,prportyname of the datalist)
  let customerStatus = getServiceRequest("/customerstatus/findall"); //calling the ajax request func in coommon func.js


  fillDataintoSelect(
    customerStatusSelect,
    "Select Customer Status",
    customerStatus,
    "name"
  );

  /* txtFullname.value="";
     txtCallingName.value="";
     txtNic.value="";
     txtDOB.value="";
     txtEmail.value="";
     txtMobileNo.value="";
     txtLandNo.value="";
     selectEmpStatus.value="";
     selectDesignation.value="";
     civilStatus.value="";
     radioMale.value=""; */

       //set customer status aailable when loading form
    customerStatusSelect.value=JSON.stringify(customerStatus[0]);//[0] is "available" in customer status table
    customer.customer_status_id=JSON.parse(customerStatusSelect.value);


  // //Need to clear the colors

  setToDefault([
    txtCustomername,
    txtEmail,
    txtNic,
    customerContactNo,
   // txtLoyaltyPoints,
    customerStatusSelect,
    customerContactNo,
    customerTxtAddress,
    txtCustomerNote
  ]);

  /*  txtFullname.classList.remove("is-valid");
    //  txtFullname.style.border="1px solid #ced4da";
  
    civilStatus.classList.remove("is-valid");
    //  civilStatus.style.border="1px solid #ced4da"; */

    //set color for customer Status
  customerStatusSelect.classList.remove("is-invalid");
  customerStatusSelect.classList.add("is-valid"); 

  //refilling the dynamic elements

  //disable update button,Enable submit button
  // updateButton.style.visibility="hidden";
  // submitButton.style.visibility="visible";

  updateButton.style.display = "none";
  submitButton.removeAttribute("style");
};

//check form errors

const checkCustomerFormErrors = () => {
  let errors = "";
  if (customer.customername == null) {
    errors = errors + "Please Enter Customer Name \n";
  }
  if (customer.nic == null) {
    errors = errors + "Please Enter NIC \n";
  }
  if (customer.email == null) {
    errors = errors + "Please Enter an Email \n";
  }
  if (customer.customeraddress == null) {
    errors = errors + "Please Enter Customer Address \n";
  }
  if (customer.contactno == null) {
    errors = errors + "Please Enter  Mobile No \n";
  }

  if (customer.customer_status_id == null) {
    errors = errors + "Please Select an Customer Status \n";
  }

  return errors;
};

//Customer form submit event Function
const customerSubmitButton = () => {
  console.log(customer);

  //check form error for required fields
  let errors = checkCustomerFormErrors(); //call the error function
  if (errors == "") {
    //no errors
    //need to get user confirmation
    let userConfirmation = window.confirm(
      "Are You sure you want to add the following Customer .. ?" +
        "\nCustomer Name :" +
        customer.customername +
        "\nCustomer Email :" +
        customer.email +
        "\nCustomer NIC :" +
        customer.nic +  
        "\nCustomer Address :" +
        customer.customeraddress +
        "\nCustomer Contact No :" +
        customer.contactno 
        
    );
    if (userConfirmation) {
      //Call post service(url,method,data) data means object name-->customer
      let postServiceResponse = getHTTPServiceRequest(
        "/customer/insert",
        "POST",
        customer
      );
      if (postServiceResponse == "OK") {
        window.alert("Submission Successfull !..\n");
        refreshCustomerTable(); //refresh customer table
        // window.location.reload(); full browser reload -->reload every image&...
        refreshCustomerForm(); //refresh customer form
        $("#customerFormModal").modal("hide"); //Hide modal
      } else {
        window.alert("Submission Failed !..\n" + postServiceResponse);
      }
    }
  } else {
    window.alert("Form Contains Following Errors !..\n" + errors);
  }

  // console.log(customer);

  refreshCustomerTable();
};

const checkCustomerFromUpdates = () => {
  let updates = "";

  console.log(customer);//if there is an update only the customer variable will be modified since its the passing object in frontend
  console.log(oldCustomer);

  if (customer != null && oldCustomer != null) {
    if (customer.customername != oldCustomer.customername) {
      updates =
        updates +
        "Customer Name changed from " +
        oldCustomer.customername +
        " into " +
        customer.customername +
        "\n";
    }
    if (customer.email != oldCustomer.email) {
      updates =
        updates +
        "Email changed from " +
        oldCustomer.email +
        " into " +
        customer.email +
        "\n";
    }
    if (customer.nic != oldCustomer.nic) {
      updates =
        updates +
        "Nic changed from " +
        oldCustomer.nic +
        " into " +
        customer.nic +
        "\n";
    }
    if (customer.customeraddress != oldCustomer.customeraddress) {
      updates =
        updates +
        "Customer Address changed from " +
        oldEmployee.customeraddress +
        " into " +
        customer.customeraddress +
        "\n";
    }   
    if (customer.contactno != oldCustomer.contactno) {
      updates =
        updates +
        "Contact No changed from " +
        oldCustomer.contactno +
        " into " +
        customer.contactno +
        "\n";
    }
    if (customer.customer_status_id.name != oldCustomer.customer_status_id.name) {
      updates =
        updates +
        "Customer Status changed from " +
        oldCustomer.customer_status_id.name +
        " into " +
        customer.customer_status_id.name +
        "\n";
    }

    if (customer.note != oldCustomer.note) {
      updates =
        updates +
        "Note changed from " +
        oldCustomer.note +
        " into " +
        customer.note +
        "\n";
    }
  
  }

  return updates;
};

//Customer Form update event function
const customerUpdateButton = () => {
  //check for form eroors
  let errors = checkCustomerFormErrors();
  if (errors == "") {
    //check for employee Form updates
    let updates = checkCustomerFromUpdates();
    if (updates == "") {
      window.alert("Form Contains No Updates..!");
    } else {
      //Need user confirmation
      let userConfirmation = window.confirm(
        "Are you Sure you want to update the following changes ?\n" + updates
      );
      if (userConfirmation) {
        //call put service

        let putServiceResponse = getHTTPServiceRequest(
          "/customer/update",
          "PUT",
          customer
        );
        if (putServiceResponse == "OK") {
          window.alert("Form update Successfull..!");
          refreshCustomerForm();
          $("#customerFormModal").modal("hide"); //Hide modal
        } else {
          window.alert("Form Update Unsucessfull..!\n" + putServiceResponse);
        }
      }
    }
  } else {
    window.alert("Form Contains Following Errors !..\n" + errors);
  }

  refreshCustomerTable();
};

//Customer Form Delete function
const DeleteCus = (dataOb, rowIndex) => {
  refreshCustomerTable();
};


//Nic validation
const nicValidator = (nicElement) => {
  let nicValue = nicElement.value;
  if (nicValue != "") {
    if (new RegExp("^(([98765][0-9]{8}[VvXx])||([0-9]{12}))$").test(nicValue)) {
      //valid nic
      customer.nic = nicValue;

      nicElement.classList.remove("is-invalid");
      nicElement.classList.add("is-valid");

      //generate  Dob and gender using nic
    } else {

      customer.nic = null;

      nicElement.classList.remove("is-valid");
      nicElement.classList.add("is-invalid");
    }
  } else {
    //invalid calling name
    customer.nic = null;

    nicElement.classList.remove("is-valid");
    nicElement.classList.add("is-invalid");
  }
};
