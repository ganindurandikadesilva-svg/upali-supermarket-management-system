//Browser load event handler
window.addEventListener("load", () => {
  // call refresh privilege table functon
  console.log("load");
  refreshPrivilegeTable();

  //refresh form function
  refreshPrivilegeForm();
});

//define function for refresh form
const refreshPrivilegeForm = () => {
  //creating a new object
  privilege = new Object();

  //calling the ajax request func in coommon func.js to get data from db for dynamic lists
  roles = getServiceRequest("/role/rolesWithoutAdmin")
 
  modules = getServiceRequest("/module/findall")



  //reusable function for select list(elementid,massege,datalistname,prpertyname of the datalist)
  fillDataintoSelect(roleSelect, "Select Role", roles, "name");
  fillDataintoSelect(moduleSelect, "Select Module", modules, "name");

  //checkxes initial state should be not checked
  checkboxSelect.checked = false;
  privilege.select_privilege = false;
  selectText.innerText = "Select Privilege Not Granted";

  checkboxInsert.checked = false;
  privilege.insert_privilege = false;
  insertText.innerText = "Insert Privilege Not Granted";

  checkboxUpdate.checked = false;
  privilege.update_privilege = false;
  updateText.innerText = "Update Privilege Not Granted";

  checkboxDelete.checked = false;
  privilege.delete_privilege = false;
  deleteText.innerText = "Delete Privilege Not Granted";

  //set the text borders to default
  /*   roleSelect.style.border="1px solid #ced4da";
  moduleSelect.style.border="1px solid #ced4da"; 

  txtFullname.classList.remove("is-valid");
  txtFullname.style.border = "1px solid #ced4da";
 */
  setToDefault([roleSelect, moduleSelect]); //call the function to make text input filed to default

  //disable update button,Enable submit button
  // updateButton.style.visibility="hidden";
  // submitButton.style.visibility="visible";

  updateButton.style.display="none";
  submitButton.removeAttribute("style");

};

//function for change text when check box is checked
function PrivilegeTextFunc() {
  if (checkboxSelect.checked) {
    selectText.innerText = "Select Privilege Granted";
    privilege.select_privilege = true;
  } else {
    selectText.innerText = "Select Privilege Not Granted";
    privilege.select_privilege = false;
  }
  if (checkboxInsert.checked) {
    insertText.innerText = "Insert Privilege Granted";
    privilege.insert_privilege = true;
  } else {
    insertText.innerText = "Insert Privilege Not Granted";
    privilege.insert_privilege = false;
  }
  if (checkboxUpdate.checked) {
    updateText.innerText = "Update Privilege Granted";
    privilege.update_privilege = true;
  } else {
    updateText.innerText = "Update Privilege Not Granted";
    privilege.update_privilege = false;
  }
  if (checkboxDelete.checked) {
    deleteText.innerText = "Delete Privilege Granted";
    privilege.delete_privilege = true;
  } else {
    deleteText.innerText = "Delete Privilege Not Granted";
    privilege.delete_privilege = false;
  }
}

//function to check form errors
const checkFormErrors = () => {
  let errors = "";

  if (privilege.role_id == null) {
    errors = errors + "Please Select a Role\n";
  }
  if (privilege.module_id == null) {
    errors = errors + "Please Select a Module\n";
  }

  return errors;
};

//Function for privilege form submit button
const privilegeSubmitButton = () => {

  console.log(privilege);
  


  let errors = checkFormErrors();
  if (errors == "") {
    let userConfirmation = window.confirm(
      "Are You sure you want to add the following Privilege .. ?" +
        "\nRole :" +
        privilege.role_id.name +
        "\nModule :" +
        privilege.module_id.name +
        "\nSelect Privilege :" +
        getSelect(privilege) +
        "\nInsert Privilege :" +
        getInsert(privilege) +
        "\nUpdate Privilege:" +
        getUpdate(privilege) +
        "\nDelete Privilege :" +
        getDelete(privilege)
    );
    if (userConfirmation) {
      let postResponse = getHTTPServiceRequest("/privilege/insert","POST",privilege)
      if (postResponse == "OK") {
        window.alert("Saved Sucessfully");

        refreshPrivilegeForm(); //refresh privilege form
        refreshPrivilegeTable(); //refresh privilege table
        $("#privilegeFormModal").modal("hide"); //Hide modal
      } else {
       window.alert(
          "Save Unsucessfull..!\nForm has following Errors.....\n" +
            postResponse
        );
      }
    }
  } else {
    window.alert("Form has following Errors.....\n" + errors);
  }
};

//Refresh privilege table function
const refreshPrivilegeTable = () => {

  //calling the ajax request func in coommon func.js to get data from db
  let privileges = getServiceRequest("/privilege/findall")

  //Datatypes
  //string --> date/string/number
  //function-->object/array/boolean

  //creating the column list
  let columnList = [
    { columnName: getRole, dataType: "function" },
    { columnName: getModule, dataType: "function" },
    { columnName: getSelect, dataType: "function" },
    { columnName: getInsert, dataType: "function" },
    { columnName: getUpdate, dataType: "function" },
    { columnName: getDelete, dataType: "function" },
  ];

  /*   call the common function to fill data into table(tablebody id,datalist name,column list,edit(Refill) parameter,
  delete parameter,view parameter,button visibility) */
  fillDataintoTableTwo(
    privilegeTableBody,
    privileges,
    columnList,
    privilegeEdit,
    privilegeDelete,
    privilegeView,
    true
  );
  

  //convert to jquery dtatable
  $("#privilegeTable").DataTable();
};

//creating functions for the columns
const getRole = (ob) => {
  return ob.role_id.name;
};
const getModule = (ob) => {
  return ob.module_id.name;
};
const getSelect = (ob) => {
  if (ob.select_privilege) {
    return "Granted";
  } else {
    return "Not-Granted";
  }
};
const getInsert = (ob) => {
  if (ob.insert_privilege) {
    return "Granted";
  } else {
    return "Not-Granted";
  }
};
const getUpdate = (ob) => {
  if (ob.update_privilege) {
    return "Granted";
  } else {
    return "Not-Granted";
  }
};
const getDelete = (ob) => {
  if (ob.delete_privilege) {
    return "Granted";
  } else {
    return "Not-Granted";
  }
};

//creating functions for insert/update /delete

//Refill function(edit button)
const privilegeEdit = (ob, rowIndex) => {
  //old privilege and privilege for update checking
  privilege = JSON.parse(JSON.stringify(ob));//if there is an update only the privilege variable will be modified since its the passing object in frontend 
  oldPrivilege = JSON.parse(JSON.stringify(ob));

  roleSelect.value = JSON.stringify(ob.role_id); //Dynamic ewage json stringify krnna one
  moduleSelect.value = JSON.stringify(ob.module_id);

  

  if (ob.select_privilege) {
    selectText.innerText = "Select Privilege Granted";
    checkboxSelect.checked = true;
  } else {
    selectText.innerText = "Select Privilege Not Granted";
    checkboxSelect.checked = false;
  }
  if (ob.insert_privilege) {
    insertText.innerText = "Insert Privilege Granted";
    checkboxInsert.checked = true;
  } else {
    insertText.innerText = "Insert Privilege Not Granted";
    checkboxInsert.checked = false;
  }
  if (ob.update_privilege) {
    updateText.innerText = "Update Privilege Granted";
    checkboxUpdate.checked = true;
  } else {
    updateText.innerText = "Update Privilege Not Granted";
    checkboxUpdate.checked = false;
  }
  if (ob.delete_privilege) {
    deleteText.innerText = "Delete Privilege Granted";
    checkboxDelete.checked = true;
  } else {
    deleteText.innerText = "Delete Privilege Not Granted";
    checkboxDelete.checked = false;
  }
  $("#privilegeFormModal").modal("show"); //show modal

  //disable submit button,Enable update button in edit function
  submitButton.style.display="none";
  updateButton.removeAttribute("style");
};

//Function to check form updates
const checkFormUpdates = () => {
  let updates = "";

  if (privilege != null && oldPrivilege != null) {
    if (privilege.role_id.name != oldPrivilege.role_id.name) {
      updates =
        updates +
        "Role changed from " +
        oldPrivilege.role_id.name +
        " into " +
        privilege.role_id.name +
        "\n";
    }
    if (privilege.module_id.name != oldPrivilege.module_id.name) {
        updates =
          updates +
          "Module changed from " +
          oldPrivilege.module_id.name +
          " into " +
          privilege.module_id.name +
          "\n";
      }
      if (privilege.select_privilege!= oldPrivilege.select_privilege) {
        if (privilege.select_privilege==true) {
            updates =updates +"Select Privilege changed from Not Granted to Granted \n" ;
        } else {
            updates =updates +"Select Privilege changed from Granted to Not Granted \n" ;
        }
       
      }
      if (privilege.insert_privilege!= oldPrivilege.insert_privilege) {
        if (privilege.insert_privilege==true) {
            updates =updates +"Insert Privilege changed from Not Granted to Granted \n" ;
        } else {
            updates =updates +"Insert Privilege changed from Granted to Not Granted \n" ;
        }
       
      }
      if (privilege.update_privilege!= oldPrivilege.update_privilege) {
        if (privilege.update_privilege==true) {
            updates =updates +"Update Privilege changed from Not Granted to Granted \n" ;
        } else {
            updates =updates +"Update Privilege changed from Granted to Not Granted \n" ;
        }
       
      }
      if (privilege.delete_privilege!= oldPrivilege.delete_privilege) {
        if (privilege.delete_privilege==true) {
            updates =updates +"Delete Privilege changed from Not Granted to Granted \n" ;
        } else {
            updates =updates +"Delete Privilege changed from Granted to Not Granted \n" ;
        }
       
      }
     

  }

  return updates;
};

//function for update
const privilegeUpdateButton = () => {
  let errors = checkFormErrors();
  if (errors == "") {
    let updates = checkFormUpdates();
    if (updates == "") {
      window.alert("Form has no Updates..!");
    } else {
      let userConfirmation = window.confirm(
        "Are you Sure you want to update the following changes ?\n" + updates
      );
      if (userConfirmation) {
        //Call  the function at commonjs to connect with db 
        let putResponse =  getHTTPServiceRequest("/privilege/update","PUT",privilege)
        console.log(putResponse);
        if (putResponse == "OK") {
          window.alert("Form update Successfull..!");
          refreshPrivilegeForm();
          $("#privilegeFormModal").modal("hide"); //Hide modal
        } else {
          window.alert("Form Update Unsucessfull..!\n" + putResponse);
        }
      }
    }
  } else {
    window.alert("Form has Following Eroors\n" + errors);
  }
  refreshPrivilegeTable();
};

//function for view row & print option
const privilegeView = (ob, rowIndex) => {
  //option 1
  //how to open a new tab and enter html tags and styles using js

  /* 
  let newTab=window.open();
  let printTab="<html><head><title>Privilege Print</title>"+
  "<link rel='stylesheet' href='./resources/bootstrap-5.2.3/css/bootstrap.min.css'></head>"+
  "<body><table class='table table-striped'>"+
        "<tr><th>Role</th><td>"+ob.role_id.name+"</td></tr>"+
        `<tr><th>Module</th><td>${ob.module_id.name}</td></tr>`+//different way to write it
        "<tr><th>Select</th><td>"+getSelect(ob)+"</td></tr>"+//calling the function which return granted or not grantd
    "</table></body></html>"
  newTab.document.write(printTab);

  setTimeout(()=>{
    //what should happen after 1500 ms
    newTab.stop();
    newTab.print();
    newTab.close();
  },1500) 
 
 */

  //option 2
  privi_role.innerText = ob.role_id.name;
  Privi_module.innerText = ob.module_id.name;
  Priv_select.innerText = ob.select_privilege;
  Priv_insert.innerText = ob.insert_privilege;
  Priv_update.innerText = ob.update_privilege;
  Priv_delete.innerText = ob.delete_privilege;

  //call the modal
  $("#privilegeFormModalView").modal("show"); //show modal
};

//function for print after the view modal print button is pressed
const printButton = () => {
  let openNewTab = window.open();
  let printTab =

    "<head><title>Privilege Print</title>" +
"<link rel='stylesheet' href='bootstrap-5.2.3/css/bootstrap.min.css'>" +
"</head>" +
"<body>" +
"<h4 class='text-center mt-3'>Privilege Print</h4>" +
"<div class='container mt-3'>" +
"  <div class='row justify-content-center'>" +
"    <div class='col-md-8'>" + privilegeTableView.outerHTML + "</div>" +
"  </div>" +
"</div>" +
"</body>";
  openNewTab.document.write(printTab);

  setTimeout(() => {
    //what should happen after 1500 ms
    openNewTab.stop();
    openNewTab.print();
    openNewTab.close();
    //$("#privilegeFormModalView").modal("hide"); //if you want to hide the opened modal after print preview closes
  }, 1500);
};

//function for delete row
const privilegeDelete = (ob, rowIndex) => {
  let userConfirmation = window.confirm(
    "Are You Sure to Delete this Privilege ?" +
      "\nRole :" +
      ob.role_id.name +
      "\nModule :" +
      ob.module_id.name
  );
  if (userConfirmation) {
    let serviceResponse =  getHTTPServiceRequest("/privilege/delete","DELETE",ob);
    if (serviceResponse == "OK") {
      window.alert("Delete Successfull !..\n");
      refreshPrivilegeTable(); //refresh privilege table
    } else {
      window.alert("Delete Unsucessfull !..\n" + serviceResponse);
    }
  }
};
