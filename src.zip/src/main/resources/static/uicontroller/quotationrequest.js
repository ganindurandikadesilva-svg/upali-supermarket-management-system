//Browser load event
window.addEventListener("load", () => {
  console.log("load");

  //enable tooltip
  $('[data-bs-toggle="tooltip"]').tooltip();

  refreshQuotationRequestTable();

  refreshQuotationRequestForm();
});

//refresh table area
const refreshQuotationRequestTable = () => {
  //
  // actionButtons.style.display = "none"; // added for table style 3
  //table

  //calling the ajax request func in coommon func.js to get data
  quotationrequests = getServiceRequest("/quotationrequest/findall");

  //Datatypes
  //string --> date/string/number
  //function-->object/array/boolean
  //decimal-->decimal/price
  let columnList = [
    { columnName: "quotation_request_no", dataType: "string" },
    { columnName: getItemList, dataType: "function" },
    { columnName: getSupplier, dataType: "function" },
    { columnName: "requested_date", dataType: "string" },
    { columnName: getQuotationRequestStatus, dataType: "function" },
  ];

  //call the common function to fill data into table(tablebody id,datalist name,column list,edit parameter,
  //delete parameter,view parameter,button visibility)
  // fillDataintoTable(purchaseOrderTableBody,quotationrequests,columnList,quotationRequestEdit,quotationRequestDelete,quotationRequestView,true);
  fillDataintoTableTwo(
    quotationRequestTableBody,
    quotationrequests,
    columnList,
    quotationRequestEdit,
    quotationRequestDelete,
    quotationRequestView,
    true
  );
  // fillDataintoTableThree(quotationRequestTableBody,quotationrequests,columnList,true);


  //disabling modifying buttons based on conditions
   for (const index in quotationrequests) {

    if (quotationrequests[index].quotation_request_status_id.name=="Deleted"||quotationrequests[index].quotation_request_status_id.name=="Received") {
    const row = quotationRequestTableBody.children[index];         // get the <tr>
    const lastCell = row.lastElementChild;                      // get the last <td>
    const deleteBtn = lastCell.querySelector("ul li:nth-child(3) button"); // third li button = Delete    
    deleteBtn.disabled="disabled";//deleteBtn.classList.add("d-none") for hide delete btn
  }
    
  }

  $("#quotationRequestTable").DataTable();
};

//function to get Item List
const getItemList = (dataOb) => {
  let quotationRequestHasItemList=dataOb.quotationRequestHasItemList;
  let itemNames="";
  quotationRequestHasItemList.forEach((itemObj, index) => {
    const itemName=itemObj.item_id.itemname;
    if (quotationRequestHasItemList.length-1==index) {
      itemNames=itemNames+itemName;//remove the comma if its the last value
    }
    else{
      itemNames=itemNames+itemName+',';
    }
  });
  return itemNames;
};

//function to get Supplier Name
const getSupplier = (dataOb) => {
  return dataOb.supplier_id.suppliername; //suppliername
};

//function to get Purchase Order Status
const getQuotationRequestStatus = (dataOb) => {
  if (dataOb.quotation_request_status_id.name == "Requested") {
    let requested =
      "<span class='badge text-bg-secondary'>" +
      dataOb.quotation_request_status_id.name +
      "</span>";
    return requested;
  }
  if (dataOb.quotation_request_status_id.name == "Received") {
    let received =
      "<span class='badge text-bg-primary'>" +
      dataOb.quotation_request_status_id.name +
      "</span>";
    return received;
  }
 /*  if (dataOb.quotation_request_status_id.name == "Completed") {
    let completed =
      "<span class='badge text-bg-success'>" +
      dataOb.quotation_request_status_id.name +
      "</span>";
    return completed;
  } */
  if (dataOb.quotation_request_status_id.name == "Canceled") {
    let canceled =
      "<span class='badge text-bg-warning'>" +
      dataOb.quotation_request_status_id.name +
      "</span>";
    return canceled;
  }
  if (dataOb.quotation_request_status_id.name == "Deleted") {
    let deleted =
      "<span class='badge text-bg-danger'>" +
      dataOb.quotation_request_status_id.name +
      "</span>";
    return deleted;
  }
};

//function for edit row
const quotationRequestEdit = (dataOb, index) => {
  //old quotationRequest and quotationRequest for update checking
  quotationRequest = JSON.parse(JSON.stringify(dataOb));//if there is an update only the quotattionRequest variable will be modified since its the passing object in frontend 
  oldquotationRequest = JSON.parse(JSON.stringify(dataOb));

  console.log("Edit", dataOb, index);
  //tableBodyQuotationRequest.children[index].style.border="2px solid black";

  //refill the form
  txtRequestedDate.value = dataOb.requested_date;
  txtRequestedDate.classList.remove("is-invalid");
  txtRequestedDate.classList.add("is-valid");

  supplierSelect.value = JSON.stringify(dataOb.supplier_id); //object ekk nisa (dynamic ewge)
  supplierSelect.disabled="disabled";//disabling supplier selection at refill/edit need to enable in refreshform function
  supplierSelect.classList.remove("is-invalid");
  supplierSelect.classList.add("is-valid");

  quotationRequestStatusSelect.value = JSON.stringify(dataOb.quotation_request_status_id); //dynmaic

  //required nati nisa
  if (dataOb.txtNote == null) {
    txtNote.value = " ";
  } else {
    txtNote.value = dataOb.note;
  }

  $("#quotationRequestFormModal").modal("show"); //show modal

  //disable submit button,Enable update button in edit function
  qoRSubmitButton.style.display = "none";
  qoRUpdateButton.removeAttribute("style");
  
  
  refreshQuotationRequestInnerForm();
};

//function for delete row
const quotationRequestDelete = (dataOb, index) => {
  console.log("Delete", dataOb, index);

  //need to get user confirmation
    let userConfirmation=window.confirm("Are You sure you want to delete the following Quotation Request .. ?"+
      "\nQuotation Request No :"+dataOb.quotation_request_no + 
      "\nSupplier Name :"+dataOb.supplier_id.suppliername + 
      "\nRequested Date :"+dataOb.requested_date +
      "\nQuotation Request Status:"+dataOb.quotation_request_status_id.name

    );
    if (userConfirmation) {
      //Call delete service
      let deleteResponse=getHTTPServiceRequest("/quotationrequest/delete","DELETE",dataOb);
      if (deleteResponse=="OK") {

        window.alert("Delete Successfull !..\n");
        refreshQuotationRequestTable();//refresh quotationrequest table
        // window.location.reload(); full browser reload -->reload every image&...
        refreshQuotationRequestForm();//refresh quotationrequest form

      } else {
        window.alert("Delete Failed !..\n"+deleteResponse);
      }
    }
};

//function for view/print row
const quotationRequestView = (dataOb, index) => {
  console.log("View", dataOb, index);

  //option 1

  //how to open a new tab and enter html tags and styles using js

  /* 
  let newTab=window.open();
  let printTab="<head><title>quotationrequest Print</title>"+
  "<link rel='stylesheet' href='../resources/bootstrap-5.2.3/css/bootstrap.min.css'></head>"+
  "<body><table class='table table-striped'><tr><th>Full Name</th><td>"+dataOb.fullname+"</td></tr></table></body>";
  newTab.document.write(printTab);

  setTimeout(()=>{
    //what should happen after 1500 ms
    newTab.stop();
    newTab.print();
    newTab.close();
  },1500) */

  //option 2 view in  a modal

  qr_req_no.innerText = dataOb.quotation_request_no;
  qr_items.innerText = getItemList(dataOb);
  qr_supplier.innerText = dataOb.supplier_id.suppliername;
  qr_requested_date.innerText = dataOb.requested_date;
  qr_Status.innerText = dataOb.quotation_request_status_id.name;
 

  $("#quotationRequestModalView").modal("show"); //show modal
};

//option 2 Print row new tab open
const printButtonRow = () => {
  let newTab = window.open();
  let printTab =
"<head><title>Quotation Request Print</title>" +
"<link rel='stylesheet' href='bootstrap-5.2.3/css/bootstrap.min.css'>" +
"</head>" +
"<body>" +
"<h4 class='text-center mt-3'>Quotation Request Print</h4>" +
"<div class='container mt-3'>" +
"  <div class='row justify-content-center'>" +
"    <div class='col-md-8'>" + quotationRequestTableView.outerHTML + "</div>" +
"  </div>" +
"</div>" +
"</body>";
  newTab.document.write(printTab);

  setTimeout(() => {
    //what should happen after 1500 ms
    newTab.stop();
    newTab.print();
    newTab.close();
  }, 1500);
};

/* *************************************************************************** */
/* **************************  FORM *********************************************/

//refresh form area
const refreshQuotationRequestForm = () => {
  //static element only is cleared
  //Cleaning the values(select list not needed dynamic nm )

  formQuotationRequest.reset(); //clearing the form values

  quotationRequest = new Object(); //creating a new object
  quotationRequest.quotationRequestHasItemList = new Array();
  supplierSelect.disabled="";//disabling supplier selection at refill/edit need to enable in refreshform function
  //refilling the dynamic elements
  let supplier = getServiceRequest("/supplier/findall"); //calling the ajax request func in coommon func.js

  //quotation Request Status select list
  let quotationRequestStatus = getServiceRequest(
    "/quotationrequeststatus/findall"
  ); //calling the ajax request func in coommon func.js

  //calling reusable function for select list(elementid,massege,dtaalistname,prportyname of the datalist)
  fillDataintoSelect(
    supplierSelect,
    "Select Supplier",
    supplier,
    "suppliername"
  );
  //calling reusable function for select list(elementid,massege,dtaalistname,prportyname of the datalist)
  fillDataintoSelect(
    quotationRequestStatusSelect,
    "Select Quotation Request Status",
    quotationRequestStatus,
    "name"
  );

  //set Quotation Request status aailable when loading form
  quotationRequestStatusSelect.value = JSON.stringify(
    quotationRequestStatus[0]
  ); //[0] is "available" in Quotation Request  status table
  quotationRequest.quotation_request_status_id = JSON.parse(
    quotationRequestStatusSelect.value
  );

  //Need to clear the colors

  setToDefault([
    supplierSelect,
    txtRequestedDate,
    txtNote,
    quotationRequestStatusSelect,
  ]);

  /*  txtFullname.classList.remove("is-valid");
  //  txtFullname.style.border="1px solid #ced4da";
  civilStatus.classList.remove("is-valid");
  //  civilStatus.style.border="1px solid #ced4da"; */

  //set color for quotation Request Status
  quotationRequestStatusSelect.classList.remove("is-invalid");
  quotationRequestStatusSelect.classList.add("is-valid");

  //disable update button,Enable submit button

  qoRUpdateButton.style.display = "none";
  qoRSubmitButton.removeAttribute("style");

  //set min max value for require date[YYYY-MM-DD]
  let currentDate = new Date();
  let currentMonth = currentDate.getMonth() + 1; //getMonth gives [0-11] so we need to add 1
  if (currentMonth < 10) {
    currentMonth = "0" + currentMonth;
  }
  let CurrentDay = currentDate.getDate(); //[1-31]
  if (CurrentDay < 10) {
    CurrentDay = "0" + CurrentDay;
  }

  txtRequestedDate.min =
    currentDate.getFullYear() + "-" + currentMonth + "-" + CurrentDay;

  currentDate.setDate(currentDate.getDate() + 14); //adding 14 days to current date to get the max date

  let maximumcurrentMonth = currentDate.getMonth() + 1; //getMonth gives [0-11] so we need to add 1
  if (maximumcurrentMonth < 10) {
    maximumcurrentMonth = "0" + maximumcurrentMonth;
  }
  let maximumCurrentDay = currentDate.getDate(); //[1-31]
  if (maximumCurrentDay < 10) {
    maximumCurrentDay = "0" + maximumCurrentDay;
  }

  txtRequestedDate.max =
    currentDate.getFullYear() +
    "-" +
    maximumcurrentMonth +
    "-" +
    maximumCurrentDay;

  refreshQuotationRequestInnerForm();
};

//check form errors
const checkQuotationRequestFormErrors = () => {
  let errors = "";
  if (quotationRequest.supplier_id == null) {
    errors = errors + "Please Select Supplier\n";
  }
  if (quotationRequest.requested_date == null) {
    errors = errors + "Please Enter  Required Date\n";
  }
  if (quotationRequest.quotation_request_status_id == null) {
    errors = errors + "Please Select  Quotation Request Status\n";
  }
  if (quotationRequest.quotationRequestHasItemList.length == 0) {
    errors = errors + "Please Select Quotation Request Item\n";
  }

  return errors;
};

//Quotation Request form submit event Function
const quotationRequestSubmitButton = () => {
  console.log(quotationRequest);

  //check form error for required fields
  let errors = checkQuotationRequestFormErrors(); //call the error function
  if (errors == "") {
    //no errors
    //need to get user confirmation
    let userConfirmation = window.confirm(
      "Are You sure you want to add the following Quotation Request .. ?" +
        "\nRequested Date :" +
        quotationRequest.requested_date +
        "\nSupplier Name :" +
        quotationRequest.supplier_id.suppliername +
        "\nQuotation Request Status:" +
        quotationRequest.quotation_request_status_id.name
    );
    if (userConfirmation) {
      //Call post service(url,method,data) data means object name-->quotationrequest
      let postServiceResponse = getHTTPServiceRequest(
        "/quotationrequest/insert",
        "POST",
        quotationRequest
      );
      if (postServiceResponse == "OK") {
        window.alert("Submission Successfull !..\n");
        refreshQuotationRequestTable(); //refresh quotationrequest table
        // window.location.reload(); full browser reload -->reload every image&...
        refreshQuotationRequestForm(); //refresh quotationrequest form
        $("#quotationRequestFormModal").modal("hide"); //Hide modal
      } else {
        window.alert("Submission Failed !..\n" + postServiceResponse);
      }
    }
  } else {
    window.alert("Form Contains Following Errors !..\n" + errors);
  }

  // console.log(purchaseorder);

  refreshQuotationRequestTable();
};

const quotationRequestFromUpdates = () => {
  let updates = "";

  console.log(quotationRequest);
  console.log(oldquotationRequest);//if there is an update only the quotationRequest variable will be modified since its the passing object in frontend 

  if (quotationRequest != null && oldquotationRequest != null) {
    if (quotationRequest.requested_date != oldquotationRequest.requested_date) {
      updates =
        updates +
        "Requested Date changed from " +
        oldquotationRequest.requested_date +
        " into " +
        quotationRequest.requested_date +
        "\n";
    }
    if (quotationRequest.quotation_request_status_id.name != oldquotationRequest.quotation_request_status_id.name) {
      updates =
        updates +
        "Quotation Request Status changed from " +
        oldquotationRequest.quotation_request_status_id.name +
        " into " +
        quotationRequest.quotation_request_status_id.name +
        "\n";
    }
    
  }

  return updates;
};

//quotation request  Form update event function
const quotationRequestUpdateButton = () => {
  //check for form errors
  let errors = checkQuotationRequestFormErrors();
  if (errors == "") {
    //check for quotation request Form updates
    let updates = quotationRequestFromUpdates();
    if (updates == "") {
      window.alert("Form Contains No Updates..!");
    } else {
      //Need user confirmation
      let userConfirmation = window.confirm(
        "Are you Sure you want to update the following changes ?\n" + updates
      );
      if (userConfirmation) {
        //call put service

        let putServiceResponse = getHTTPServiceRequest(
          "/quotationrequest/update",
          "PUT",
          quotationRequest
        );
        if (putServiceResponse == "OK") {
          window.alert("Form update Successfull..!");
          refreshQuotationRequestForm();
          $("#quotationRequestFormModal").modal("hide"); //Hide modal
        } else {
          window.alert("Form Update Unsucessfull..!\n" + putServiceResponse);
        }
      }
    }
  } else {
    window.alert("Form Contains Following Errors !..\n" + errors);
  }

  refreshQuotationRequestTable();
};

//quotation request  Form Delete function
const DeleteQuotationRequest = (dataOb, rowIndex) => {
  refreshQuotationRequestTable();
};

/* *************************************************************************** */
/* ************************** INNER FORM *********************************************/

//define function to filter item list by existance of inner table
const filterItemListbyExistance = () => {

  // let selectedItem = JSON.parse(itemSelect.value);
  let selectedItem = quotationRequestHasItem.item_id;

  // find the index of a specific item in a list inside a quotation request object.
  let extIndex = quotationRequest.quotationRequestHasItemList.map((qritem) => qritem.item_id.id).indexOf(selectedItem.id);

  console.log("index" + extIndex);

    /*
   quotationRequest.quotationRequestHasItemList
      This is assumed to be an array (e.g., a list of items in a quotationRequest requestes).

      Example structure:

      quotationRequestHasItemList = [
        { item_id: { id: 101 } },
        { item_id: { id: 202 } },
        { item_id: { id: 303 } }
      ];
      2. .map((qritem) => qritem.item_id.id)
      This transforms the array into just a list of item IDs.

      From the above example, you'd get:

      [101, 202, 303]
      .indexOf(selectedItem.id)
      This finds the index of selectedItem.id in the array of item IDs.

      If selectedItem.id = 202, the result would be 1.

      let extIndex = ...
      Stores the index in a variable called extIndex.

      If the selectedItem.id is not found, extIndex will be -1. */

  if (extIndex != -1) {
    //index exists
    window.alert("Selected item already exists....!");
    refreshQuotationRequestInnerForm();
  }
};

//define function to filter item list by supplier (need to call this function at supplier dropdown in quotationrequest.html)
const filterItemListbySupplier = () => {
  //get the items
  let items = getServiceRequest(
    "/item/listbysupplier/" + JSON.parse(supplierSelect.value).id
  ); //calling the ajax request func in coommon func.js

  //calling reusable function for select list(elementid,massege,dtaalistname,prportynameOne,proprtynameTwo of the datalist)
/*   fillDataintoSelectTwo(
    itemSelect,
    "Select Item",
    items,
    "item_no",
    "itemname"
  ); */

  //filling to item datalist
  //calling reusable function for data list(elementid,dtaalistname,prportynameOne,proprtynameTwo of the datalist)
 fillDataintoDataList(
    itemList,
    items,
    "item_no",
    "itemname"
  );

};

//Funtion for inner form
const refreshQuotationRequestInnerForm = () => {
  //creating a new object
  quotationRequestHasItem = new Object();

   items = [];
  if (supplierSelect.value != "") {
    //get the items
    items = getServiceRequest("/item/listbysupplier/" + JSON.parse(supplierSelect.value).id); //calling the ajax request func in coommon func.js
  } else {
    //get the items
    items = getServiceRequest("/item/findall"); //calling the ajax request func in coommon func.js
  }

  //calling reusable function for select list(elementid,massege,dtaalistname,prportynameOne,proprtynameTwo of the datalist)
/*   fillDataintoSelectTwo(
    itemSelect,
    "Select Item",
    items,
    "item_no",
    "itemname"
  );
 */

  //filling to item datalist
    //calling reusable function for data list(elementid,dtaalistname,prportynameOne,proprtynameTwo of the datalist)
 fillDataintoDataList(
    itemList,
    items,
    "item_no",
    "itemname"
  );


  //cant reset because it will reset the main form also
  //so need to clear the values
  txtQty.value = "";
    textItemName.value="";//clearing datalist
  //itemSelect.value="";//for dynamic no need to clear values

  //Need to clear the colors
  //setToDefault([itemSelect, txtQty]); since using a datalist for item not a select list
  setToDefault([textItemName, txtQty]);//textItemName datalist inpufield id

  //disable update button,Enable submit button
  quotationRequestInnerItemupdateButton.classList.add("d-none");
  quotationRequestInnerItemsubmitButton.classList.remove("d-none");

  //refresh inner table

  //Datatypes
  //string --> date/string/number
  //function-->object/array/boolean
  //decimal-->decimal/price
  let columnList = [
    { columnName: getQuotationRequestItemName, dataType: "function" },
    { columnName: "qty", dataType: "string" },
  ];

  //call the common function to fill data into table(tablebody id,datalist name,column list,edit parameter,
  //delete parameter,view parameter,button visibility)
  // fillDataintoInnerTable(quotationRequestItemTableBody,purchaseorders,columnList,quotationRequestItemEdit,quotationRequestItemDelete,true);
  fillDataintoInnerTable(
    quotationRequestItemTableBody,
    quotationRequest.quotationRequestHasItemList,
    columnList,
    quotationRequestItemEdit,
    quotationRequestItemDelete,
    true
  );
};

//function to get quotation request item name
const getQuotationRequestItemName = (dataOb) => {
  return dataOb.item_id.itemname;
};

//function to edit/refill inner form
const quotationRequestItemEdit = (dataOb, index) => {

  innerFormIndex=index;

    //if there is an update only the quotationRequestHasItem variable will be modified since its the passing object in frontend 
  quotationRequestHasItem = JSON.parse(JSON.stringify(dataOb)); // Working copy for editing
  oldquotationRequestHasItem = JSON.parse(JSON.stringify(dataOb)); // Original copy for comparison

  /* JSON.stringify(dataOb) converts the object to a JSON string
JSON.parse() converts that JSON string back to a JavaScript object
This creates a completely new object with the same data */

  //get the items
  let items = getServiceRequest("/item/itemlist"); //calling the ajax request func in coommon func.js

  //calling reusable function for select list(elementid,massege,dtaalistname,prportynameOne,proprtynameTwo of the datalist,selected itemid)
  /* fillDataintoSelectTwo(
    itemSelect,
    "Select Item",
    items,
    "item_no",
    "itemname",
    quotationRequestHasItem.item_id.item_no
  ); */

  //filling to item datalist
  textItemName.value=quotationRequestHasItem.item_id.item_no+' '+quotationRequestHasItem.item_id.itemname;

  //itemSelect.disabled = "disabled"; //disabling item selection
  textItemName.disabled = "disabled"; //disabling item selection
  textItemName.classList.remove("is-invalid");
  textItemName.classList.add("is-valid");

  txtQty.value = quotationRequestHasItem.qty;
  txtQty.classList.remove("is-invalid");
  txtQty.classList.add("is-valid");

  //disable submit button,Enable update button
  quotationRequestInnerItemupdateButton.classList.remove("d-none");
  quotationRequestInnerItemsubmitButton.classList.add("d-none");
};

const quotationRequestItemDelete = (dataOb, index) => {
  //need to get user confirmation
  let userConfirmation = window.confirm(
    "Are You sure you want to Remove the following Item .. ?" +
      "\nItem Name :" +
      dataOb.item_id.itemname +
      "\n Quantity :" +
      dataOb.qty
  );
  if (userConfirmation) {
    window.alert("Delete Successfull !..\n");

    //remove an existing item record from the inner form list (quotationRequestHasItemList) if it already exists — based on item_id.
    let extIndex = quotationRequest.quotationRequestHasItemList
      .map((orderitem) => orderitem.item_id.id)//Extracts a list of all item_id.id values from the quotationRequestHasItemList (ex:-[101, 102, 103])
      .indexOf(dataOb.item_id.id);//Searches for the index of the item ID from dataOb in that list.Returns:0, 1, 2, etc., if found,-1 if not found
    if (extIndex != -1) {
      quotationRequest.quotationRequestHasItemList.splice(extIndex, 1);//Removes one item at the index extIndex.Effectively deletes that item from the inner form list.
    }
    // window.location.reload(); full browser reload -->reload every image&...
  } else {
    window.alert("Form Contains Errors !..\n");
  }

  refreshQuotationRequestInnerForm(); //refresh quotation Request inner form
};


//check inner form errors
const checkInnerFormErrors=()=>{
  innererrors="";
   if (quotationRequestHasItem.item_id == null ) {
    innererrors = innererrors + "Please select Item \n";
  }
  if (quotationRequestHasItem.qty == null) {
    innererrors = innererrors + "Please Enter Quantity\n";
  }
  return innererrors;
}


const quotationRequestItemSubmitButton = () => {
  console.log(quotationRequestHasItem);
   innererrors = checkInnerFormErrors(); //call the error function
  if (innererrors == "") {
  //need to get user confirmation
  let userConfirmation = window.confirm(
    "Are You sure you want to add the following Item .. ?" +
      "\nItem Name :" +
      quotationRequestHasItem.item_id.itemname +
      "\nQuantity :" +
      quotationRequestHasItem.qty
  );
  if (userConfirmation) {
    window.alert("Submission Successfull !..\n");
    quotationRequest.quotationRequestHasItemList.push(quotationRequestHasItem);
    // window.location.reload(); full browser reload -->reload every image&...
    refreshQuotationRequestInnerForm(); //refresh quotation Request inner form
  } else {
    window.alert("Form Contains Errors !..\n");
  }

  // console.log(quotationrequest);
  }
  else {
    window.alert("Form Contains Following Errors !..\n" + innererrors);
  }
  refreshQuotationRequestInnerForm();
};

const quotationRequestItemUpdateButton = () => {

  console.log(quotationRequestHasItem);

  if (quotationRequestHasItem.qty != oldquotationRequestHasItem.qty) {
    //need to get user confirmation
    let userConfirmation = window.confirm(
      "Are You Sure you want to update the following changes.. ?" +
        "\nQuantity Changed from :" +oldquotationRequestHasItem.qty+" to "+quotationRequestHasItem.qty
    );

    if (userConfirmation) {
      window.alert("Update Successfull !..\n");
      quotationRequest.quotationRequestHasItemList[innerFormIndex]=quotationRequestHasItem;
      // window.location.reload(); full browser reload -->reload every image&...
      refreshQuotationRequestInnerForm(); //refresh purchase order inner form
    } else {
      window.alert("Form Contains Errors !..\n");
    }
  }
  else{
    window.alert("Form Contains No Updates..!");
  }
  refreshQuotationRequestInnerForm();
};

