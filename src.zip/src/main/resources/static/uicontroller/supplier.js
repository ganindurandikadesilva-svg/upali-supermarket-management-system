//Browser load event
window.addEventListener("load", () => {
  console.log("load");
 
  

  //enable tooltip
  $('[data-bs-toggle="tooltip"]').tooltip();

  refreshSupplierTable();

  refreshSupplierForm();
});

//refresh table area
const refreshSupplierTable = () => {
  //
 // actionButtons.style.display = "none"; // added for table style 3
  //table
 
//calling the ajax request func in coommon func.js to get data
 suppliers  = getServiceRequest("/supplier/findall")

 /*  //accessing data of database using ajax for suppliers table
  $.ajax({
    url: "suppliers/findall",
    type: "GET", // HTTP method(GET/POST/PUT/DELETE)
    async: false,
    dataType: "json", // The type of data expected from the server
    success: function (response) {
      // Callback function executed if the request is successful
      console.log("Success", response);
      suppliers = response;
    },
    error: function (xhr, status, error) {
      // Callback function executed if the request fails
      console.log("Error", response);
    },
  }); */

  //Datatypes
  //string --> date/string/number
  //function-->object/array/boolean
  //decimal-->decimal/price
  let columnList = [
    { columnName: "suppliername", dataType: "string" },
    { columnName: "email", dataType: "string" },
    { columnName: "contact_no", dataType: "string" },
    { columnName: getItemname, dataType: "function" },
    { columnName: "contactperson_name", dataType: "string" },
    { columnName: getSupplierStatus, dataType: "function" },
  ];

  //call the common function to fill data into table(tablebody id,datalist name,column list,edit parameter,
  //delete parameter,view parameter,button visibility)
  // fillDataintoTable(supplierTableBody,suppliers,columnList,supplierEdit,supplierDelete,supplierView,true);
  fillDataintoTableTwo(
    supplierTableBody,
    suppliers,
    columnList,
    supplierEdit,
    supplierDelete,
    supplierView,
    true
  );
  // fillDataintoTableThree(supplierTableBody,suppliers,columnList,true);


   //disabling modifying buttons based on conditions
   for (const index in suppliers) {

    if (suppliers[index].supplier_status_id.name=="Deleted") {
    const row = supplierTableBody.children[index];         // get the <tr>
    const lastCell = row.lastElementChild;                      // get the last <td>
    const deleteBtn = lastCell.querySelector("ul li:nth-child(3) button"); // third li button = Delete    
    deleteBtn.disabled="disabled";//deleteBtn.classList.add("d-none") for hide delete btn
  }
    
  }

  $("#supplierTable").DataTable();
};



//function to get Supplier status to table
const getSupplierStatus = (dataOb) => {
  if (dataOb.supplier_status_id.name=="Active") {
    let active="<span class='badge text-bg-success'>"+dataOb.supplier_status_id.name+ "</span>";
    return  active ;
  }
  if (dataOb.supplier_status_id.name=="Inactive") {
    let inactive="<span class='badge text-bg-primary'>"+dataOb.supplier_status_id.name+ "</span>";
    return  inactive ;
  }
  if (dataOb.supplier_status_id.name=="Deleted") {
    let deleted="<span class='badge text-bg-danger'>"+dataOb.supplier_status_id.name+ "</span>";
    return  deleted ;
  }


};


//function to get item name to table
const getItemname=(dataOb)=>{
  let suppliedItems = "";
  dataOb.suppliedItems.forEach((item, index) => {
    if (dataOb.suppliedItems.length - 1 == index) {
      suppliedItems = suppliedItems + item.itemname; //remove the comma if its the last value
    } else {
      suppliedItems = suppliedItems + item.itemname + ",";
    }
  });
  return suppliedItems;

}



//Functions for list transfer
//Function for Adding selected item 
const addSelectedItem =()=>{

  if (allItemSelect.value!="")//select krl tibboth witharai add krnn puluwn
  {
    let selectedItem=JSON.parse(allItemSelect.value);//selected element
  supplier.suppliedItems.push(selectedItem);//selected element is pushed to selectedItems List
  fillDataintoSelect(selectedItemSelect,"",supplier.suppliedItems,"itemname");//refresh the list after pushing
 
  let extIndex=allItems.map(item=>item.id).indexOf(selectedItem.id);//all item eke id eka selecteditem eke id ekt samana wenn one
 

  if (extIndex != -1) {
    //index eka tiynwanm tiyn tanin ain krl dnwa
    allItems.splice(extIndex,1)//(allitem list eken ain krnwa)
   
    
  }
  fillDataintoSelect(allItemSelect,"",allItems,"itemname");
  }


}

//Function for Adding all items
const addAllItems =()=>{

  for (const item of allItems) {
    supplier.suppliedItems.push(item);
  }

  fillDataintoSelect(selectedItemSelect,"",supplier.suppliedItems,"itemname");//refresh the list after pushing
 
  allItems=[];
  fillDataintoSelect(allItemSelect,"",allItems,"itemname");


}

//Function for Removing selected item
const removeSelectedItem =()=>{

  if (selectedItemSelect.value!="")//select krl tibboth witharai add krnn puluwn
  {
    let selectedItem=JSON.parse(selectedItemSelect.value);//selected element
    allItems.push(selectedItem);//selected element is pushed to allitems List
    fillDataintoSelect(allItemSelect,"",allItems,"itemname");
   
    let extIndex=supplier.suppliedItems.map(item=>item.id).indexOf(selectedItem.id);//all item eke id eka selecteditem eke id ekt samana wenn one
  
    if (extIndex != -1) {
      //index eka tiynwanm tiyn tanin ain krl dnwa (selected list eken ain krnwa )
      supplier.suppliedItems.splice(extIndex,1)
     
      
    }
    fillDataintoSelect(selectedItemSelect,"",supplier.suppliedItems,"itemname");//refresh the list after pushing
  
  }

}

//Function for removing all  items
const removeAllItems =()=>{
  for (const item of supplier.suppliedItems) {
    allItems.push(item);
  }
  fillDataintoSelect(allItemSelect,"",allItems,"itemname");
 
  supplier.suppliedItems=[];
  fillDataintoSelect(selectedItemSelect,"",supplier.suppliedItems,"itemname");//refresh the list after pushing

}


//common function to get item name list for confirm messege
const itemNameList=(dataOb)=>{

   //item name list
   let itemNames = [];
   dataOb.suppliedItems.forEach((element) => {
   itemNames.push(element.itemname);
   });
   //.join(", ") creates a single string with commas only between elements:
  
 return itemNames.join(", ");//return krnwa item namelist  with commas inbetween
}




//function for edit row
const supplierEdit = (dataOb, index) => {
  //old supplier and supplier for update checking
  supplier = JSON.parse(JSON.stringify(dataOb));
  oldSupplier = JSON.parse(JSON.stringify(dataOb));//if there is an update only the supplier variable will be modified since its the passing object in frontend 

  console.log("Edit", dataOb, index);
  //supplierTableBody.children[index].style.border="2px solid black";

  //refill the form

   //static
  txtsuppliername.value = dataOb.suppliername;
  txtEmail.value = dataOb.email;
  supplierContactNo.value = dataOb.contact_no;
  supplierTxtAddress.value=dataOb.address;
  txtContactPersonName.value = dataOb.contactperson_name;
  txtContactPersonTelNo.value = dataOb.contactperson_telno;
  txtBuisnessRegNo.value = dataOb.buisness_reg_no;
  txtbankName.value = dataOb.bank_name;
  txtBankBranch.value = dataOb.bank_branch;
  txtAccountName.value = dataOb.account_name;
  txtAccountNo.value = dataOb.account_no; //static

 //object ekk nisa (dynamic ewge)
  supplierStatusSelect.value = JSON.stringify(dataOb.supplier_status_id); //dynmaic

   //required nati nisa
   if (dataOb.txtSupplierNote == null) {
    txtSupplierNote.value = " ";
  } else {
    txtSupplierNote.value = dataOb.note;
  }

  //meken ywn supplier id ekt itemcontroller eke mapping ekk liynwa
  allItems=getServiceRequest("/item/listWithoutSupply?supplierid="+supplier.id);//supplier supply krnne nati item genna

  fillDataintoSelect(allItemSelect,"",allItems,"itemname");
  fillDataintoSelect(selectedItemSelect,"",supplier.suppliedItems,"itemname");

  $("#supplierFormModal").modal("show"); //show modal

  
  //disable submit button,Enable update button in edit function
  submitButton.style.display="none";
  updateButton.removeAttribute("style");
};

//function for delete row
const supplierDelete = (dataOb, index) => {
  console.log("Delete", dataOb, index);
  
  
 

  //add sweet alert
  /* let userDeleteMsg =
    "\Supplier Name :" +dataOb.fullname +
    "\Supplier Calling Name :" +dataOb.callingname +
    "\Supplier DOB :" +dataOb.dob +
    "\Supplier NIC :" +dataOb.nic +
    "\Supplier Email :" +dataOb.email +
    "\Supplier Designation :" +dataOb.designaton_id.name+
    "\Supplier Mobile No :" +dataOb.mobile_no +
    "\Supplier Land No :" +dataOb.landno +
    "\Supplier Gender :" +dataOb.gender +
    "\Supplier Civil Status :" +dataOb.civil_status;

  Swal.fire({
    title: "Are you sure?",
    text: userDeleteMsg,
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes, delete it!",
  }).then((userResponse) => {
    if (userResponse.isConfirmed) {
      //employee=dataOb need to change the object name based on theobject name used in delete employeeDelete()

      let deleteResponse=getHTTPServiceRequest("/employee/delete","DELETE",dataOb);

      if (deleteResponse) {
        Swal.fire({
          title: "Delete Sucessfull!",
          text: "Your file has been deleted.",
          icon: "success",
        });
        refreshEmpTable();
        refreshEmpForm();
        $("#employeeFormModal").modal("hide"); //Hide modal
      } else {
        Swal.fire({
          title: "Delete unsucessfull!",
          text: "Your file has not been deleted.\n"+deleteResponse,
          icon: "error",
        });
      }

      
    }
  }); */

 
  //need to get user confirmation
    let userConfirmation=window.confirm("Are You sure you want to delete the following Supplier .. ?"+
      "\nSupplier Name :" +dataOb.suppliername +
      "\nSupplier Email :" +dataOb.email +
      "\nSupplier Contact No :" +dataOb.contact_no +
      "\nSupplier Address :" +dataOb.address +
      "\nSupplier Contact Person Name :" +dataOb.contactperson_name+
      "\nSupplier Status :" +dataOb.supplier_status_id.name +
      "\nSupplier Contact Person Tel-No :" +dataOb.contactperson_telno +
      "\nSupplier Business Reg No :" +dataOb.buisness_reg_no+ 
      "\nSupplier Bank Name :" +dataOb.bank_name+ 
      "\nSupplier Bank Branch :" +dataOb.bank_branch+ 
      "\nSupplier Account Name :" +dataOb.account_name+ 
      "\nSupplier Account No :" +dataOb.account_no+
      "\nSupplied Items :" + itemNameList(dataOb)
    );
    if (userConfirmation) {
      //Call delete service
      let deleteResponse=getHTTPServiceRequest("/supplier/delete","DELETE",dataOb);
      if (deleteResponse=="OK") {

        window.alert("Delete Successfull !..\n");
        refreshSupplierTable();//refresh supplier table
        // window.location.reload(); full browser reload -->reload every image&...
        refreshSupplierForm();//refresh supplier form

      } else {
        window.alert("Submission Failed !..\n"+deleteResponse);
      }
    }
};

//function for view/print row
const supplierView = (dataOb, index) => {
  console.log("View", dataOb, index);

  //option 1

  //how to open a new tab and enter html tags and styles using js

  /* 
  let newTab=window.open();
  let printTab="<head><title>Employee Print</title>"+
  "<link rel='stylesheet' href='../resources/bootstrap-5.2.3/css/bootstrap.min.css'></head>"+
  "<body><table class='table table-striped'><tr><th>Full Name</th><td>"+dataOb.fullname+"</td></tr></table></body>";
  newTab.document.write(printTab);

  setTimeout(()=>{
    //what should happen after 1500 ms
    newTab.stop();
    newTab.print();
    newTab.close();
  },1500) */

  //option 2 view in  a modal

txtSupplier_name.innerText = dataOb.suppliername;
txtSupplier_email.innerText = dataOb.email;
txtSupplier_contact_no.innerText = dataOb.contact_no;
txtSupplier_address.innerText = dataOb.address;
txtContactperson_name.innerText = dataOb.contactperson_name;
txtSupplier_status.innerText = dataOb.supplier_status_id.name;
txtContactperson_telno.innerText = dataOb.contactperson_telno;
txtbusiness_regNo.innerText = dataOb.buisness_reg_no;
txtBank_name.innerText = dataOb.bank_name;
txtBank_branch.innerText = dataOb.bank_branch;
txtAccount_name.innerText = dataOb.account_name;
txtAccount_no.innerText = dataOb.account_no;
txtSupplied_items.innerText = getItemname(dataOb); // txtSupplied_items.innerText = itemNames.join(", "); //join a comma after a role but no the last role


  $("#supplierFormModalView").modal("show"); //show modal
};

//option 2 Print row new tab open
const printButtonRow = () => {
  let newTab = window.open();
  let printTab =
"<head><title>Supplier Print</title>" +
"<link rel='stylesheet' href='bootstrap-5.2.3/css/bootstrap.min.css'>" +
"</head>" +
"<body>" +
"<h4 class='text-center mt-3'>Supplier Print</h4>" +
"<div class='container mt-3'>" +
"  <div class='row justify-content-center'>" +
"    <div class='col-md-8'>" + supplierTableView.outerHTML + "</div>" +
"  </div>" +
"</div>" +
"</body>";
  newTab.document.write(printTab);

  setTimeout(() => {
    //what should happen after 1500 ms
    newTab.stop();
    newTab.print();
    newTab.close();
  }, 1500);
};




/* *************************************************************************** */
/* **************************  FORM *********************************************/

//refresh form area
const refreshSupplierForm = () => {
 

  //static element only is cleared
  //Cleaning the values(select list not needed dynamic nm )
  

  formSupplier.reset(); //clearing the form values

  supplier = new Object(); //creating a new object
  supplier.suppliedItems=new Array();//creating an array for selected items

  /* txtFullname.value="";
   radioMale.value=""; */

//refilling the dynamic elements
    //supplier status select list
 let supplierStatus = getServiceRequest("/supplierstatus/findall")//calling the ajax request func in coommon func.js
  allItems=getServiceRequest("/item/findall")

 //calling reusable function for select list(elementid,massege,dtaalistname,prportyname of the datalist)
  fillDataintoSelect(
    supplierStatusSelect,
    "Select Supplier Status",
    supplierStatus,
    "name"
  );

  //fill data into itemAll select
  fillDataintoSelect(
    allItemSelect,
    "",
    allItems,
    "itemname"
  );
  //fill data into selected items
  fillDataintoSelect(
    selectedItemSelect,
    "",
    supplier.suppliedItems,
    "itemname"
  );
  


    //set supplier status aailable when loading form
    supplierStatusSelect.value=JSON.stringify(supplierStatus[0]);//[0] is "available" in supplier status table
    supplier.supplier_status_id=JSON.parse(supplierStatusSelect.value);

    // //Need to clear the colors
  setToDefault([
    txtsuppliername,
    txtEmail,
    supplierContactNo,
    supplierTxtAddress,
    txtContactPersonName,
    txtContactPersonTelNo,
    txtBuisnessRegNo,
    txtbankName,
    txtBankBranch,
    txtAccountName,
    txtAccountNo,
    supplierStatusSelect,
    txtSupplierNote
  ]);
    /*  txtFullname.classList.remove("is-valid");
  //  txtFullname.style.border="1px solid #ced4da";*/

  
  //set color for supplier Status
  supplierStatusSelect.classList.remove("is-invalid");
  supplierStatusSelect.classList.add("is-valid"); 

    //disable update button,Enable submit button
  // updateButton.style.visibility="hidden";
  // submitButton.style.visibility="visible";

  updateButton.style.display="none";
  submitButton.removeAttribute("style");
};







//check form errors

const checkSupplierFormErrors = () => {
  let errors = "";
  if (supplier.suppliername == null) {
    errors = errors + "Please Enter Supplier Name \n";
  }
  if (supplier.email == null) {
    errors = errors + "Please Enter Supplier Email \n";
  }
  if (supplier.contact_no == null) {
    errors = errors + "Please Enter Supplier Contact No \n";
  }
  if (supplier.address == null) {
    errors = errors + "Please Enter Address \n";
  }
  if (supplier.contactperson_name == null) {
    errors = errors + "Please Enter Contact Person Name\n";
  }
  if (supplier.supplier_status_id == null) {
    errors = errors + "Please Select an Supplier Status \n";
  }
  if (supplier.contactperson_telno == null) {
    errors = errors + "Please Enter Contact Person Tel-No \n";
  }
  if (supplier.buisness_reg_no == null) {
    errors = errors + "Please Enter Business Reg No \n";
  }

  if (supplier.bank_name == null) {
    errors = errors + "Please Enter Bank Name\n";
  }
  if (supplier.bank_branch == null) {
    errors = errors + "Please Enter Bank Branch \n";
  }
  if (supplier.account_name == null) {
    errors = errors + "Please Enter Account name \n";
  }
  if (supplier.account_no == null) {
    errors = errors + "Please Enter Account No \n";
  }
  //suppliedItems is the array created in refreshSupplierForm function
  if (supplier.suppliedItems.length == 0) {
    errors = errors + "Please Select Item/s \n";
  }
  return errors;
};

//Supplier form submit event Function
const supplierSubmitButton = () => {

  console.log(supplier);
  
  //check form error for required fields
  let errors = checkSupplierFormErrors(); //call the error function
  if (errors == "") {
    //no errors
    //need to get user confirmation
    let userConfirmation = window.confirm(
      "Are You sure you want to add the following Supplier .. ?" +
      "\nSupplier Name :" +supplier.suppliername +
      "\nSupplier Email :" +supplier.email +
      "\nSupplier Contact No :" +supplier.contact_no +
      "\Supplier Address :" +supplier.address +
      "\nSupplier Contact Person Name :" +supplier.contactperson_name+
      "\nSupplier Status :" +supplier.supplier_status_id.name +
      "\nSupplier Contact Person Tel-No :" +supplier.contactperson_telno +
      "\nSupplier Business Reg No :" +supplier.buisness_reg_no+ 
      "\nSupplier Bank Name :" +supplier.bank_name+ 
      "\nSupplier Bank Branch :" +supplier.bank_branch+ 
      "\nSupplier Account Name:" +supplier.account_name+ 
      "\nSupplier Account No:" +supplier.account_no+
      "\nSupplied Items :" + itemNameList(supplier)
    );
    if (userConfirmation) {
      //Call post service(url,method,data) data means object name-->supplier
      let postServiceResponse = getHTTPServiceRequest("/supplier/insert","POST",supplier);
      if (postServiceResponse == "OK") {
        window.alert("Submission Successfull !..\n");
        refreshSupplierTable(); //refresh supplier table
        // window.location.reload(); full browser reload -->reload every image&...
        refreshSupplierForm(); //refresh supplier form
        $("#supplierFormModal").modal("hide"); //Hide modal
      } else {
        window.alert("Submission Failed !..\n" + postServiceResponse);
      }
    }
  } else {
    window.alert("Form Contains Following Errors !..\n" + errors);
  }

  // console.log(supplier);

  refreshSupplierTable();
};

const checkSupplierFormUpdates = () => {
  let updates = "";

  console.log(supplier);
  console.log(oldSupplier);//if there is an update only the supplier variable will be modified since its the passing object in frontend 
  console.log(supplier.suppliedItems.length);
  console.log(supplier.suppliedItems);

  if (supplier != null && oldSupplier != null) {
    if (supplier.suppliername != oldSupplier.suppliername) {
      updates =
        updates +
        "Supplier Name changed from " +
        oldSupplier.suppliername +
        " into " +
        supplier.suppliername +
        "\n";
    }
    if (supplier.email != oldSupplier.email) {
      updates =
        updates +
        "Supplier Email changed from " +
        oldSupplier.email +
        " into " +
        supplier.email +
        "\n";
    }
    if (supplier.contact_no != oldSupplier.contact_no) {
      updates =
        updates +
        "Supplier Contact No changed from " +
        oldSupplier.contact_no +
        " into " +
        supplier.contact_no +
        "\n";
    }
    if (supplier.address != oldSupplier.address) {
      updates =
        updates +
        "Supplier Address changed from " +
        oldSupplier.address +
        " into " +
        supplier.address +
        "\n";
    }
    if (supplier.contactperson_name != oldSupplier.contactperson_name) {
      updates =
        updates +
        "Contact Person Name changed from " +
        oldSupplier.contactperson_name +
        " into " +
        supplier.contactperson_name +
        "\n";
    }
    if (supplier.supplier_status_id.name != oldSupplier.supplier_status_id.name) {
      updates =
        updates +
        "Supplier Status changed from " +
        oldSupplier.supplier_status_id.name +
        " into " +
        supplier.supplier_status_id.name +
        "\n";
    }
    if (supplier.contactperson_telno != oldSupplier.contactperson_telno) {
      updates =
        updates +
        "Contact Person Tel-No changed from " +
        oldSupplier.contactperson_telno +
        " into " +
        supplier.contactperson_telno+
        "\n";
    }
    if (supplier.buisness_reg_no != oldSupplier.buisness_reg_no) {
      updates =
        updates +
        "Business Reg No changed from " +
        oldSupplier.buisness_reg_no +
        " into " +
        supplier.buisness_reg_no +
        "\n";
    }
    if (supplier.bank_name != oldSupplier.bank_name) {
      updates =
        updates +
        "Bank Name changed from " +
        oldSupplier.bank_name +
        " into " +
        supplier.bank_name +
        "\n";
    }
    if (supplier.bank_branch != oldSupplier.bank_branch) {
      updates =
        updates +
        "Bank Branch changed from " +
        oldSupplier.bank_branch +
        " into " +
        supplier.bank_branch +
        "\n";
    }
    if (supplier.account_name != oldSupplier.account_name) {
      updates =
        updates +
        "Account Name changed from " +
        oldSupplier.account_name +
        " into " +
        supplier.account_name +
        "\n";
    }
    if (supplier.account_no != oldSupplier.account_no) {
      updates =
        updates +
        "Account No changed from " +
        oldSupplier.account_no +
        " into " +
        supplier.account_no +
        "\n";
    }
    if (supplier.suppliedItems.length != oldSupplier.suppliedItems.length) {
      updates =
        updates +
        "Selected Items changed";
        
    }
    
  }

  return updates;
};

//Supplier Form update event function
const supplierUpdateButton = () => {
  //check for form eroors
  let errors = checkSupplierFormErrors();
  if (errors == "") {
    //check for Supplier Form updates
    let updates = checkSupplierFormUpdates();
    if (updates == "") {
      window.alert("Form Contains No Updates..!");
    } else {
      //Need user confirmation
      let userConfirmation = window.confirm(
        "Are you Sure you want to update the following changes ?\n" + updates
      );
      if (userConfirmation) {

        //call put service

        let putServiceResponse = getHTTPServiceRequest("/supplier/update","PUT",supplier);;
        if (putServiceResponse == "OK") {
          window.alert("Form update Successfull..!");
          refreshSupplierForm();
          $("#supplierFormModal").modal("hide"); //Hide modal
        } else {
          window.alert("Form Update Unsucessfull..!\n" + putServiceResponse);
        }
      }
    }
  } else {
    window.alert("Form Contains Following Errors !..\n" + errors);
  }

  refreshSupplierTable();
};

//Supplier Form Delete function
const DeleteEmp = (dataOb, rowIndex) => {
  refreshSupplierTable();
};

