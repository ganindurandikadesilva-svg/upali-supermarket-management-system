window.addEventListener("load", () => {
  console.log("load");

  //call refresh inventory table function
  refreshInventoryTable();

 

  //enable tooltip
  $('[data-bs-toggle="tooltip"]').tooltip();
//  console.log(inventories);
  
});

//Fuction for refresh inventory table
const refreshInventoryTable = () => {
  //calling the ajax request func in coommon func.js to get data
  const inventories = getServiceRequest("/inventory/findall");

    //Datatypes
  //string --> date/string/number
  //function-->object/array/boolean
  //decimal-->decimal/price
  let columnList = [
    { columnName: getItem, dataType: "function" }, //object ekk misa function
    { columnName: "batch_no", dataType: "string" },
    { columnName: "total_qty", dataType: "decimal" },
    { columnName: "available_qty", dataType: "decimal" },
    { columnName: "exp_date", dataType: "string" },
    { columnName: "manufacture_date", dataType: "string" },
    { columnName: "sales_price", dataType: "decimal" }
  ];

  //call the common function to fill data into table(tablebody id,datalist name,column list,view parameter,button visibility)
  // fillDataintoTableFour(itemInventoryTableBody,inventories,columnList,employeeView,true);
  fillDataintoTableFour(
    itemInventoryTableBody,
    inventories,
    columnList,
    inventoryView,
    true
  );
  //disabling modifying buttons based on conditions
//removed the button by defining a filldatintotable functon without edit,delete btn

  $("#itemInventoryTable").DataTable();
};

//function to get Employee name
const getItem = (dataOb) => {
  if (dataOb.item_id != null) {
    return dataOb.item_id.itemname;
  } else {
    return "-";
  }

  


};





//function for view/print inventory
const inventoryView = (dataOb) => {
  console.log("View", dataOb);

  itemInv_itemname.innerText = dataOb.item_id.itemname;
  itemInv_batchno.innerText = dataOb.batch_no;
  itemInv_totalqty.innerText = dataOb.total_qty;
  itemInv_avqty.innerText = dataOb.available_qty;
  itemInv_expdate.innerText = dataOb.exp_date;
  itemInv_mfdate.innerText = dataOb.manufacture_date;
  itemInv_salesprice.innerText = dataOb.sales_price;

  $("#itemInventoryFormModalView").modal("show"); //show modal
};

//After clicking print on view modal
//Print row new tab open
const printButtonRow = () => {
  let newTab = window.open();
  let printTab =
 "<head><title>Item Inventory Print</title>" +
"<link rel='stylesheet' href='bootstrap-5.2.3/css/bootstrap.min.css'>" +
"</head>" +
"<body>" +
"<h4 class='text-center mt-3'>Item Inventory Print</h4>" +
"<div class='container mt-3'>" +
"  <div class='row justify-content-center'>" +
"    <div class='col-md-8'>" + inventoryTableView.outerHTML + "</div>" +
"  </div>" +
"</div>" +
"</body>";

  newTab.document.write(printTab);

  setTimeout(() => {
    //what should happen after 1500 ms
    newTab.stop();
    newTab.print();
    newTab.close();
  }, 1500);
};



