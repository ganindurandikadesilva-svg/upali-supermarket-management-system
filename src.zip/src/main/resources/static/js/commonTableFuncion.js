
//define fill data into table(tablebody id,datalist ,column list,edit function name,delete function name,view function name)
const fillDataintoTable=(tableBodyId,dataList,columnList,editFunction,deleteFunction,
    viewFunction,buttonVisibility=true)=>{


    
    tableBodyId.innerHTML="";//Cleaning the inner html

    dataList.forEach((dataOb,index )=> {

    let tr=document.createElement("tr");

    let tdindex=document.createElement("td");
    tdindex.innerText=parseInt(index)+1;
    tr.appendChild(tdindex);


    //console.log(dataOb);
    
    

    for (const column of columnList) {
        let td=document.createElement("td");

        if (column.dataType=="string") {
            td.innerText=dataOb[column.columnName];//column namer is string e nisa dot tiyl accesss krnn aba e nisa array ek k widiht dai
        } 
        if (column.dataType=="function") {
            td.innerHTML=column.columnName(dataOb);
        } 
        
        
        else {
            
        }
        tr.appendChild(td);
    }

    
    

   

    let tdActionbuttons=document.createElement("td");

    let editbtn=document.createElement("button");
    editbtn.className="btn btn-success";
    //editbtn.innerText="Edit";
    editbtn.innerHTML='<i class="fa-solid fa-pen-to-square fa-sm"></i>';
    tdActionbuttons.appendChild(editbtn);
    editbtn.onclick=()=>{
        console.log("Edit", dataOb);
        editFunction(dataOb,index);
        
    }

   
    let viewbtn=document.createElement("button");
    viewbtn.className="btn btn-primary ";
    // viewbtn.innerText="View";
    viewbtn.innerHTML='<i class="fa-regular fa-eye fa-sm "></i>';
    tdActionbuttons.appendChild(viewbtn);
    viewbtn.onclick=()=>{
        console.log("View",dataOb);
        viewFunction(dataOb,index);        
    }

    let deletebtn=document.createElement("button");
    deletebtn.className="btn btn-danger";
    // deletebtn.innerText="Delete";
    deletebtn.innerHTML='<i class="fa-solid fa-trash fa-sm"></i>';
    tdActionbuttons.appendChild(deletebtn);
    deletebtn.onclick=()=>{
        console.log("Delete",dataOb);
        deleteFunction(dataOb,index);
    }

   
    if (buttonVisibility) {
        tr.appendChild(tdActionbuttons);
    }
     
    tableBodyId.appendChild(tr);
    });

}

//fill data into table design 2
const fillDataintoTableTwo=(tableBodyId,dataList,columnList,editFunction,deleteFunction,
    viewFunction,buttonVisibility=true)=>{


    
    tableBodyId.innerHTML="";//Cleaning the inner html

    dataList.forEach((dataOb,index )=> {

    let tr=document.createElement("tr");

    let tdindex=document.createElement("td");
    tdindex.innerText=parseInt(index)+1;
    tr.appendChild(tdindex);


    //console.log(dataOb);
    
    
    //Creating rows for data
    for (const column of columnList) {
        let td=document.createElement("td");

        if (column.dataType=="string") {
            td.innerText=dataOb[column.columnName];//column namer is string e nisa dot tiyl accesss krnn aba e nisa array ek k widiht dai
        } 
        if (column.dataType=="decimal") {
            td.innerHTML=parseFloat(dataOb[column.columnName]).toFixed(2);//two decimal points
        } 
        if (column.dataType=="function") {
            td.innerHTML=column.columnName(dataOb);
        } 
       if (column.dataType=="image-array") {
            let img=document.createElement("img");
            img.className="w-50 h-50";
             if (dataOb[column.columnName]!=null) {
                img.src=atob(dataOb[column.columnName]);
             } else {
                img.src="images/undraw_profile.jpg";
             }
            td.appendChild(img);
        } 
        
        tr.appendChild(td);
    }

    
   

    let tdActionbuttons=document.createElement("td");

    let div=document.createElement("div");
    div.className="dropdown";
    tdActionbuttons.appendChild(div);

    let buttonDropdown=document.createElement("button");
    buttonDropdown.className="btn btn-sm ms-4 ";
    //buttonDropdown.innerText="Modify"; style 1
    buttonDropdown.innerHTML="<i class='fa-solid fa-ellipsis fa-beat-fade'></i>"; //style 2
    buttonDropdown.setAttribute("data-bs-toggle","dropdown");
    buttonDropdown.setAttribute("aria-expanded","false");
    div.appendChild(buttonDropdown);

    let dropdownUl=document.createElement("ul");
    dropdownUl.style="background: linear-gradient(45deg, #f8f9fa, #eaf4fc);";
    dropdownUl.className="dropdown-menu";
    buttonDropdown.appendChild(dropdownUl);

    let listItemEdit=document.createElement("li");
    listItemEdit.className="dropdown-item";

    let editbtn=document.createElement("button");
    editbtn.className="btn btn-outline-warning ms-4 btn-sm";
    
    //editbtn.innerText="Edit";
    editbtn.innerHTML="<i class='fa-solid fa-pen-to-square fa-shake'></i> Edit";
    
    editbtn.onclick=()=>{
        console.log("Edit", dataOb);
        editFunction(dataOb,index);
        
    }
    listItemEdit.appendChild(editbtn);
    dropdownUl.appendChild(listItemEdit);


    let listItemView=document.createElement("li");
    listItemView.className="dropdown-item";

    let viewbtn=document.createElement("button");
    viewbtn.className="btn btn-outline-info ms-4 btn-sm ";
   // viewbtn.innerText="View";
   viewbtn.innerHTML="<i class='fa-solid fa-eye fa-shake'></i> View";
    
    viewbtn.onclick=()=>{
        console.log("View",dataOb);
        viewFunction(dataOb,index);        
    }
    listItemView.appendChild(viewbtn);
    dropdownUl.appendChild(listItemView);


    let listItemDelete=document.createElement("li");
    listItemDelete.className="dropdown-item";

    let deletebtn=document.createElement("button");
    deletebtn.className="btn btn-outline-danger ms-4 btn-sm";
   // deletebtn.innerText="Delete";
   deletebtn.innerHTML="<i class='fa-solid fa-trash fa-shake'></i> Delete";
   
    deletebtn.onclick=()=>{
        console.log("Delete",dataOb);
        deleteFunction(dataOb,index);
    }
    listItemDelete.appendChild(deletebtn);
    dropdownUl.appendChild(listItemDelete);

   
    if (buttonVisibility) {
        tr.appendChild(tdActionbuttons);
    }
     
    tableBodyId.appendChild(tr);
    });

}


//fill data into table design 4 -->with only view button for inventory
const fillDataintoTableFour=(tableBodyId,dataList,columnList,viewFunction,buttonVisibility=true)=>{


    tableBodyId.innerHTML="";//Cleaning the inner html

    dataList.forEach((dataOb,index )=> {

    let tr=document.createElement("tr");

    let tdindex=document.createElement("td");
    tdindex.innerText=parseInt(index)+1;
    tr.appendChild(tdindex);


    //console.log(dataOb);
    
    
    //Creating rows for data
    for (const column of columnList) {
        let td=document.createElement("td");

        if (column.dataType=="string") {
            td.innerText=dataOb[column.columnName];//column namer is string e nisa dot tiyl accesss krnn aba e nisa array ek k widiht dai
        } 
        if (column.dataType=="decimal") {
            td.innerHTML=parseFloat(dataOb[column.columnName]).toFixed(2);//two decimal points
        } 
        if (column.dataType=="function") {
            td.innerHTML=column.columnName(dataOb);
        } 
       if (column.dataType=="image-array") {
            let img=document.createElement("img");
            img.className="w-25 h-25";
             if (dataOb[column.columnName]!=null) {
                img.src=atob(dataOb[column.columnName]);
             } else {
                img.src="images/undraw_profile.jpg";
             }
            td.appendChild(img);
        } 
        
        tr.appendChild(td);
    }

    
   

    let tdActionbuttons=document.createElement("td");

    let div=document.createElement("div");
    div.className="dropdown";
    tdActionbuttons.appendChild(div);

    let buttonDropdown=document.createElement("button");
    buttonDropdown.className="btn btn-sm ms-4 ";
    //buttonDropdown.innerText="Modify"; style 1
    buttonDropdown.innerHTML="<i class='fa-solid fa-ellipsis fa-beat-fade'></i>"; //style 2
    buttonDropdown.setAttribute("data-bs-toggle","dropdown");
    buttonDropdown.setAttribute("aria-expanded","false");
    div.appendChild(buttonDropdown);

    let dropdownUl=document.createElement("ul");
    dropdownUl.style="background: linear-gradient(45deg, #f8f9fa, #eaf4fc);";
    dropdownUl.className="dropdown-menu";
    buttonDropdown.appendChild(dropdownUl);


    let listItemView=document.createElement("li");
    listItemView.className="dropdown-item";

    let viewbtn=document.createElement("button");
    viewbtn.className="btn btn-outline-info ms-4 btn-sm ";
   // viewbtn.innerText="View";
   viewbtn.innerHTML="<i class='fa-solid fa-eye fa-shake'></i> View";
    
    viewbtn.onclick=()=>{
        console.log("View",dataOb);
        viewFunction(dataOb,index);        
    }
    listItemView.appendChild(viewbtn);
    dropdownUl.appendChild(listItemView);

   
    if (buttonVisibility) {
        tr.appendChild(tdActionbuttons);
    }
     
    tableBodyId.appendChild(tr);
    });

}


//fill data into report table
const fillDataintoReportTable=(tableBodyId,dataList,columnList)=>{

 
    tableBodyId.innerHTML="";//Cleaning the inner html

    dataList.forEach((dataOb,index )=> {

    let tr=document.createElement("tr");

    let tdindex=document.createElement("td");
    tdindex.innerText=parseInt(index)+1;
    tr.appendChild(tdindex);


    //console.log(dataOb);
    
    
    //Creating rows for data
    for (const column of columnList) {
        let td=document.createElement("td");

        if (column.dataType=="string") {
            td.innerText=dataOb[column.columnName];//column namer is string e nisa dot tiyl accesss krnn aba e nisa array ek k widiht dai
        } 
        if (column.dataType=="decimal") {
            td.innerHTML=parseFloat(dataOb[column.columnName]).toFixed(2);//two decimal points
        } 
        if (column.dataType=="function") {
            td.innerHTML=column.columnName(dataOb);
        } 
       if (column.dataType=="image-array") {
            let img=document.createElement("img");
            img.className="w-25 h-25";
             if (dataOb[column.columnName]!=null) {
                img.src=atob(dataOb[column.columnName]);
             } else {
                img.src="images/undraw_profile.jpg";
             }
            td.appendChild(img);
        } 
        
        tr.appendChild(td);
    }
 
    tableBodyId.appendChild(tr);
    });

}



//table design 3
//define fill data into table(tablebody id,datalist ,column list,edit function name,delete function name,view function name)
const fillDataintoTableThree=(tableBodyId,dataList,columnList,buttonVisibility=true)=>{


    
    tableBodyId.innerHTML="";//Cleaning the inner html

    dataList.forEach((dataOb,index )=> {

    let tr=document.createElement("tr");

    let tdindex=document.createElement("td");
    tdindex.innerText=parseInt(index)+1;
    tr.appendChild(tdindex);


    //console.log(dataOb);
    
    

    for (const column of columnList) {
        let td=document.createElement("td");

        if (column.dataType=="string") {
            td.innerText=dataOb[column.columnName];//column namer is string e nisa dot tiyl accesss krnn aba e nisa array ek k widiht dai
        } 
        if (column.dataType=="function") {
            td.innerHTML=column.columnName(dataOb);
        } 
        
        
        else {
            
        }
        tr.appendChild(td);
    }

    
    

   

    let tdActionbuttons=document.createElement("td");

    let button=document.createElement("button");
    button.className="btn btn-outline-warning ms-2";
    button.innerText="Edit";
    button.onclick=()=>{
        actionButtons.style.display="block";
        //make dataOb & Row index global for the the button row open in table style 3
        window['editOb']=dataOb;//dataob eka editOb ta denwa
        window['rowIndex']=index;
       
    }
    tdActionbuttons.appendChild(button);

    

   
    if (buttonVisibility) {
        tr.appendChild(tdActionbuttons);
    }
     
    tableBodyId.appendChild(tr);
    });

}






//reusable function for select list(elementid,massege,dtaalistname,prportyname of the datalist)

const fillDataintoSelect=(parentId,massege,dataList,displaypropertyname)=>{

    parentId.innerHTML="";//empty the values inside the html tag
    
    if (massege!="") {
        let optionStatus=document.createElement("option");
        optionStatus.value="";//value eka empty kre nattm innertext eka return venwa value eka widiht("pls slect desig.")
        
        optionStatus.selected="selected";
        optionStatus.disabled="disabled";
        optionStatus.innerText=massege;
        parentId.appendChild(optionStatus);
    
    }
   
    dataList.forEach(dataOb => {
        let option=document.createElement("option");
        option.value=JSON.stringify(dataOb);//convert js object into json string (to see the text)
        option.innerText=dataOb[displaypropertyname];
        parentId.appendChild(option);
    });


}



//reusable function for select list(elementid,massege,dtaalistname,prportyname of the datalist)

const fillDataintoSelectTwo=(parentId,massege,dataList,displaypropertynameOne,displaypropertynameTwo,selectedvalue)=>{

    parentId.innerHTML="";//empty the values inside the html tag
    
    if (massege!="") {
        let optionStatus=document.createElement("option");
        optionStatus.value="";//value eka empty kre nattm innertext eka return venwa value eka widiht("pls slect desig.")
        
        optionStatus.selected="selected";
        optionStatus.disabled="disabled";
        optionStatus.innerText=massege;
        parentId.appendChild(optionStatus);
    
    }
   
    dataList.forEach(dataOb => {
        let option=document.createElement("option");
        if (selectedvalue==dataOb[displaypropertynameOne]) {
            option.selected="selected";
        }
        option.value=JSON.stringify(dataOb);//convert js object into json string (to see the text)
        option.innerText=dataOb[displaypropertynameOne]+" "+dataOb[displaypropertynameTwo];
        parentId.appendChild(option);
    });


}


//reusable function for select list(elementid,massege,dtaalistname,prportynameone,propertyname2 of the datalist)

const fillDataintoDataList=(parentId,dataList,displaypropertynameOne,displaypropertynameTwo)=>{

    parentId.innerHTML="";//empty the values inside the html tag
   
    dataList.forEach(dataOb => {
        let option=document.createElement("option");
    
        option.value=dataOb[displaypropertynameOne]+" "+dataOb[displaypropertynameTwo];//we need the format like this "itemcode itemname"
        option.innerText=dataOb[displaypropertynameOne]+" "+dataOb[displaypropertynameTwo];
        parentId.appendChild(option);
    });


}

//reusable function for select list(elementid,massege,dtaalistname,prportynameone of the dtalist)
const fillDataintoDataListTwo=(parentId,dataList,displaypropertynameOne)=>{

    parentId.innerHTML="";//empty the values inside the html tag
   
    dataList.forEach(dataOb => {
        let option=document.createElement("option");
    
        option.value=dataOb[displaypropertynameOne];//we need the format like this "grnCode"
        option.innerText=dataOb[displaypropertynameOne];
        parentId.appendChild(option);
    });


}


//fill data into iiner table
const fillDataintoInnerTable=(tableBodyId,dataList,columnList,editFunction,deleteFunction,buttonVisibility=true)=>{


    
    tableBodyId.innerHTML="";//Cleaning the inner html

    dataList.forEach((dataOb,index )=> {

    let tr=document.createElement("tr");

    let tdindex=document.createElement("td");
    tdindex.innerText=parseInt(index)+1;
    tr.appendChild(tdindex);


    //console.log(dataOb);
    
    
    //Creating rows for data
    for (const column of columnList) {
        let td=document.createElement("td");

        if (column.dataType=="string") {
            td.innerText=dataOb[column.columnName];//column namer is string e nisa dot tiyl accesss krnn aba e nisa array ek k widiht dai
        } 
        if (column.dataType=="decimal") {
            td.innerHTML=parseFloat(dataOb[column.columnName]).toFixed(2);//two decimal points
        } 
        if (column.dataType=="function") {
            td.innerHTML=column.columnName(dataOb);
        } 
       
        
        
        else {
            
        }
        tr.appendChild(td);
    }

    
   

    let tdActionbuttons=document.createElement("td");

    let div=document.createElement("div");
    div.className="dropdown";
    tdActionbuttons.appendChild(div);

    let buttonDropdown=document.createElement("button");
    buttonDropdown.className="btn btn-sm ms-4 ";
    //buttonDropdown.innerText="Modify"; style 1
    buttonDropdown.innerHTML="<i class='fa-solid fa-ellipsis fa-beat-fade'></i>"; //style 2
    buttonDropdown.setAttribute("data-bs-toggle","dropdown");
    buttonDropdown.setAttribute("aria-expanded","false");
    div.appendChild(buttonDropdown);

    let dropdownUl=document.createElement("ul");
    dropdownUl.style="background: linear-gradient(45deg, #f8f9fa, #eaf4fc);";
    dropdownUl.className="dropdown-menu";
    buttonDropdown.appendChild(dropdownUl);

    //edit btn
    let listItemEdit=document.createElement("li");
    listItemEdit.className="dropdown-item";

    let editbtn=document.createElement("button");
    editbtn.className="btn btn-outline-warning ms-4 btn-sm";
    
    //editbtn.innerText="Edit";
    editbtn.innerHTML="<i class='fa-solid fa-pen-to-square fa-shake'></i> Edit";
    
    editbtn.onclick=()=>{
        console.log("Edit", dataOb);
        editFunction(dataOb,index);
        
    }
    listItemEdit.appendChild(editbtn);
    dropdownUl.appendChild(listItemEdit);


    //delete btn
    let listItemDelete=document.createElement("li");
    listItemDelete.className="dropdown-item";

    let deletebtn=document.createElement("button");
    deletebtn.className="btn btn-outline-danger ms-4 btn-sm";
   // deletebtn.innerText="Delete";
   deletebtn.innerHTML="<i class='fa-solid fa-trash fa-shake'></i> Delete";
   
    deletebtn.onclick=()=>{
        console.log("Delete",dataOb);
        deleteFunction(dataOb,index);
    }
    listItemDelete.appendChild(deletebtn);
    dropdownUl.appendChild(listItemDelete);

   
    if (buttonVisibility) {
        tr.appendChild(tdActionbuttons);
    }
     
    tableBodyId.appendChild(tr);
    });

}