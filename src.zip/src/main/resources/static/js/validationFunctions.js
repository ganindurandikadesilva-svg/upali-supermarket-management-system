//reusable function for text validation
const textValidator=(element,txtPattern,object,property)=>{
    const textValue=element.value;
    const ob=window[object];

    const regExp=new RegExp(txtPattern);//Creating an object
    console.log(textValue);
    

    if (textValue!="") {
        if (regExp.test(textValue)) {
            element.classList.remove("is-invalid");
            element.classList.add("is-valid");
            ob[property]=textValue;

        } else {
            element.classList.remove("is-valid");
            element.classList.add("is-invalid");
            ob[property]=null;
        }
        
    } else {
        element.classList.remove("is-valid");

        if (element.required) {
           
            element.classList.add("is-invalid");
            ob[property]=null;
        } else {
            element.style.border="1px solid #ced4da"; //intial bootsrap border 
            ob[property]="";
          
        }
    }
    

}

//Date of birth validator
const dobValidator=(element,object,property)=>{
    const dobElementValue=element.value;
    const ob=window[object];

    if (dobElementValue!="") {
        element.classList.remove("is-invalid");
        element.classList.add("is-valid");
        ob[property]=dobElementValue;

    } else {
        element.classList.remove("is-invalid");
        element.classList.add("is-valid");
        ob[property]=null;
    }

}

//select static element validator
const selectElementValidator=(element,object,property)=>{
    const selectElementValue=element.value;
    const ob=window[object];

    if (selectElementValue!="") {
        element.classList.remove("is-invalid");
        element.classList.add("is-valid");
        ob[property]=selectElementValue;

    } else {
        element.classList.remove("is-invalid");
        element.classList.add("is-valid");
        ob[property]=null;
    }
}

//select dynamic element validator(element name,object name(string) ,property(string))
const selectDynamicElementValidator=(element,object,property)=>{
    const selectElementValue=element.value;
    const ob=window[object];

    if (selectElementValue!="") {
        element.classList.remove("is-invalid");
        element.classList.add("is-valid");
        ob[property]=JSON.parse(selectElementValue);//dynamic nisa jason parse krnn one
        console.log(selectElementValue);
        

    } else {
        element.classList.remove("is-invalid");
        element.classList.add("is-valid");
        ob[property]=null;
    }
}

/* //select dynamic element validator2(element name,object name(string) ,property(string)) used for slect2 added select list search coloring & validation
const selectDynamicElementValidator2=(element,object,property)=>{
    const selectElementValue=element.value;
    const ob=window[object];

    if (selectElementValue!="") {
        element.parentNode.children[2].children[0].children[0].JSONclassList.remove("is-invalid");//seect2 library dmma nisa children athule tama color/classs add wenna one
        element.parentNode.children[2].children[0].children[0].classList.add("is-valid");
        ob[property]=JSON.parse(selectElementValue);//dynamic nisa jason parse krnn one
        console.log(selectElementValue);
        

    } else {
        element.parentNode.children[2].children[0].children[0].classList.remove("is-invalid");
        element.parentNode.children[2].children[0].children[0].classList.add("is-valid");
        ob[property]=null;
    }
} */


//Function for validating image/file (item,emp form)
//fileValidator(file element name,object name(string) ,property(string),preview id)
const fileValidator=(element,object,property,previewElement)=>{

    
    
    if (element.value!="") {
        console.log(element.files);

        let file=element.files[0];//file will have the names of the photos uploaded 
        //[0] index is the file
        
        let fileReader =new FileReader();//reading from a file so object nedded
        fileReader.onload=(e)=>{
            previewElement.src=e.target.result;//passing the image to the previewElement
            window[object][property]=btoa(e.target.result);//converting using btoa and binding
        }
        fileReader.readAsDataURL(file);//
    }
    

}   


//function for validating item name (this,objectname,'item_id')
const dataListValidator=(elementid,object,property)=>{

  let elementValue=elementid.value;
  let itemCode=elementValue.split(" ")[0];//split the value from the space, [0] value  when splitted is itemcode
  let extIndex=items.map(item=>item.item_no).indexOf(itemCode);//item list eke tiyna ietmobject eka gane aragen e itemobject eke item code check kriai

  
  if (extIndex!=-1) {
     window[object][property]=items[extIndex];//item ekt object eka set wenawa
      //set color for quotation Request Status

     elementid.classList.remove("is-invalid");
     elementid.classList.add("is-valid");
     
    
    }
 

    //console.log(quotationRequestHasItem);
    
}

//function for validating grn no (this,objectname,'grn_id')
const dataListValidatorTwo=(elementid,object,property)=>{

 /* grns list ekaka thiyana okkoma GRN number (grn_no) tika map ekak eken aran
user dala thiyena grncode eka e list eke inawada balanna indexOf eken balanawa.
extIndex ≠ -1 kiyanne GRN ekak match wela thiyenawa. */

  let grncode=elementid.value;
  let extIndex=grns.map(grn=>grn.grn_no).indexOf(grncode);//grn list eke tiyna grnobject eka gane aragen e grnobject eke grn code check kriai

  
  if (extIndex!=-1) {
     window[object][property]=grns[extIndex];//grn ekt object eka set wenawa

     elementid.classList.remove("is-invalid");
     elementid.classList.add("is-valid");
     
    
    }
 

    //console.log(quotationRequestHasItem);
    
}