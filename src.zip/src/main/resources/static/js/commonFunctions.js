const setToDefault = (elements) => {
  elements.forEach((element) => {
    element.classList.remove("is-valid");
    element.classList.remove("is-invalid");
  });
};

//define function for GET service request
const getServiceRequest = (url) => {

    let serviceResponse=[];//array

  //accessing data of database using ajax for employee table
  $.ajax({
    url: url,
    type: "GET", // HTTP method(GET/POST/PUT/DELETE)
    async: false,
    dataType: "json", // The type of data expected from the server
    success: function (response) {
      // Callback function executed if the request is successful
     // console.log("Success", response);
      serviceResponse = response;
    },
    error: function (xhr, status, error) {
      // Callback function executed if the request fails
      console.log("Error",url, response);
    },
  });
  return serviceResponse;
};


//define function for POST/PUT/DELETE service request 
const getHTTPServiceRequest = (url,method,data) => {

    let serviceResponse=[];//array

  //accessing data of database using ajax for employee table
  $.ajax({
    url: url,
    type: method, // HTTP method(POST/PUT/DELETE)
    async: false,
    contentType: 'application/json', // The type of data expected from the server
    data:JSON.stringify(data),
    success: function (response) {
      // Callback function executed if the request is successful
     // console.log(data);
      
      console.log("Success", response);
      serviceResponse = response;
    },
    error: function (xhr, status, error) {
      // Callback function executed if the request fails
      console.log("Error",url, response);
    },
  });
  return serviceResponse;
};



//generate colors
function generateRandomColors(count) {
  const colors = [];
  for (let i = 0; i < count; i++) {
    // Generate a random number between 0 and 16777215 (FFFFFF in hexadecimal)
    const randomHex = Math.floor(Math.random() * 16777215).toString(16);
    // Pad the hexadecimal string with leading zeros if necessary to ensure 6 digits
    const paddedHex = randomHex.padStart(6, '0');
    colors.push(`#${paddedHex}`);
  }
  return colors;
}