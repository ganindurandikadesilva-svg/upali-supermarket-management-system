

(function () {
    "use strict";

    // Sidebar toggle functionality
    const sidebarToggleButtons = document.querySelectorAll("#sidebarToggle, #sidebarToggleTop");
    const body = document.body;
    const sidebar = document.querySelector(".sidebar");
    const sidebarCollapse = document.querySelectorAll(".sidebar .collapse");

    sidebarToggleButtons.forEach((button) => {
        button.addEventListener("click", () => {
            body.classList.toggle("sidebar-toggled");
            sidebar.classList.toggle("toggled");
            if (sidebar.classList.contains("toggled")) {
                sidebarCollapse.forEach((collapse) => {
                    collapse.classList.remove("show");
                });
            }
        });
    });

    // Window resize behavior
    window.addEventListener("resize", () => {
        if (window.innerWidth < 768) {
            sidebarCollapse.forEach((collapse) => {
                collapse.classList.remove("show");
            });
        }
        if (window.innerWidth < 480 && !sidebar.classList.contains("toggled")) {
            body.classList.add("sidebar-toggled");
            sidebar.classList.add("toggled");
            sidebarCollapse.forEach((collapse) => {
                collapse.classList.remove("show");
            });
        }
    });

    // Prevent sidebar scrolling on large screens
    if (body.classList.contains("fixed-nav")) {
        sidebar.addEventListener("wheel", (e) => {
            if (window.innerWidth > 768) {
                const delta = e.deltaY || -e.detail;
                sidebar.scrollTop += 30 * (delta > 0 ? 1 : -1);
                e.preventDefault();
            }
        });
    }

    // Show or hide scroll-to-top button
    const scrollToTopButton = document.querySelector(".scroll-to-top");
    if (scrollToTopButton) {
        document.addEventListener("scroll", () => {
            if (window.scrollY > 100) {
                scrollToTopButton.style.display = "block";
            } else {
                scrollToTopButton.style.display = "none";
            }
        });

        // Smooth scroll to top
        scrollToTopButton.addEventListener("click", (e) => {
            e.preventDefault();
            window.scrollTo({
                top: 0,
                behavior: "smooth",
            });
        });
    }

    // Smooth scrolling for "a.scroll-to-top" links
    const scrollLinks = document.querySelectorAll("a.scroll-to-top");
    scrollLinks.forEach((link) => {
        link.addEventListener("click", (e) => {
            e.preventDefault();
            const target = document.querySelector(link.getAttribute("href"));
            if (target) {
                window.scrollTo({
                    top: target.offsetTop,
                    behavior: "smooth",
                });
            }
        });
    });
})();

