package lk.upalisupermarket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UpalisupermarketApplicationTests {

	@Test
	void contextLoads() {
	}

}
